﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using Microsoft.Extensions.DependencyInjection;
using FRT.Properties;
using Microsoft.Extensions.FileProviders;

namespace FRT.Messaging
{
	/// <summary>
	/// Message attachment
	/// </summary>
	public sealed class MessageAttachment : IDisposable
	{
		private Stream _stream;

		/// <summary>
		/// Constructor
		/// </summary>
		public MessageAttachment(byte[] data, string name, string mime)
		{
			if (data == null)
			{
				throw new ArgumentNullException(nameof(data));
			}

			name = string.IsNullOrWhiteSpace(name) ? null : name.Trim();
			mime = string.IsNullOrWhiteSpace(mime) ? null : mime.Trim();

			Name = name ?? throw new ArgumentNullException(nameof(name));
			Mime = mime ?? throw new ArgumentNullException(nameof(mime));

			_stream = new MemoryStream(data);
		}

		/// <summary>
		/// Constructor
		/// </summary>
		public MessageAttachment(string filePath, string mime = null)
		{
			filePath = string.IsNullOrWhiteSpace(filePath) ? null : filePath.Trim();
			if (filePath == null)
			{
				throw new ArgumentNullException(nameof(filePath));
			}

			// Get the file
			var fileProvider = DI.Container.GetService<IFileProvider>();
			if (fileProvider == null)
			{
				throw new InvalidOperationException(LocalResources.S_FileProviderNotAvailable);
			}

			// Get the file
			var fileInfo = fileProvider.GetFileInfo(filePath);
			if (!(fileInfo?.Exists ?? false) || fileInfo.IsDirectory)
			{
				throw new FileNotFoundException(CommonResources.S_FileNotFound, filePath);
			}

			// Mime
			mime = string.IsNullOrWhiteSpace(mime) ? null : mime.Trim();
			mime = mime ?? MimeUtil.DetectContentTypesFromExtension(fileInfo.PhysicalPath).FirstOrDefault();
			if (string.IsNullOrWhiteSpace(mime))
			{
				throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, CommonResources.S_UnknownFileMimeType_File, filePath));
			}

			// Save
			Name = Path.GetFileName(fileInfo.PhysicalPath);
			Mime = mime;

			// Data
			_stream = new MemoryStream();
			using (var fileStream = fileInfo.CreateReadStream())
			{
				fileStream.CopyTo(_stream);
			}
			_stream.Seek(0, SeekOrigin.Begin);
		}

		/// <summary>
		/// Constructor
		/// </summary>
		public MessageAttachment(Stream stream, string name, string mime = null)
		{
			if (stream == null)
			{
				throw new ArgumentNullException(nameof(stream));
			}

			name = string.IsNullOrWhiteSpace(name) ? null : name.Trim();
			mime = string.IsNullOrWhiteSpace(mime) ? null : mime.Trim();

			// Save
			Name = name ?? throw new ArgumentNullException(nameof(name));
			Mime = mime ?? throw new ArgumentNullException(nameof(mime));

			// Data
			_stream = new MemoryStream();
			stream.CopyTo(_stream);
			_stream.Seek(0, SeekOrigin.Begin);
		}

		/// <summary>
		/// Finalizer
		/// </summary>
		~MessageAttachment()
		{
			Dispose(false);
		}

		/// <summary>
		/// Disposer
		/// </summary>
		[SuppressMessage("Microsoft.Usage", "CA2213:DisposableFieldsShouldBeDisposed", MessageId = "_stream")]
		// ReSharper disable once UnusedParameter.Local
		private void Dispose(bool disposing)
		{
			_stream?.Dispose();
			_stream = null;
		}

		/// <summary>
		/// Disposer
		/// </summary>
		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}

		/// <summary>
		/// Unique Id
		/// </summary>
		public string Id { get; set; } = Guid.NewGuid().ToString("N");

		/// <summary>
		/// Name
		/// </summary>
		public string Name { get; }

		/// <summary>
		/// Mime type
		/// </summary>
		public string Mime { get; }

		/// <summary>
		/// Data stream
		/// </summary>
		public Stream Stream => _stream;
	}
}
