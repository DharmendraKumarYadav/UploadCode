﻿using System.Collections.Generic;

namespace FRT.Messaging
{
	/// <summary>
	/// Template type
	/// </summary>
	public enum MessageTemplateType
	{
		HtmlMail,
		TextMail,
		Sms
	}

	/// <summary>
	/// Message template loader
	/// </summary>
	public interface IMessageTemplateLoader
	{
		/// <summary>
		/// Loads the given template content
		/// </summary>
		/// <param name="templateRelativePath">Template relative path file name without the file extension</param>
		/// <param name="type">Templatetype to load</param>
		/// <returns>Content of the template if found. Null otherwise</returns>
		string Load(string templateRelativePath, MessageTemplateType type);

		/// <summary>
		/// Embeds resources into the html content
		/// </summary>
		/// <param name="htmlContent">Html content</param>
		/// <param name="templateRelativePath">Template relative path file name without the file extension</param>
		/// <param name="htmlLinkedResources">List of resources</param>
		string EmbedHtmlResources(string htmlContent, string templateRelativePath, List<MessageAttachment> htmlLinkedResources);
	}
}
