﻿using System.Threading.Tasks;

namespace FRT.Messaging
{
	/// <summary>
	/// Sms service
	/// </summary>
	public interface ISmsService
	{
		/// <summary>
		/// Sends an sms message asynchronously
		/// </summary>
		/// <param name="message">Sms message</param>
		/// <returns>Operation status</returns>
		Task<OperationResult<SmsSendStatus>> SendAsync(SmsMessage message);
	}
}
