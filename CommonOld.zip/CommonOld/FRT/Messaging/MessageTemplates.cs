﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Encodings.Web;
using Microsoft.Extensions.DependencyInjection;
using FRT.Properties;
// ReSharper disable RedundantArgumentDefaultValue

namespace FRT.Messaging
{
	/// <summary>
	/// Message template loader
	/// </summary>
	public static class MessageTemplates
	{
		/// <summary>
		/// Loads the given message with the content from the template
		/// </summary>
		/// <param name="mailMessage">Message</param>
		/// <param name="templateRelativePath">Relative path of the template</param>
		/// <param name="replacements">Token replacements</param>
		/// <param name="loadHtmlContent">Whether to load html content</param>
		/// <param name="loadTextContent">Whether to load text content</param>
		public static void LoadContentFromTemplate(this EmailMessage mailMessage, string templateRelativePath,
			IDictionary<string, string> replacements = null, bool loadHtmlContent = true, bool loadTextContent = true)
		{
			if (mailMessage == null)
			{
				throw new ArgumentNullException(nameof(mailMessage));
			}
			if (string.IsNullOrWhiteSpace(templateRelativePath))
			{
				throw new ArgumentNullException(nameof(templateRelativePath));
			}
			else if (!loadHtmlContent && !loadTextContent)
			{
				throw new InvalidOperationException(LocalResources.S_MessageTemplateNoContentToLoad);
			}

			// Get the service
			var templateLoader = DI.Container.GetService<IMessageTemplateLoader>();
			var htmlContent = loadHtmlContent ? templateLoader.Load(templateRelativePath, MessageTemplateType.HtmlMail) : null;
			var txtContent = loadTextContent? templateLoader.Load(templateRelativePath, MessageTemplateType.TextMail) : null;
			if ((htmlContent == null) && (txtContent == null))
			{
				throw new FileNotFoundException(CommonResources.S_FileNotFound, templateRelativePath);
			}

			// Set
			mailMessage.HtmlMessage = htmlContent;
			mailMessage.HtmlLinkedResources = new List<MessageAttachment>();
			mailMessage.TextMessage = txtContent;

			// Replacements
			PerformReplacements(mailMessage, replacements);

			// Embed resources
			if (mailMessage.HtmlMessage != null)
			{
				mailMessage.HtmlMessage = templateLoader.EmbedHtmlResources(mailMessage.HtmlMessage, templateRelativePath,
					mailMessage.HtmlLinkedResources);
			}
		}

		/// <summary>
		/// Loads the given message with the content from the template
		/// </summary>
		/// <param name="smsMessage">Message</param>
		/// <param name="templateRelativePath">Relative path of the template</param>
		/// <param name="replacements">Token replacements</param>
		public static void LoadContentFromTemplate(this SmsMessage smsMessage, string templateRelativePath,
			IDictionary<string, string> replacements = null)
		{
			if (smsMessage == null)
			{
				throw new ArgumentNullException(nameof(smsMessage));
			}
			if (string.IsNullOrWhiteSpace(templateRelativePath))
			{
				throw new ArgumentNullException(nameof(templateRelativePath));
			}

			// Get the service
			var templateLoader = DI.Container.GetService<IMessageTemplateLoader>();
			var txtContent = templateLoader.Load(templateRelativePath, MessageTemplateType.Sms);

			// Set
			smsMessage.Message = txtContent;

			// Replacements
			PerformReplacements(smsMessage, replacements);
		}

		/// <summary>
		/// Performs content replacements
		/// </summary>
		private static void PerformReplacements(EmailMessage mailMessage, IDictionary<string, string> replacements)
		{
			var tokenReplacements = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
			tokenReplacements.AddRange(replacements ?? new Dictionary<string, string>());

			// Add default global replacements
			var appConfig = Crosscuttings.AppInformationConfigOptions.Value;
			var templatesConfig = DI.Container.GetService<MessagingTemplatesConfig>();
			var configReplacements = new List<Tuple<string, string>>(new[]
			{
				new Tuple<string, string>("CompanyName", appConfig.CompanyName),
				new Tuple<string, string>("CompanyShortName", appConfig.CompanyShortName),
				new Tuple<string, string>("CompanyUrl", appConfig.CompanyUrl),
				new Tuple<string, string>("ApplicationName", appConfig.ApplicationName),
				new Tuple<string, string>("ApplicationShortName", appConfig.ApplicationShortName),
				new Tuple<string, string>("ApplicationDisplayVersion", appConfig.ApplicationDisplayVersion),
				new Tuple<string, string>("ApplicationVersion", appConfig.ApplicationVersion),
				new Tuple<string, string>("ApplicationSupportEmail", appConfig.ApplicationSupportEmail),
				new Tuple<string, string>("ApplicationTechSupportEmail", appConfig.ApplicationTechSupportEmail),
				new Tuple<string, string>("ApplicationUrl", Url.WebApplicationBaseUri.ToString())
			});
			tokenReplacements.MergeRange(configReplacements.Select(p => new KeyValuePair<string, string>(p.Item1, p.Item2)), false);
			tokenReplacements.MergeRange(templatesConfig?.Replacements.Select(p => new KeyValuePair<string, string>(p.Key, p.Value)) ?? new KeyValuePair<string, string>[0], false);

			// Load config
			var smtpConfig = DI.Container.GetService<SmtpEmailConfig>();

			// Subject
			string subject;
			if (!tokenReplacements.TryGetValue("Subject", out subject)
				|| string.IsNullOrWhiteSpace(subject))
			{
				subject = mailMessage.Subject;
			}
			subject = subject.Trim();

			// Add message specific properties
			tokenReplacements.Remove("Subject");
			tokenReplacements.Merge("Priority", mailMessage.Priority.ToString().NameToDisplayName(), false);
			tokenReplacements.Merge("From", (mailMessage.From ?? new EmailEndpoint(smtpConfig.SenderEmail)).ToString(), false);
			tokenReplacements.Merge("To", string.Join(", ", mailMessage.To.Select(e => e.ToString())), false);
			tokenReplacements.Merge("CC", string.Join(", ", (mailMessage.CC ?? new List<EmailEndpoint>()).Select(e => e.ToString())), false);
			tokenReplacements.Merge("Bcc", string.Join(", ", (mailMessage.Bcc ?? new List<EmailEndpoint>()).Select(e => e.ToString())), false);

			// Replace
			mailMessage.Subject = PerformReplacements(subject, tokenReplacements, false);
			tokenReplacements["Subject"] = mailMessage.Subject;
			mailMessage.HtmlMessage = PerformReplacements(mailMessage.HtmlMessage, tokenReplacements, true);
			mailMessage.TextMessage = PerformReplacements(mailMessage.TextMessage, tokenReplacements, false);
		}

		/// <summary>
		/// Performs content replacements
		/// </summary>
		private static void PerformReplacements(SmsMessage smsMessage, IDictionary<string, string> replacements)
		{
			var tokenReplacements = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
			tokenReplacements.AddRange(replacements ?? new Dictionary<string, string>());

			// Add default global replacements
			var templatesConfig = DI.Container.GetService<MessagingTemplatesConfig>();
			tokenReplacements.MergeRange(templatesConfig?.Replacements.Select(p => new KeyValuePair<string, string>(p.Key, p.Value)) ?? new KeyValuePair<string, string>[0], false);

			// Add message specific properties
			tokenReplacements.Merge("From", smsMessage.From?.ToString());
			tokenReplacements.Merge("To", smsMessage.To.ToString());

			// Replace
			smsMessage.Message = PerformReplacements(smsMessage.Message, tokenReplacements, false);
		}

		/// <summary>
		/// Performs content replacements
		/// </summary>
		private static string PerformReplacements(string content, IDictionary<string, string> replacements, bool isHtml)
		{
			if (string.IsNullOrWhiteSpace(content))
			{
				return content;
			}

			foreach (var kv in replacements.Where(k => k.Value != null))
			{
				var tokenString = string.Format(CultureInfo.InvariantCulture, "[html:{0}]", kv.Key);
				content = content.Replace(tokenString, kv.Value, StringComparison.OrdinalIgnoreCase);
				tokenString = string.Format(CultureInfo.InvariantCulture, "[text:{0}]", kv.Key);
				content = content.Replace(tokenString, isHtml ? HtmlEncoder.Default.Encode(kv.Value) : kv.Value, StringComparison.OrdinalIgnoreCase);
				tokenString = string.Format(CultureInfo.InvariantCulture, "[url:{0}]", kv.Key);
				content = content.Replace(tokenString, isHtml ? UrlEncoder.Default.Encode(kv.Value) : kv.Value, StringComparison.OrdinalIgnoreCase);
			}

			return content;
		}
	}
}

