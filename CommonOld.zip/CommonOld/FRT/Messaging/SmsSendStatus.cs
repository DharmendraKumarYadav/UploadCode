﻿namespace FRT.Messaging
{
	/// <summary>
	/// Sms sending status
	/// </summary>
	public enum SmsSendStatus
	{
		Delivered,
		Failed,
		Queued,
		Received,
		Receiving,
		Sending,
		Sent,
		Undelivered
	}
}
