﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text.RegularExpressions;
using FluentValidation;
using FluentValidation.Attributes;

namespace FRT.Messaging
{
	/// <summary>
	/// Message entity to be sent as e-mail
	/// </summary>
	[Validator(typeof(EmailMessageValidator))]
	public class EmailMessage : IDisposable
	{
		private static readonly Regex _nonAsciiCharsRegex = DI.Platform.CreateRegex(@"[^\x00-\x7F]",
			RegexOptions.Singleline | RegexOptions.IgnoreCase, true);
		private static readonly Regex _multipleWhiteSpacesRegex = DI.Platform.CreateRegex(@"\s{2,}",
			RegexOptions.Singleline | RegexOptions.IgnoreCase, true);

		/// <summary>
		/// Finalizer
		/// </summary>
		~EmailMessage()
		{
			Dispose(false);
		}

		/// <summary>
		/// Disposer
		/// </summary>
		protected virtual void Dispose(bool disposing)
		{
			Attachments?.ForEach(a => a.Dispose());
			Attachments = null;
			HtmlLinkedResources?.ForEach(a => a.Dispose());
			HtmlLinkedResources = null;
		}

		/// <summary>
		/// Disposer
		/// </summary>
		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}

		/// <summary>
		/// To address
		/// </summary>
		[SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		public List<EmailEndpoint> To
		{
			get;
			set;
		}

		/// <summary>
		/// From address
		/// </summary>
		public EmailEndpoint From
		{
			get;
			set;
		}

		/// <summary>
		/// CC
		/// </summary>
		[SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists")]
		[SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		public List<EmailEndpoint> CC
		{
			get;
			set;
		}

		/// <summary>
		/// Bcc
		/// </summary>
		[SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists")]
		[SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		public List<EmailEndpoint> Bcc
		{
			get;
			set;
		}

		private string _subject;
		/// <summary>
		/// Subject
		/// </summary>
		public string Subject
		{
			get => _subject;
			set
			{
				_subject = string.IsNullOrWhiteSpace(value) ? null : _multipleWhiteSpacesRegex.Replace(_nonAsciiCharsRegex.Replace(value.Trim(), string.Empty).Replace("\r", string.Empty).Replace("\n", string.Empty), " ");
				_subject = string.IsNullOrWhiteSpace(_subject) ? null : _subject.Trim();
			}
		}

		private string _textMessage;
		/// <summary>
		/// Text message
		/// </summary>
		public string TextMessage
		{
			get => _textMessage;
			set => _textMessage = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private string _htmlMessage;
		/// <summary>
		/// Html message
		/// </summary>
		public string HtmlMessage
		{
			get => _htmlMessage;
			set => _htmlMessage = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		/// <summary>
		/// Message priority
		/// </summary>
		public MessagePriority Priority
		{
			get;
			set;
		}

		/// <summary>
		/// Attachments
		/// </summary>
		[SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists")]
		[SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		public List<MessageAttachment> Attachments
		{
			get;
			set;
		}

		/// <summary>
		/// Linked resources to the html content
		/// </summary>
		[SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists")]
		[SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		public List<MessageAttachment> HtmlLinkedResources
		{
			get;
			set;
		}
	}

	/// <summary>
	/// Validator
	/// </summary>
	[SuppressMessage("Microsoft.Naming", "CA1710:IdentifiersShouldHaveCorrectSuffix")]
	public class EmailMessageValidator : AbstractValidator<EmailMessage>
	{
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		public EmailMessageValidator()
		{
			RuleFor(m => m.To)
				.NotNull()
				.Must(m => m.TrueForAll(e => (e != null) && e.IsValid));

			RuleFor(m => m.From)
				.Must(m => (m == null) || m.IsValid);

			RuleFor(m => m.CC)
				.Must(m => (m == null) || m.TrueForAll(e => (e != null) && e.IsValid));

			RuleFor(m => m.Bcc)
				.Must(m => (m == null) || m.TrueForAll(e => (e != null) && e.IsValid));

			RuleFor(m => m.Subject)
				.NotEmpty()
				.Matches(@"^[\x00-\x7F]*$");

			RuleFor(m => m.HtmlMessage)
				.Must((m, p) => (p != null) || (m.TextMessage != null));

			RuleFor(m => m.TextMessage)
				.Must((m, p) => (p != null) || (m.HtmlMessage != null));
		}
	}
}
