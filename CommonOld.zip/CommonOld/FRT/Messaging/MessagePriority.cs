﻿namespace FRT.Messaging
{
	/// <summary>
	/// Priority
	/// </summary>
	public enum MessagePriority
	{
		Normal,
		Low,
		High
	}
}
