﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace FRT.Messaging
{
	/// <summary>
	/// Messaging configuration
	/// </summary>
	public sealed class MessagingConfig : IInjectableConfig
	{
		private MessagingTemplatesConfig _messagingTemplatesConfig = new MessagingTemplatesConfig();
		/// <summary>
		/// Messaging templates configuration
		/// </summary>
		public MessagingTemplatesConfig Templates
		{
			get => _messagingTemplatesConfig;
			set => _messagingTemplatesConfig = value ?? new MessagingTemplatesConfig();
		}

		private SmtpEmailConfig _smtpEmailConfig = new SmtpEmailConfig();
		/// <summary>
		/// Smtp e-mail configuration
		/// </summary>
		public SmtpEmailConfig SmtpEmail
		{
			get => _smtpEmailConfig;
			set => _smtpEmailConfig = value ?? new SmtpEmailConfig();
		}

		private TwilioSmsConfig _twilioSmsConfig = new TwilioSmsConfig();
		/// <summary>
		/// Twilio sms configuration
		/// </summary>
		public TwilioSmsConfig TwilioSms
		{
			get => _twilioSmsConfig;
			set => _twilioSmsConfig = value ?? new TwilioSmsConfig();
		}
	}

	/// <summary>
	/// Messaging templates configuration
	/// </summary>
	public sealed class MessagingTemplatesConfig : IInjectableConfig
	{
		private string _relativePath;
		/// <summary>
		/// Templates path relative to app content root
		/// </summary>
		public string RelativePath
		{
			get => _relativePath;
			set => _relativePath = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private readonly Dictionary<string, string> _replacements = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
		/// <summary>
		/// Replacements
		/// </summary>
		[SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		public Dictionary<string, string> Replacements
		{
			get => _replacements;
			set
			{
				if (!Equals(_replacements, value))
				{
					_replacements.Clear();
					if (value != null)
					{
						_replacements.MergeRange(value);
					}
				}
			}
		}
	}

	/// <summary>
	/// Smtp Email configuration
	/// </summary>
	public sealed class SmtpEmailConfig : IInjectableConfig
	{
		private string _server;
		/// <summary>
		/// Smtp server or IP address
		/// </summary>
		public string Server
		{
			get => _server;
			set => _server = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		/// <summary>
		/// Smtp port
		/// </summary>
		public int Port
		{
			get;
			set;
		}

		/// <summary>
		/// Whether the communication is secure over SSL
		/// </summary>
		public bool Secure
		{
			get;
			set;
		} = true;

		private string _senderEmail;
		/// <summary>
		/// Sender e-mail address for authentication
		/// </summary>
		public string SenderEmail
		{
			get => _senderEmail;
			set => _senderEmail = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private string _senderPassword;
		/// <summary>
		/// Sender password for authentication
		/// </summary>
		public string SenderPassword
		{
			get => _senderPassword;
			set => _senderPassword = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}
	}

	/// <summary>
	/// Twilio Sms configuration
	/// </summary>
	public sealed class TwilioSmsConfig : IInjectableConfig
	{
		private string _accountSid;
		/// <summary>
		/// Account sid
		/// </summary>
		public string AccountSid
		{
			get => _accountSid;
			set => _accountSid = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private string _authToken;
		/// <summary>
		/// Authentication token
		/// </summary>
		public string AuthToken
		{
			get => _authToken;
			set => _authToken = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private string _fromPhone;
		/// <summary>
		/// From phone
		/// </summary>
		public string FromPhone
		{
			get => _fromPhone;
			set => _fromPhone = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}
	}
}
