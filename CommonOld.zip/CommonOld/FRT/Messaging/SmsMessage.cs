﻿using System.Diagnostics.CodeAnalysis;
using FluentValidation;
using FluentValidation.Attributes;

namespace FRT.Messaging
{
	/// <summary>
	/// Message entity to be sent as sms
	/// </summary>
	[Validator(typeof(SmsMessageValidator))]
	public class SmsMessage
	{
		/// <summary>
		/// To phone
		/// </summary>
		public SmsEndpoint To { get; set; }

		/// <summary>
		/// From phone
		/// </summary>
		public SmsEndpoint From { get; set; }

		/// <summary>
		/// Message
		/// </summary>
		public string Message { get; set; }
	}

	/// <summary>
	/// Validator
	/// </summary>
	[SuppressMessage("Microsoft.Naming", "CA1710:IdentifiersShouldHaveCorrectSuffix")]
	public class SmsMessageValidator : AbstractValidator<SmsMessage>
	{
		public SmsMessageValidator()
		{
			RuleFor(m => m.To)
				.NotNull()
				.Must(m => m.IsValid);

			RuleFor(m => m.From)
				.Must(m => (m == null) || m.IsValid);

			RuleFor(m => m.Message)
				.NotEmpty();
		}
	}
}