﻿namespace FRT.Messaging
{
	/// <summary>
	/// Email sending status
	/// </summary>
	public enum EmailSendStatus
	{
		Success,
		FailedRecipients,
		Failed
	}
}
