﻿using System;
using System.Globalization;
using System.Threading.Tasks;
using FRT.Messaging;
using FRT.Properties;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace FRT.Web
{
	/// <summary>
	/// Twilio based SMS service
	/// </summary>
	public sealed class TwilioSmsService : ISmsService
	{
		private readonly TwilioSmsConfig _config;

		/// <summary>
		/// Constructor
		/// </summary>
		public TwilioSmsService(TwilioSmsConfig config)
		{
			_config = config;
		}

		/// <summary>
		/// Sends an sms message asynchronously
		/// </summary>
		/// <param name="message">Sms message</param>
		/// <returns>Operation status</returns>
		public async Task<OperationResult<SmsSendStatus>> SendAsync(SmsMessage message)
		{
			// Validate
			if (message == null)
			{
				throw new ArgumentNullException(nameof(message));
			}
			message.ThrowOnValidationError();

			// Send
			var result = new OperationResult<SmsSendStatus>(SmsSendStatus.Failed);
			try
			{
				// Initialize and send
				TwilioClient.Init(_config.AccountSid, _config.AuthToken);
				var msg = await MessageResource.CreateAsync(
					to: new PhoneNumber(message.To.PhoneNumber),
					from: new PhoneNumber(_config.FromPhone),
					body: message.Message);

				// Update result
				if (string.Equals(msg.Status.ToString(), MessageResource.StatusEnum.Delivered.ToString(), StringComparison.OrdinalIgnoreCase))
				{
					result.Status = SmsSendStatus.Delivered;
				}
				else if (string.Equals(msg.Status.ToString(), MessageResource.StatusEnum.Failed.ToString(), StringComparison.OrdinalIgnoreCase))
				{
					result.Status = SmsSendStatus.Failed;
				}
				else if (string.Equals(msg.Status.ToString(), MessageResource.StatusEnum.Queued.ToString(), StringComparison.OrdinalIgnoreCase))
				{
					result.Status = SmsSendStatus.Queued;
				}
				else if (string.Equals(msg.Status.ToString(), MessageResource.StatusEnum.Received.ToString(), StringComparison.OrdinalIgnoreCase))
				{
					result.Status = SmsSendStatus.Received;
				}
				else if (string.Equals(msg.Status.ToString(), MessageResource.StatusEnum.Receiving.ToString(), StringComparison.OrdinalIgnoreCase))
				{
					result.Status = SmsSendStatus.Receiving;
				}
				else if (string.Equals(msg.Status.ToString(), MessageResource.StatusEnum.Sending.ToString(), StringComparison.OrdinalIgnoreCase))
				{
					result.Status = SmsSendStatus.Sending;
				}
				else if (string.Equals(msg.Status.ToString(), MessageResource.StatusEnum.Sent.ToString(), StringComparison.OrdinalIgnoreCase))
				{
					result.Status = SmsSendStatus.Sent;
				}
				else if (string.Equals(msg.Status.ToString(), MessageResource.StatusEnum.Undelivered.ToString(), StringComparison.OrdinalIgnoreCase))
				{
					result.Status = SmsSendStatus.Undelivered;
				}

				if (!string.IsNullOrWhiteSpace(msg.ErrorMessage))
				{
					result.Exception = new InvalidOperationException(msg.ErrorMessage);
				}
				else if (msg.ErrorCode.HasValue)
				{
					result.Exception = new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, CommonResources.S_UnknownError_Code, msg.ErrorCode.Value));
				}
			}
			catch (Exception ex)
			{
				result.Status = SmsSendStatus.Failed;
				result.Exception = ex;
			}
			return result;
		}
	}
}
