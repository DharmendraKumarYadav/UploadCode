﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using FRT.Messaging;
using FRT.Properties;
using MailKit;
using MailKit.Net.Smtp;
using MimeKit;
using MessagePriority = FRT.Messaging.MessagePriority;

namespace FRT.Web
{
	/// <summary>
	/// Smtp service
	/// </summary>
	public sealed class SmtpEmailService : IEmailService
	{
		private readonly AppInformationConfig _appInformationConfig;
		private readonly SmtpEmailConfig _config;

		/// <summary>
		/// Constructor
		/// </summary>
		public SmtpEmailService(AppInformationConfig appInformationConfig, SmtpEmailConfig config)
		{
			_appInformationConfig = appInformationConfig;
			_config = config;
		}

		/// <summary>
		/// Sends an e-mail message asynchronously
		/// </summary>
		/// <param name="message">E-mail message</param>
		/// <returns>Operation status</returns>
		public async Task<OperationResult<EmailSendStatus>> SendAsync(EmailMessage message)
		{
			// Validate
			if (message == null)
			{
				throw new ArgumentNullException(nameof(message));
			}
			message.ThrowOnValidationError();

			// Send
			return await Task.FromResult(Send(message));
		}

		/// <summary>
		/// Sends an e-mail message asynchronously
		/// </summary>
		/// <param name="message">E-mail message</param>
		/// <returns>Operation status</returns>
		[SuppressMessage("Microsoft.Usage", "CA2201:DoNotRaiseReservedExceptionTypes")]
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
		private OperationResult<EmailSendStatus> Send(EmailMessage message)
		{
			var result = new OperationResult<EmailSendStatus>();
			try
			{
				using (SmtpClient client = new SmtpClient())
				{
					// Configure
					client.ServerCertificateValidationCallback = (s, c, h, e) => true;
					client.Connect(_config.Server, _config.Port);

					// Note: since we don't have an OAuth2 token, disable
					// the XOAUTH2 authentication mechanism.
					client.AuthenticationMechanisms.Remove("XOAUTH2");

					// SMTP server requires authentication
					if (_config.SenderPassword != null)
					{
						client.Authenticate(_config.SenderEmail, _config.SenderPassword);
					}

					// Message
					var mailMessage = CreateMailMessage(message);

					// Send
					try
					{
						client.Send(mailMessage);
					}
					catch (ServiceNotConnectedException ex)
					{
						result.Status = EmailSendStatus.Failed;
						result.Exception = new Exception(string.Format(CultureInfo.CurrentCulture, LocalResources.S_CouldNotConnectToServer_Server, _config.Server), ex);
					}
					catch (ServiceNotAuthenticatedException ex)
					{
						result.Status = EmailSendStatus.Failed;
						result.Exception = new Exception(CommonResources.S_InvalidAuthenticationCredentials, ex);
					}
					catch (SmtpCommandException ex)
					{
						result.Status = EmailSendStatus.Failed;
						result.Exception = new Exception(
							string.Format(CultureInfo.CurrentCulture,
								"SMTP Error - {0} (status: {1}){2}",
								ex.ErrorCode.ToString().NameToDisplayName(),
								ex.StatusCode.ToString().NameToDisplayName(),
								((ex.ErrorCode == SmtpErrorCode.SenderNotAccepted) || (ex.ErrorCode == SmtpErrorCode.RecipientNotAccepted))
									? string.Format(CultureInfo.CurrentCulture, "(mailbox: {0})", ex.Mailbox.ToString())
									: string.Empty),
							ex);
					}
					catch (SmtpProtocolException ex)
					{
						result.Status = EmailSendStatus.Failed;
						result.Exception = new Exception(CommonResources.S_ProtocolError, ex);
					}
				}
			}
			catch (Exception ex)
			{
				result.Status = EmailSendStatus.Failed;
				result.Exception = ex;
			}
			return result;
		}

		/// <summary>
		/// Creates a mail message object
		/// </summary>
		/// <param name="message"></param>
		/// <returns></returns>
		[SuppressMessage("Microsoft.Reliability", "CA2000:Dispose objects before losing scope")]
		private MimeMessage CreateMailMessage(EmailMessage message)
		{
			var mailMessage = new MimeMessage();

			// Properties
			mailMessage.To.AddRange(message.To.Select(m => new MailboxAddress(m.DisplayName, m.Address)));
			if (message.CC != null)
			{
				mailMessage.Cc.AddRange(message.CC.Select(m => new MailboxAddress(m.DisplayName, m.Address)));
			}
			if (message.Bcc != null)
			{
				mailMessage.Bcc.AddRange(message.Bcc.Select(m => new MailboxAddress(m.DisplayName, m.Address)));
			}

			mailMessage.Sender = new MailboxAddress(_appInformationConfig.ApplicationName, _config.SenderEmail);
			if (message.From != null)
			{
				mailMessage.From.Add(new MailboxAddress(message.From.DisplayName, message.From.Address));
				mailMessage.ReplyTo.Add(new MailboxAddress(message.From.DisplayName, message.From.Address));
			}
			else
			{
				mailMessage.From.Add(new MailboxAddress(_appInformationConfig.ApplicationName, _config.SenderEmail));
				mailMessage.ReplyTo.Add(new MailboxAddress(_appInformationConfig.ApplicationName, _config.SenderEmail));
			}

			mailMessage.Priority = message.Priority.ConvertEnumByName<MessagePriority, MimeKit.MessagePriority>();
			mailMessage.Subject = message.Subject;

			// Body
			var bodyBuilder = new BodyBuilder();

			// Html view
			if (message.HtmlMessage != null)
			{
				bodyBuilder.HtmlBody = message.HtmlMessage;
				foreach (var htmlLinkedResource in message.HtmlLinkedResources ?? new List<MessageAttachment>())
				{
					var resource = bodyBuilder.LinkedResources.Add(htmlLinkedResource.Name, htmlLinkedResource.Stream,
						ContentType.Parse(htmlLinkedResource.Mime));
					resource.ContentId = htmlLinkedResource.Id;
				}
			}

			// Text view
			if (message.TextMessage != null)
			{
				bodyBuilder.TextBody = message.TextMessage;
			}

			// Attachments
			foreach (var att in message.Attachments)
			{
				bodyBuilder.Attachments.Add(att.Name, att.Stream, ContentType.Parse(att.Mime));
			}

			// Set body
			mailMessage.Body = bodyBuilder.ToMessageBody();

			// Return
			return mailMessage;
		}
	}
}
