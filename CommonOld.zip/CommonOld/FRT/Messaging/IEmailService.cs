﻿using System.Threading.Tasks;

namespace FRT.Messaging
{
	/// <summary>
	/// E-mail service
	/// </summary>
	public interface IEmailService
	{
		/// <summary>
		/// Sends an e-mail message asynchronously
		/// </summary>
		/// <param name="message">E-mail message</param>
		/// <returns>Operation status</returns>
		Task<OperationResult<EmailSendStatus>> SendAsync(EmailMessage message);
	}
}
