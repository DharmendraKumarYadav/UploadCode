﻿using System;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using FRT.Properties;

namespace FRT.Messaging
{
	/// <summary>
	/// Endpoint for an sms
	/// </summary>
	public sealed class SmsEndpoint
	{
		private static readonly Regex _validPhoneNumberRegex = DI.Platform.CreateRegex(@"[+\(\)\-\s0-9]",
			RegexOptions.Singleline | RegexOptions.IgnoreCase, true);
		private static readonly Regex _invalidPhoneNumberCharRegex = DI.Platform.CreateRegex(@"[^+0-9]",
			RegexOptions.Singleline | RegexOptions.IgnoreCase, true);
		private static readonly Regex _invalidDisplayNameCharRegex = DI.Platform.CreateRegex(@"[^\x00-\x7F]",
			RegexOptions.Singleline | RegexOptions.IgnoreCase, true);
		private string _phoneNumber;
		private string _displayName;

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="phoneNumber"></param>
		/// <param name="displayName"></param>
		public SmsEndpoint(string phoneNumber = null, string displayName = null)
		{
			if (!string.IsNullOrWhiteSpace(phoneNumber))
			{
				phoneNumber = phoneNumber.Trim();
				if (!_validPhoneNumberRegex.IsMatch(phoneNumber))
				{
					throw new ArgumentException(CommonResources.S_InvalidParameterFormat, nameof(phoneNumber));
				}
			}

			_displayName = !string.IsNullOrWhiteSpace(displayName) ? _invalidDisplayNameCharRegex.Replace(displayName.Trim(), string.Empty) : null;
			_displayName = string.IsNullOrWhiteSpace(_displayName) ? null : _displayName;
			_phoneNumber = string.IsNullOrWhiteSpace(phoneNumber) ? null : _invalidPhoneNumberCharRegex.Replace(phoneNumber, string.Empty);
			_phoneNumber = string.IsNullOrWhiteSpace(_phoneNumber) ? null : _phoneNumber;
		}

		/// <summary>
		/// Phone Number
		/// </summary>
		public string PhoneNumber
		{
			get => _phoneNumber;
			set
			{
				var phoneNumber = value;
				if (!string.IsNullOrWhiteSpace(phoneNumber))
				{
					phoneNumber = phoneNumber.Trim();
					if (!_validPhoneNumberRegex.IsMatch(phoneNumber))
					{
						throw new ArgumentException(CommonResources.S_InvalidParameterFormat, nameof(value));
					}
				}
				_phoneNumber = string.IsNullOrWhiteSpace(phoneNumber) ? null : _invalidPhoneNumberCharRegex.Replace(phoneNumber, string.Empty);
				_phoneNumber = string.IsNullOrWhiteSpace(_phoneNumber) ? null : _phoneNumber;
			}
		}

		/// <summary>
		/// Display name
		/// </summary>
		public string DisplayName
		{
			get => _displayName ?? _phoneNumber;
			set
			{
				_displayName = !string.IsNullOrWhiteSpace(value) ? _invalidDisplayNameCharRegex.Replace(value.Trim(), string.Empty) : null;
				_displayName = string.IsNullOrWhiteSpace(_displayName) ? null : _displayName;
			}
		}

		/// <summary>
		/// Whether the object is valid
		/// </summary>
		public bool IsValid => _phoneNumber != null;

		public override string ToString()
		{
			if (IsValid)
			{
				if (_displayName != null)
				{
					return string.Format(CultureInfo.CurrentCulture, "{0} <{1}>", _displayName, _phoneNumber);
				}
				return _phoneNumber;
			}
			else
			{
				return "Invalid phone number";
			}
		}

		/// <summary>
		/// Equality
		/// </summary>
		/// <param name="obj"></param>
		/// <returns></returns>
		public override bool Equals(object obj)
		{
			var other = obj as SmsEndpoint;
			if (other == null)
			{
				return false;
			}
			return _displayName.NullableEquals(other._displayName)
			       && _phoneNumber.NullableEquals(other._phoneNumber, StringComparison.OrdinalIgnoreCase);
		}

		/// <summary>
		/// Hash code generation
		/// </summary>
		/// <returns></returns>
		public override int GetHashCode()
		{
			StringBuilder sbBuffer = new StringBuilder();
			// ReSharper disable once NonReadonlyMemberInGetHashCode
			if (_displayName != null)
			{
				// ReSharper disable once NonReadonlyMemberInGetHashCode
				sbBuffer.Append(_displayName);
			}
			sbBuffer.Append("&*^%$@$#@@$");
			// ReSharper disable once NonReadonlyMemberInGetHashCode
			if (_phoneNumber != null)
			{
				// ReSharper disable once NonReadonlyMemberInGetHashCode
				sbBuffer.Append(_phoneNumber);
			}
			return sbBuffer.ToString().GetHashCode();
		}
	}
}
