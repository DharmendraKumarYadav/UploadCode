﻿using System;
using System.Threading;

namespace FRT
{
	/// <summary>
	/// Disposable lock for SemaphoreSlim
	/// </summary>
	public sealed class SlimSemaphoreLock : IDisposable
	{
		private readonly SemaphoreSlim _semaphore;
		private bool _lockAcquired;

		/// <summary>
		/// Constructor
		/// </summary>
		public SlimSemaphoreLock(SemaphoreSlim semaphore, int timeout = Timeout.Infinite)
		{
			_semaphore = semaphore ?? throw new ArgumentNullException(nameof(semaphore));
			_lockAcquired = _semaphore.Wait(timeout);
		}

		/// <summary>
		/// Constructor
		/// </summary>
		public SlimSemaphoreLock(SemaphoreSlim semaphore, TimeSpan timeout)
		{
			_semaphore = semaphore ?? throw new ArgumentNullException(nameof(semaphore));
			_lockAcquired = _semaphore.Wait(timeout);
		}

		/// <summary>
		/// Whether lock was acquired
		/// </summary>
		public bool HasLock => _lockAcquired;

		/// <summary>
		/// Disposes this instance
		/// </summary>
		public void Dispose()
		{
			if (_lockAcquired)
			{
				_semaphore.Release();
				_lockAcquired = false;
			}
		}
	}
}
