﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using SysReaderWriterLock = System.Threading.ReaderWriterLockSlim;

namespace FRT
{
	/// <summary>
	/// Base class for reader/writer locks
	/// </summary>
	public abstract class UpgradeableReaderWriterLock : IDisposable
	{
		private readonly bool _lockOwned;
		private SysReaderWriterLock _lock;

		#region Constructors
		/// <summary>
		/// Constructor - create a new lock
		/// </summary>
		/// <param name="timeoutMilliseconds">Timeout in milliseconds to acquire a lock</param>
		/// <param name="lockRecursion">Lock recursion policy</param>
		[SuppressMessage ("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
		protected UpgradeableReaderWriterLock (int timeoutMilliseconds = Timeout.Infinite, LockRecursionPolicy lockRecursion = LockRecursionPolicy.NoRecursion)
		{
			// Create
			_lock = new SysReaderWriterLock (lockRecursion);
			_lockOwned = true;

			// Lock
			// ReSharper disable once DoNotCallOverridableMethodsInConstructor
			if (!EnterLock(timeoutMilliseconds))
			{
				throw new SynchronizationLockException();
			}
		}

		/// <summary>
		/// Constructor - Use an external lock
		/// </summary>
		/// <param name="externalLock">External lock</param>
		/// <param name="ownLock">True to own this lock and dispose it along with this instance. False otherwise</param>
		/// <param name="timeoutMilliseconds">Timeout in milliseconds to acquire a lock</param>
		[SuppressMessage ("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
		protected UpgradeableReaderWriterLock(SysReaderWriterLock externalLock, bool ownLock = false, int timeoutMilliseconds = Timeout.Infinite)
		{
			// Save
			_lock = externalLock ?? throw new ArgumentNullException (nameof(externalLock));
			_lockOwned = ownLock;

			// Lock
			// ReSharper disable once DoNotCallOverridableMethodsInConstructor
			if (!EnterLock(timeoutMilliseconds))
			{
				throw new SynchronizationLockException();
			}
		}

		/// <summary>
		/// Finalizer
		/// </summary>
		~UpgradeableReaderWriterLock ()
		{
			Dispose (false);
		}
		#endregion

		#region IDisposable Members
		/// <summary>
		/// Disposal
		/// </summary>
		public void Dispose ()
		{
			Dispose (true);
			GC.SuppressFinalize (this);
		}

		/// <summary>
		/// Dispose override
		/// </summary>
		/// <param name="disposing">True if called from Dispose method. False if called from Finalizer</param>
		protected virtual void Dispose (bool disposing)
		{
			if (disposing)
			{
				if (_lock != null)
				{
					ExitLock ();
					if (_lockOwned)
					{
						_lock.Dispose ();
					}
					_lock = null;
				}
			}
		}
		#endregion

		#region Properties
		/// <summary>
		/// Underlying lock
		/// </summary>
		protected SysReaderWriterLock Lock => _lock;
		#endregion

		#region Abstracts
		/// <summary>
		/// Locks the object
		/// </summary>
		/// <param name="timeoutMilliseconds">Timeout in milliseconds to acquire a lock</param>
		/// <returns>True if the lock was successfully acquired. False otherwise.</returns>
		public abstract bool EnterLock(int timeoutMilliseconds = Timeout.Infinite);

		/// <summary>
		/// Unlocks the object
		/// </summary>
		public abstract void ExitLock ();
		#endregion
	}

	/// <summary>
	/// Reader lock
	/// </summary>
	public sealed class ReaderLock : UpgradeableReaderWriterLock
	{
		#region Constructors
		/// <summary>
		/// Constructor - create a new lock
		/// </summary>
		/// <param name="timeoutMilliseconds">Timeout in milliseconds to acquire a lock</param>
		/// <param name="lockRecursion">Lock recursion policy</param>
		public ReaderLock(int timeoutMilliseconds = Timeout.Infinite, LockRecursionPolicy lockRecursion = LockRecursionPolicy.NoRecursion) : base (timeoutMilliseconds, lockRecursion)
		{
		}

		/// <summary>
		/// Constructor - Use an external lock
		/// </summary>
		/// <param name="externalLock">External lock</param>
		/// <param name="ownLock">True to own this lock and dispose it along with this instance. False otherwise</param>
		/// <param name="timeoutMilliseconds">Timeout in milliseconds to acquire a lock</param>
		public ReaderLock(SysReaderWriterLock externalLock, bool ownLock = false, int timeoutMilliseconds = Timeout.Infinite)
			: base(externalLock, ownLock, timeoutMilliseconds)
		{
		}
		#endregion

		#region Overrides
		/// <summary>
		/// Locks the object
		/// </summary>
		/// <param name="timeoutMilliseconds">Timeout in milliseconds to acquire a lock</param>
		/// <returns>True if the lock was successfully acquired. False otherwise.</returns>
		public override bool EnterLock(int timeoutMilliseconds = Timeout.Infinite)
		{
			return Lock.TryEnterReadLock (timeoutMilliseconds);
		}

		/// <summary>
		/// Unlocks the object
		/// </summary>
		public override void ExitLock ()
		{
			Lock.ExitReadLock ();
		}
		#endregion
	}

	/// <summary>
	/// Upgreadable Reader lock
	/// </summary>
	public sealed class UpgradeableReaderLock : UpgradeableReaderWriterLock
	{
		#region Constructors
		/// <summary>
		/// Constructor - create a new lock
		/// </summary>
		/// <param name="timeoutMilliseconds">Timeout in milliseconds to acquire a lock</param>
		/// <param name="lockRecursion">Lock recursion policy</param>
		public UpgradeableReaderLock(int timeoutMilliseconds = Timeout.Infinite, LockRecursionPolicy lockRecursion = LockRecursionPolicy.NoRecursion) : base (timeoutMilliseconds, lockRecursion)
		{
		}

		/// <summary>
		/// Constructor - Use an external lock
		/// </summary>
		/// <param name="externalLock">External lock</param>
		/// <param name="ownLock">True to own this lock and dispose it along with this instance. False otherwise</param>
		/// <param name="timeoutMilliseconds">Timeout in milliseconds to acquire a lock</param>
		public UpgradeableReaderLock(SysReaderWriterLock externalLock, bool ownLock = false, int timeoutMilliseconds = Timeout.Infinite)
			: base(externalLock, ownLock, timeoutMilliseconds)
		{
		}
		#endregion

		#region Overrides
		/// <summary>
		/// Locks the object
		/// </summary>
		/// <param name="timeoutMilliseconds">Timeout in milliseconds to acquire a lock</param>
		/// <returns>True if the lock was successfully acquired. False otherwise.</returns>
		public override bool EnterLock(int timeoutMilliseconds = Timeout.Infinite)
		{
			return Lock.TryEnterUpgradeableReadLock (timeoutMilliseconds);
		}

		/// <summary>
		/// Unlocks the object
		/// </summary>
		public override void ExitLock ()
		{
			Lock.ExitUpgradeableReadLock();
		}
		#endregion
	}

	/// <summary>
	/// Writer lock
	/// </summary>
	public sealed class WriterLock : UpgradeableReaderWriterLock
	{
		#region Constructors
		/// <summary>
		/// Constructor - create a new lock
		/// </summary>
		/// <param name="timeoutMilliseconds">Timeout in milliseconds to acquire a lock</param>
		/// <param name="lockRecursion">Lock recursion policy</param>
		public WriterLock(int timeoutMilliseconds = Timeout.Infinite, LockRecursionPolicy lockRecursion = LockRecursionPolicy.NoRecursion) : base (timeoutMilliseconds, lockRecursion)
		{
		}

		/// <summary>
		/// Constructor - Use an external lock
		/// </summary>
		/// <param name="externalLock">External lock</param>
		/// <param name="ownLock">True to own this lock and dispose it along with this instance. False otherwise</param>
		/// <param name="timeoutMilliseconds">Timeout in milliseconds to acquire a lock</param>
		public WriterLock(SysReaderWriterLock externalLock, bool ownLock = false, int timeoutMilliseconds = Timeout.Infinite)
			: base(externalLock, ownLock, timeoutMilliseconds)
		{
		}
		#endregion

		#region Overrides
		/// <summary>
		/// Locks the object
		/// </summary>
		/// <param name="timeoutMilliseconds">Timeout in milliseconds to acquire a lock</param>
		/// <returns>True if the lock was successfully acquired. False otherwise.</returns>
		public override bool EnterLock(int timeoutMilliseconds = Timeout.Infinite)
		{
			return Lock.TryEnterWriteLock (timeoutMilliseconds);
		}

		/// <summary>
		/// Unlocks the object
		/// </summary>
		public override void ExitLock ()
		{
			Lock.ExitWriteLock ();
		}
		#endregion
	}
}
