﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace FRT
{
	/// <summary>
	/// Timer implementation for PCL
	/// </summary>
	public class PclTimer : CancellationTokenSource
	{
		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="callback">Timer callback</param>
		/// <param name="state">State</param>
		/// <param name="millisecondsDueTime">Due time</param>
		/// <param name="millisecondsPeriod">Period</param>
		/// <param name="waitForCallbackBeforeNextPeriod">Whether to invoke callback synchronously</param>
		public PclTimer(Action<object> callback, object state, int millisecondsDueTime, int millisecondsPeriod, bool waitForCallbackBeforeNextPeriod = false)
		{
			Task.Delay(millisecondsDueTime, Token).ContinueWith(async (t, s) =>
			{
				var tuple = (Tuple<Action<object>, object>)s;
				while (!IsCancellationRequested)
				{
					if (waitForCallbackBeforeNextPeriod)
					{
						tuple.Item1(tuple.Item2);
					}
					else
					{
						await Task.Run(() => tuple.Item1(tuple.Item2));
					}
					await Task.Delay(millisecondsPeriod, Token).ConfigureAwait(false);
				}
			}, Tuple.Create(callback, state), CancellationToken.None, TaskContinuationOptions.ExecuteSynchronously | TaskContinuationOptions.OnlyOnRanToCompletion, TaskScheduler.Default);
		}

		/// <summary>
		/// Disposal
		/// </summary>
		/// <param name="disposing"></param>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				Cancel();
			}
			base.Dispose(disposing);
		}
	}
}
