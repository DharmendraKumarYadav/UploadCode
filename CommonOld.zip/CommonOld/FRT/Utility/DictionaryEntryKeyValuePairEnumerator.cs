﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace FRT
{
	/// <summary>
	/// KeyValuePair enumerator for generic dictionary
	/// </summary>
	/// <typeparam name="TKeyType">Key type</typeparam>
	/// <typeparam name="TValueType">Value type</typeparam>
	public class DictionaryEntryKeyValuePairEnumerator<TKeyType, TValueType> : IEnumerator<KeyValuePair<TKeyType, TValueType>>
	{
		private IDictionaryEnumerator _dictionaryEnumerator;

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="dictionaryEnumerator">Inner enumerator</param>
		public DictionaryEntryKeyValuePairEnumerator(IDictionaryEnumerator dictionaryEnumerator)
		{
			_dictionaryEnumerator = dictionaryEnumerator ?? throw new ArgumentNullException(nameof(dictionaryEnumerator));
		}

		/// <summary>
		/// Finalizer
		/// </summary>
		~DictionaryEntryKeyValuePairEnumerator()
		{
			Dispose(false);
		}

		/// <summary>
		/// Disposer
		/// </summary>
		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}

		/// <summary>
		/// Disposer
		/// </summary>
		/// <param name="disposing">Whether disposing or finalizing</param>
		protected virtual void Dispose(bool disposing)
		{
			if (_dictionaryEnumerator != null)
			{
				var disposable = _dictionaryEnumerator as IDisposable;
				disposable?.Dispose();
				_dictionaryEnumerator = null;
			}
		}

		/// <summary>
		/// Current item
		/// </summary>
		public KeyValuePair<TKeyType, TValueType> Current
		{
			get
			{
				DictionaryEntry entry = (DictionaryEntry) _dictionaryEnumerator.Current;
				return new KeyValuePair<TKeyType, TValueType>((TKeyType)entry.Key, (TValueType) entry.Value);
			}
		}

		/// <summary>
		/// Current item
		/// </summary>
		object IEnumerator.Current => Current;

		/// <summary>
		/// Move to the next item
		/// </summary>
		/// <returns></returns>
		public bool MoveNext()
		{
			return _dictionaryEnumerator.MoveNext();
		}

		/// <summary>
		/// Reset the collection
		/// </summary>
		public void Reset()
		{
			_dictionaryEnumerator.Reset();
		}
	}
}
