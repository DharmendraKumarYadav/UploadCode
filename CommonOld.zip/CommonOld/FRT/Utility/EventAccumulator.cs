﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

namespace FRT
{
	/// <summary>
	/// Accumulates events occurring frequently and fires only one event within a specific interval
	/// </summary>
	public sealed class EventAccumulator<TEventArgs> : IDisposable
	{
		private PclTimer _triggerTimer;
		private readonly Queue<TEventArgs> _accumulatedEvents = new Queue<TEventArgs>();

		/// <summary>
		/// Event raised after interval is elapsed and there are events raised during the interval
		/// </summary>
		[SuppressMessage("Microsoft.Design", "CA1009:DeclareEventHandlersCorrectly")]
		public event EventHandler<List<TEventArgs>> OnCompositeEvent;

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="intervalMilliseconds">Time interval in milliseconds in which a single trigger will occur</param>
		public EventAccumulator(int intervalMilliseconds)
		{
			if (intervalMilliseconds < 0.0)
			{
				throw new ArgumentNullException(nameof(intervalMilliseconds));
			}
			_triggerTimer = new PclTimer(OnTimerCallback, null, intervalMilliseconds, intervalMilliseconds, true);
		}

		/// <summary>
		/// Handler for timer elapsed
		/// </summary>
		/// <param name="state">Sender</param>
		private void OnTimerCallback(object state)
		{
			if (OnCompositeEvent != null)
			{
				lock (_accumulatedEvents)
				{
					if (_accumulatedEvents.Count > 0)
					{
						OnCompositeEvent(this, _accumulatedEvents.ToList());
						_accumulatedEvents.Clear();
					}
				}
			}
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="interval">Time interval in which a single trigger will occur</param>
		public EventAccumulator(TimeSpan interval)
			: this((int) interval.TotalMilliseconds)
		{
		}

		/// <summary>
		/// Finalizer
		/// </summary>
		~EventAccumulator()
		{
			Dispose(false);
		}

		/// <summary>
		/// Disposes this instance
		/// </summary>
		// ReSharper disable once UnusedParameter.Local
		[SuppressMessage("Microsoft.Usage", "CA1801:ReviewUnusedParameters", MessageId = "disposing")]
		// ReSharper disable once UnusedParameter.Local
		private void Dispose(bool disposing)
		{
			if (_triggerTimer != null)
			{
				_triggerTimer.Dispose();
				_triggerTimer = null;
			}
		}

		/// <summary>
		/// Disposes this instance
		/// </summary>
		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}

		/// <summary>
		/// Call this method when the external event triggers
		/// </summary>
		/// <param name="eventArgs">Data associated with this event</param>
		public void EventRaised(TEventArgs eventArgs)
		{
			lock (_accumulatedEvents)
			{
				_accumulatedEvents.Enqueue(eventArgs);
			}
		}
	}
}
