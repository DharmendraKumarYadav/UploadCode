﻿namespace FRT
{
	public sealed class RefLock
	{
	}
}
