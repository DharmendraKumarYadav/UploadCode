﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Text.RegularExpressions;
using FRT.Properties;

namespace FRT
{
	/// <summary>
	/// Domain &amp; User Name
	/// </summary>
	public sealed class DomainUserNameInfo
	{
		public const string DefaultDomain = "FRTECH";

		#region Construction
		/// <summary>
		/// Creates an instance of this type
		/// </summary>
		public DomainUserNameInfo()
		{
		}

		/// <summary>
		/// Creates an instance of this type
		/// </summary>
		/// <param name="userName"></param>
		public DomainUserNameInfo(string userName)
		{
			if (string.IsNullOrWhiteSpace(userName))
			{
				UserName = null;
			}
			else
			{
				Tuple<string, string> data = GetDomainUserName(userName);
				Domain = data.Item1;
				UserName = data.Item2;
			}
		}
		#endregion

		#region Properties
		private string _domain = DefaultDomain;
		/// <summary>
		/// Domain
		/// </summary>
		[SuppressMessage("Microsoft.Usage", "CA2208:InstantiateArgumentExceptionsCorrectly")]
		public string Domain
		{
			get => _domain;
			set
			{
				string domain = string.IsNullOrWhiteSpace(value) ? DefaultDomain : value.Trim().ToUpperInvariant();
				if (Regex.IsMatch(domain, @"[^a-z0-9_\-\s]", RegexOptions.Singleline | RegexOptions.IgnoreCase))
				{
					// ReSharper disable once LocalizableElement
					throw new ArgumentNullException(string.Format(CultureInfo.CurrentCulture, CommonResources.S_InvalidDomainName_Name, domain), nameof(value));
				}
				_domain = domain;
			}
		}

		private string _userName;
		/// <summary>
		/// User name
		/// </summary>
		[SuppressMessage("Microsoft.Usage", "CA2208:InstantiateArgumentExceptionsCorrectly")]
		[SuppressMessage("Microsoft.Globalization", "CA1308:NormalizeStringsToUppercase")]
		public string UserName
		{
			get => _userName;
			set
			{
				string userName = string.IsNullOrWhiteSpace(value) ? null : value.Trim().ToLowerInvariant();
				if ((userName != null) && Regex.IsMatch(userName, @"[^a-z0-9_\-\s]", RegexOptions.Singleline | RegexOptions.IgnoreCase))
				{
					throw new ArgumentNullException(string.Format(CultureInfo.CurrentCulture, CommonResources.S_InvalidUserName_Name, userName), nameof(value));
				}
				_userName = userName;
			}
		}
		#endregion

		#region Operators
		/// <summary>
		/// Conversion from object to string
		/// </summary>
		/// <param name="userNameInfo"></param>
		/// <returns></returns>
		public static implicit operator string(DomainUserNameInfo userNameInfo)
		{
			return (userNameInfo == null) ? null
				: ((userNameInfo.UserName != null) ? string.Format(CultureInfo.InvariantCulture, "{0}\\{1}", userNameInfo.Domain, userNameInfo.UserName) : string.Empty);
		}

		/// <summary>
		/// Conversion from string to object
		/// </summary>
		/// <param name="userName"></param>
		/// <returns></returns>
		public static implicit operator DomainUserNameInfo(string userName)
		{
			return (userName == null) ? null : new DomainUserNameInfo(userName);
		}
		#endregion

		#region Overrides
		public override string ToString()
		{
			return this;
		}

		public override bool Equals(object obj)
		{
			return (obj != null) && string.Equals(obj.ToString(), ToString(), StringComparison.OrdinalIgnoreCase);
		}

		public override int GetHashCode()
		{
			return ToString().GetHashCode();
		}
		#endregion

		#region Helpers
		/// <summary>
		/// Retrieves Pre Windows2K domain &amp; user name [DOMAIN, Username]
		/// </summary>
		/// <param name="userName">User name</param>
		/// <returns>Pre windows 2000 domain and user name</returns>
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
		private static Tuple<string, string> GetDomainUserName(string userName)
		{
			userName = userName?.Trim();
			if (string.IsNullOrEmpty(userName))
			{
				throw new ArgumentNullException(nameof(userName));
			}

			try
			{
				string[] userNameParts = userName.Split(new[] { '/', '\\' }, StringSplitOptions.None);
				string domain, userNameWithoutDomainName;

				// Try DOMAIN\UserName
				if (userNameParts.Length > 1)
				{
					domain = userNameParts[0];
					userNameWithoutDomainName = userName.Substring(domain.Length + 1);
				}
				else
				{
					// Try UserName@DOMAIN
					userNameParts = userName.Split(new[] { '@' }, StringSplitOptions.None);
					if (userNameParts.Length > 1)
					{
						userNameWithoutDomainName = userNameParts[0];
						domain = userName.Substring(userNameWithoutDomainName.Length + 1);
						if (string.Equals(domain, DefaultDomain + ".com", StringComparison.OrdinalIgnoreCase))
						{
							domain = DefaultDomain;
						}
					}
					else
					{
						// Defaults
						domain = DefaultDomain;
						userNameWithoutDomainName = userName;
					}
				}
				return new Tuple<string, string>(domain, userNameWithoutDomainName);
			}
			catch
			{
				return new Tuple<string, string>(DefaultDomain, userName);
			}
		}
		#endregion
	}
}
