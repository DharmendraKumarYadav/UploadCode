﻿using System;
using System.Collections.Generic;

namespace FRT
{
	/// <summary>
	/// Equality comparer based on delegated methods
	/// </summary>
	/// <typeparam name="TType"></typeparam>
	public class DelegatedEqualityComparer<TType> : IEqualityComparer<TType>
	{
		private readonly Func<TType, TType, bool> _comparer;
		private readonly Func<TType, int> _hashCodeGenerator;

		#region Construction
		/// <summary>
		/// Creates an instance of this type
		/// </summary>
		/// <param name="comparer">Equality comparer delegate</param>
		/// <param name="hashCodeGenerator">Hash code generator delegate</param>
		public DelegatedEqualityComparer(Func<TType, TType, bool> comparer, Func<TType, int> hashCodeGenerator)
		{
			_comparer = comparer ?? throw new ArgumentNullException(nameof(comparer));
			_hashCodeGenerator = hashCodeGenerator ?? throw new ArgumentNullException(nameof(hashCodeGenerator));
		}
		#endregion

		#region Implementation
		/// <summary>
		/// Compares the two specified objects
		/// </summary>
		/// <param name="x">Object 1</param>
		/// <param name="y">Object 2</param>
		/// <returns>True if both objects are equal. False otherwise</returns>
		public virtual bool Equals(TType x, TType y)
		{
			return _comparer(x, y);
		}

		/// <summary>
		/// Generates hash code
		/// </summary>
		/// <param name="obj">Object</param>
		/// <returns>Hash code</returns>
		public virtual int GetHashCode(TType obj)
		{
			return _hashCodeGenerator(obj);
		}
		#endregion
	}
}
