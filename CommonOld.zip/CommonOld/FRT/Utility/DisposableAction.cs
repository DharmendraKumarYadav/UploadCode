﻿using System;

namespace FRT
{
	/// <summary>
	/// Class to call an action on disposal
	/// </summary>
	public class DisposableAction : IDisposable
	{
		private readonly Action<bool> _action;

		/// <summary>
		/// Creates an instance of this type
		/// </summary>
		/// <param name="action">Action to be called on disposal
		/// (boolean parameter indicates whether this action is being called from the Dispose method or from the finalizer)</param>
		public DisposableAction(Action<bool> action)
		{
			_action = action ?? throw new ArgumentNullException(nameof(action));
		}

		/// <summary>
		/// Finalizer
		/// </summary>
		~DisposableAction()
		{
			Dispose(false);
		}

		/// <summary>
		/// Disposes this instance
		/// </summary>
		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}

		/// <summary>
		/// Disposes this instance
		/// </summary>
		/// <param name="disposing">True if being called from the Dispose method. False if being called from the finalizer</param>
		protected virtual void Dispose(bool disposing)
		{
			_action(disposing);
		}
	}
}
