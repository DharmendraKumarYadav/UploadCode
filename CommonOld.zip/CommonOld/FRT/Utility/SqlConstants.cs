﻿using System;

namespace FRT
{
	/// <summary>
	/// Global Sql Constants
	/// </summary>
	public static class SqlConstants
	{
		public static readonly DateTime SqlMinDateTime = new DateTime(1753, 1, 1);
		public static readonly DateTime SqlMaxDateTime = new DateTime(9999, 12, 31);
		public static readonly DateTime SqlMinSmallDateTime = new DateTime(1900, 1, 1);
		public static readonly DateTime SqlMaxSmallDateTime = new DateTime(2079, 6, 6);
	}
}