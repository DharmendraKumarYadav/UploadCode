﻿using System.Linq;

namespace FRT
{
	/// <summary>
	/// String utilities
	/// </summary>
	public static class StringUtil
	{
		/// <summary>
		/// Combines multiple strings into one
		/// </summary>
		public static string JoinStrings(string separator, params string[] parts)
		{
			var result = string.Join(separator,
				(parts ?? new string[0]).Where(p => !string.IsNullOrWhiteSpace(p)).Select(p => p.Trim()));
			return string.IsNullOrWhiteSpace(result) ? null : result.Trim();
		}
	}
}
