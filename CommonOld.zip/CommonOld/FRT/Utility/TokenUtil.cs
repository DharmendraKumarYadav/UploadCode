﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Text;
using FRT.Properties;

namespace FRT
{
	/// <summary>
	/// Token utility
	/// </summary>
	public static class TokenUtil
	{
		private const string _tokenPartSeparator = "#$%";

		/// <summary>
		/// Creates an encrypted token for the given action
		/// </summary>
		/// <param name="action">Action</param>
		/// <param name="expiryTime">Whether the token has an expiry</param>
		/// <param name="subTokens">Sub-parts</param>
		/// <returns>Token</returns>
		public static string CreateToken(string action, TimeSpan? expiryTime = null, params string[] subTokens)
		{
			action = string.IsNullOrWhiteSpace(action) ? string.Empty : action.Trim();
			List<string> parts = new List<string>(subTokens.Select(p => p ?? string.Empty));
			parts.Insert(0, action);
			parts.Insert(1, expiryTime.HasValue.ToString());
			if (expiryTime.HasValue)
			{
				parts.Insert(2, DateTimeOffset.UtcNow.Add(expiryTime.Value).ToString("O", CultureInfo.InvariantCulture));
			}
			return Convert.ToBase64String(Crosscuttings.SymmetricCryptographer.EncryptData(Encoding.UTF8.GetBytes(string.Join(_tokenPartSeparator, parts))))
					.Replace('+', '-')
					.Replace('/', '_')
					.Replace('=', '~');
		}

		/// <summary>
		/// Analyzes the specified token
		/// </summary>
		/// <param name="token">Token</param>
		/// <param name="action">Action</param>
		/// <returns>Parts of the token</returns>
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
		public static OperationResult<bool, string[]> AnalyzeToken(string token, string action)
		{
			try
			{
				if (!string.IsNullOrWhiteSpace(token))
				{
					token = token.Trim().Replace('~', '=').Replace('_', '/').Replace('-', '+');
					action = string.IsNullOrWhiteSpace(action) ? string.Empty : action.Trim();

					var decryptedData = Crosscuttings.SymmetricCryptographer.DecryptData(Convert.FromBase64String(token));
					string[] allParts = Encoding.UTF8.GetString(decryptedData, 0, decryptedData.Length).Split(new [] { _tokenPartSeparator }, StringSplitOptions.None);
					if (allParts.Length >= 2)
					{
						if (string.Equals(action, allParts[0], StringComparison.OrdinalIgnoreCase))
						{
							var skipParts = 2;
							var hasExpiry = bool.Parse(allParts[1]);
							DateTimeOffset? expiryTime = null;
							if (hasExpiry)
							{
								expiryTime = DateTimeOffset.ParseExact(allParts[2], "O", CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind);
								skipParts = 3;
							}
							if (!expiryTime.HasValue || (expiryTime.Value <= DateTimeOffset.UtcNow))
							{
								return new OperationResult<bool, string[]>(true, allParts.Skip(skipParts).ToArray());
							}
						}
					}
				}
			}
			// ReSharper disable once EmptyGeneralCatchClause
			catch { }
			return new OperationResult<bool, string[]>() { Exception = new InvalidOperationException(LocalResources.S_InvalidSecurityToken) };
		}
	}
}

