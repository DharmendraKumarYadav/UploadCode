﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Reflection;

namespace FRT
{
	/// <summary>
	/// Assembly accessor
	/// </summary>
	public sealed class AssemblyAccess
	{
		private Assembly _assembly;
		private AssemblyName _assemblyName;

		#region Construction
		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="assembly">Assembly to wrap. If null, calling assembly will be used</param>
		[SuppressMessage("Microsoft.Design", "CA1026:DefaultParametersShouldNotBeUsed")]
		public AssemblyAccess(Assembly assembly = null)
		{
			Assembly = assembly;
		}

		/// <summary>
		/// Wrapping assembly
		/// </summary>
		public Assembly Assembly
		{
			get => _assembly;
			set
			{
				_assembly = value;
				_assemblyName = _assembly?.GetName();
			}
		}
		#endregion

		#region Attribute Retrieval
		/// <summary>
		/// Retrieves assembly attributes
		/// </summary>
		/// <typeparam name="TAttributeType">Type of the attribute</typeparam>
		/// <returns>Matching attributes</returns>
		public IEnumerable<TAttributeType> GetAssemblyAttributes<TAttributeType>() where TAttributeType : Attribute
		{
			List<TAttributeType> attributeList = new List<TAttributeType>();
			// ReSharper disable once LoopCanBeConvertedToQuery
			// ReSharper disable once PossibleInvalidCastExceptionInForeachLoop
			foreach (TAttributeType attr in _assembly.GetCustomAttributes(typeof(TAttributeType)))
			{
				attributeList.Add(attr);
			}
			return attributeList;
		}

		/// <summary>
		/// Retrieves assembly attribute
		/// </summary>
		/// <typeparam name="TAttributeType">Type of the attribute</typeparam>
		/// <returns>Matching attribute</returns>
		public TAttributeType GetAssemblyAttribute<TAttributeType>() where TAttributeType : Attribute
		{
			return _assembly.GetCustomAttributes(typeof (TAttributeType)).Cast<TAttributeType>().FirstOrDefault();
		}

		#endregion

		#region Properties
		/// <summary>
		/// File version
		/// </summary>
		public string FileVersion
		{
			get
			{
				AssemblyFileVersionAttribute attr = GetAssemblyAttribute<AssemblyFileVersionAttribute>();
				return attr?.Version;
			}
		}

		/// <summary>
		/// Assembly version
		/// </summary>
		public Version Version => _assemblyName?.Version;

		/// <summary>
		/// Copyright
		/// </summary>
		public string Copyright
		{
			get
			{
				AssemblyCopyrightAttribute attr = GetAssemblyAttribute<AssemblyCopyrightAttribute>();
				return attr?.Copyright;
			}
		}

		/// <summary>
		/// Trademark
		/// </summary>
		public string Trademark
		{
			get
			{
				AssemblyTrademarkAttribute attr = GetAssemblyAttribute<AssemblyTrademarkAttribute>();
				return attr?.Trademark;
			}
		}

		/// <summary>
		/// Product name
		/// </summary>
		public string Product
		{
			get
			{
				AssemblyProductAttribute attr = GetAssemblyAttribute<AssemblyProductAttribute>();
				return attr?.Product;
			}
		}

		/// <summary>
		/// Company
		/// </summary>
		public string Company
		{
			get
			{
				AssemblyCompanyAttribute attr = GetAssemblyAttribute<AssemblyCompanyAttribute>();
				return attr?.Company;
			}
		}

		/// <summary>
		/// Assembly description
		/// </summary>
		public string Description
		{
			get
			{
				AssemblyDescriptionAttribute attr = GetAssemblyAttribute<AssemblyDescriptionAttribute>();
				return attr?.Description;
			}
		}

		/// <summary>
		/// Assembly title
		/// </summary>
		public string Title
		{
			get
			{
				AssemblyTitleAttribute attr = GetAssemblyAttribute<AssemblyTitleAttribute>();
				return attr?.Title;
			}
		}

		/// <summary>
		/// Assembly configuration
		/// </summary>
		public string Configuration
		{
			get
			{
				AssemblyConfigurationAttribute attr = GetAssemblyAttribute<AssemblyConfigurationAttribute>();
				return attr?.Configuration;
			}
		}

		/// <summary>
		/// Default assembly alias
		/// </summary>
		public string DefaultAlias
		{
			get
			{
				AssemblyDefaultAliasAttribute attr = GetAssemblyAttribute<AssemblyDefaultAliasAttribute>();
				return attr?.DefaultAlias;
			}
		}

		/// <summary>
		/// Informational version
		/// </summary>
		public string InformationalVersion
		{
			get
			{
				AssemblyInformationalVersionAttribute attr = GetAssemblyAttribute<AssemblyInformationalVersionAttribute>();
				return attr?.InformationalVersion;
			}
		}

		/// <summary>
		/// Culture name
		/// </summary>
		public string CultureName => _assemblyName?.CultureName;

		/// <summary>
		/// Assembly culture
		/// </summary>
		public CultureInfo CultureInfo
			=> (_assemblyName?.CultureName != null) ? new CultureInfo(_assemblyName?.CultureName) : null;

		/// <summary>
		/// Assembly name
		/// </summary>
		public string Name => _assemblyName?.Name;

		/// <summary>
		/// Assembly full name
		/// </summary>
		public string FullName => _assemblyName?.FullName;

		/// <summary>
		/// Assembly key name
		/// </summary>
		public string KeyName
		{
			get
			{
				AssemblyKeyNameAttribute attr = GetAssemblyAttribute<AssemblyKeyNameAttribute>();
				return attr?.KeyName;
			}
		}

		/// <summary>
		/// Assembly key file path
		/// </summary>
		public string KeyFile
		{
			get
			{
				AssemblyKeyFileAttribute attr = GetAssemblyAttribute<AssemblyKeyFileAttribute>();
				return attr?.KeyFile;
			}
		}

		/// <summary>
		/// Whether to delay sign the assembly or not
		/// </summary>
		public bool DelaySign
		{
			get
			{
				AssemblyDelaySignAttribute attr = GetAssemblyAttribute<AssemblyDelaySignAttribute>();
				if (attr != null)
				{
					return attr.DelaySign;
				}

				return false;
			}
		}

		/// <summary>
		/// Name flags
		/// </summary>
		[SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "Flags")]
		public AssemblyNameFlags NameFlags
		{
			get
			{
				if (_assemblyName != null)
				{
					return _assemblyName.Flags;
				}

				return AssemblyNameFlags.None;
			}
		}
		#endregion
	}
}
