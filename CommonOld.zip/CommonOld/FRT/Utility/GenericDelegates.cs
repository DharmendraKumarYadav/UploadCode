﻿using System.Diagnostics.CodeAnalysis;

namespace FRT
{
	[SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix")]
	// ReSharper disable once TypeParameterCanBeVariant
	public delegate TReturnType GenericDelegate<TReturnType>(params object[] parameters);
	[SuppressMessage("Microsoft.Naming", "CA1711:IdentifiersShouldNotHaveIncorrectSuffix")]
	public delegate void GenericDelegate(params object[] parameters);
}
