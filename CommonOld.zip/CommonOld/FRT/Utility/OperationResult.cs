﻿using System;

namespace FRT
{
	/// <summary>
	/// Operation result
	/// </summary>
	/// <typeparam name="TStatus">Status of the operation</typeparam>
	public class OperationResult<TStatus>
	{
		/// <summary>
		/// Construction
		/// </summary>
		public OperationResult(TStatus status = default(TStatus))
		{
			Status = status;
		}

		/// <summary>
		/// Operation status
		/// </summary>
		public TStatus Status
		{
			get;
			set;
		}

		/// <summary>
		/// Exception
		/// </summary>
		public Exception Exception
		{
			get;
			set;
		}
	}

	/// <summary>
	/// Operation result
	/// </summary>
	/// <typeparam name="TStatus">Status of the operation</typeparam>
	/// <typeparam name="TData">Return data of the operation</typeparam>
	public class OperationResult<TStatus, TData> : OperationResult<TStatus>
	{
		/// <summary>
		/// Construction
		/// </summary>
		public OperationResult(TStatus status = default(TStatus), TData data = default(TData))
			: base(status)
		{
			Data = data;
		}

		/// <summary>
		/// Data
		/// </summary>
		public TData Data
		{
			get;
			set;
		}
	}
}
