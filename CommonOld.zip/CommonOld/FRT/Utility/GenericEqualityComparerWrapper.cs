﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;

namespace FRT
{
	/// <summary>
	/// Generic equality comparer
	/// </summary>
	/// <typeparam name="TItemType"></typeparam>
	public class GenericEqualityComparerWrapper<TItemType> : IEqualityComparer
	{
		private readonly IEqualityComparer<TItemType> _internalComparer;

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="internalComparer">Internal comparer</param>
		public GenericEqualityComparerWrapper(IEqualityComparer<TItemType> internalComparer)
		{
			_internalComparer = internalComparer ?? throw new ArgumentNullException(nameof(internalComparer));
		}

		/// <summary>
		/// Equals
		/// </summary>
		/// <param name="x">Item 1</param>
		/// <param name="y">Item 2</param>
		/// <returns>Result</returns>
		bool IEqualityComparer.Equals(object x, object y)
		{
			if (((x == null) && (y == null))
				|| ((x != null) && (y == null))
				|| (x == null))
			{
				return false;
			}

			// Check types
			if ((x is TItemType) && (y is TItemType))
			{
				return _internalComparer.Equals((TItemType) x, (TItemType) y);
			}
			else
			{
				// ReSharper disable once RedundantNameQualifier
				return object.ReferenceEquals(x, y);
			}
		}

		/// <summary>
		/// Hash code
		/// </summary>
		/// <param name="obj">Object</param>
		/// <returns>Hash code</returns>
		public int GetHashCode(object obj)
		{
			if (obj == null)
			{
				if (!typeof (TItemType).GetTypeInfo().IsValueType)
				{
					return _internalComparer.GetHashCode((TItemType) (object) null);
				}
				return 0;
			}
			else if (obj is TItemType)
			{
				return _internalComparer.GetHashCode((TItemType) obj);
			}
			else
			{
				return obj.GetHashCode();
			}
		}
	}
}
