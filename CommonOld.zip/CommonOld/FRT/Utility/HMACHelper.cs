﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using FRT.Cryptography;

namespace FRT
{
	/// <summary>
	/// HMAC helper
	/// </summary>
	public static class HMACHelper
	{
		/// <summary>
		/// Generates the timestamp token
		/// </summary>
		/// <param name="dateTime"></param>
		/// <returns></returns>
		public static ulong GetTimestamp(DateTimeOffset dateTime)
		{
			DateTimeOffset epochStart = new DateTimeOffset(new DateTime(1970, 01, 01, 0, 0, 0, 0, DateTimeKind.Utc));
			TimeSpan timeSpan = dateTime - epochStart;
			return Convert.ToUInt64(timeSpan.TotalSeconds);
		}

		/// <summary>
		/// Generates a nonce
		/// </summary>
		/// <returns></returns>
		public static string GenerateNonce()
		{
			return Guid.NewGuid().ToString("N").ToUpperInvariant();
		}

		/// <summary>
		/// Hashes the given data
		/// </summary>
		/// <param name="appId">App Id</param>
		/// <param name="appKey">App Key</param>
		/// <param name="nonce">Nonce data</param>
		/// <param name="tokens">String tokens to include in the hash</param>
		/// <param name="timestamp">Timestamp (UNIX seconds)</param>
		/// <returns>Hash data</returns>
		public static string Hash(string appId, string appKey,
			ulong timestamp, string nonce,
			params string[] tokens)
		{
			if (string.IsNullOrWhiteSpace(appId))
			{
				throw new ArgumentNullException(nameof(appId));
			}
			appId = appId.Trim();

			if (string.IsNullOrWhiteSpace(appKey))
			{
				throw new ArgumentNullException(nameof(appKey));
			}
			appKey = appKey.Trim();

			// Adjust tokens
			tokens = (tokens ?? new string[0]).Select(p => p ?? string.Empty).ToArray();

			// ReSharper disable once UseObjectOrCollectionInitializer
			var tokenList = new List<string>();

			// App Id
			tokenList.Add(appId);

			// Add Timestamp
			tokenList.Add(timestamp.ToString(CultureInfo.InvariantCulture));

			// Add Nonce
			tokenList.Add(nonce);

			// Add specified tokens
			tokenList.AddRange(tokens);

			// Convert to UPPER CASE and Prepare signature text
			var signatureText = string.Join(string.Empty, tokenList).ToUpperInvariant();

			// Bytes
			var signatureData = Encoding.UTF8.GetBytes(signatureText);
			var hasher = Crosscuttings.CryptoFactory.CreateHasher(new CryptographyHashConfig() { Salt = appKey.ToUpperInvariant() });
			return Convert.ToBase64String(hasher.ComputeHash(signatureData));
		}
	}
}