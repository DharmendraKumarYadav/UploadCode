﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace FRT
{
	/// <summary>
	/// Disposable wrapper
	/// </summary>
	/// <typeparam name="TData">Data type</typeparam>
	public sealed class DisposableWrapper<TData> : IDisposable
	{
		/// <summary>
		/// Before disposing
		/// </summary>
		public event EventHandler OnDisposing;

		// After disposed
		public event EventHandler OnDisposed;

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="data">Wrapping data</param>
		/// <param name="dataDisposer">Data disposer</param>
		[SuppressMessage("Microsoft.Design", "CA1026:DefaultParametersShouldNotBeUsed")]
		public DisposableWrapper(TData data = default(TData), Action<TData, bool> dataDisposer = null)
		{
			IsDisposed = false;
			Data = data;
			Disposer = dataDisposer;
		}

		/// <summary>
		/// Finalizer
		/// </summary>
		~DisposableWrapper()
		{
			Dispose(false);
		}

		/// <summary>
		/// Disposer
		/// </summary>
		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}

		/// <summary>
		/// Disposer
		/// </summary>
		/// <param name="disposing">Whether disposing or finalizing</param>
		private void Dispose(bool disposing)
		{
			// Check disposed
			if (IsDisposed)
			{
				return;
			}

			// Before Disposing
			OnDisposing?.Invoke(this, EventArgs.Empty);

			// Dispose
			if (Disposer != null)
			{
				Disposer(Data, disposing);
			}
			else
			{
				var disposable = Data as IDisposable;
				disposable?.Dispose();
			}

			// Set
			IsDisposed = true;

			// Before Disposing
			OnDisposed?.Invoke(this, EventArgs.Empty);
		}

		/// <summary>
		/// Whether this object is already disposed
		/// </summary>
		public bool IsDisposed
		{
			get;
			private set;
		}

		/// <summary>
		/// Underlying data
		/// </summary>
		public TData Data
		{
			get;
			set;
		}

		/// <summary>
		/// Data disposer
		/// </summary>
		public Action<TData, bool> Disposer
		{
			get;
			set;
		}

		/// <summary>
		/// Converter
		/// </summary>
		/// <param name="wrapper">Wrapper</param>
		[SuppressMessage("Microsoft.Usage", "CA2225:OperatorOverloadsHaveNamedAlternates")]
		public static implicit operator TData(DisposableWrapper<TData> wrapper)
		{
			return (wrapper != null) ? wrapper.Data : default(TData);
		}

		/// <summary>
		/// Converter
		/// </summary>
		/// <param name="data">Data to wrap</param>
		[SuppressMessage("Microsoft.Reliability", "CA2000:Dispose objects before losing scope")]
		[SuppressMessage("Microsoft.Usage", "CA2225:OperatorOverloadsHaveNamedAlternates")]
		public static implicit operator DisposableWrapper<TData>(TData data)
		{
			return (data != null) ? new DisposableWrapper<TData>(data) : null;
		}
	}
}
