﻿using System;

namespace FRT
{
	/// <summary>
	/// TimeZone utilities
	/// </summary>
	public interface ITimeZoneManager
	{
		/// <summary>
		/// Gets the time zone for the given IANA timezone id
		/// </summary>
		/// <param name="ianaId">TimeZone Id</param>
		/// <returns>TimeZone</returns>
		TimeZoneInfo TimeZoneFromIANAId(string ianaId);

		/// <summary>
		/// Gets IANA timezone id from the given timezone
		/// </summary>
		/// <param name="timeZoneInfo">TimeZone</param>
		/// <returns>IANA Id</returns>
		string IANAIdFromTimeZone(TimeZoneInfo timeZoneInfo);
	}
}
