﻿using System;
using System.Linq;

namespace FRT
{
	/// <summary>
	/// TimeZone manager base class
	/// </summary>
	public class TimeZoneManager : ITimeZoneManager
	{
		/// <summary>
		/// Gets the time zone for the given IANA timezone id
		/// </summary>
		/// <param name="ianaId">TimeZone Id</param>
		/// <returns>TimeZone</returns>
		public virtual TimeZoneInfo TimeZoneFromIANAId(string ianaId)
		{
			ianaId = (ianaId ?? string.Empty).Trim();
			if (ianaId.Length == 0)
			{
				return null;
			}

			var tzdbSource = NodaTime.TimeZones.TzdbDateTimeZoneSource.Default;
			var mappings = tzdbSource.WindowsMapping.MapZones;
			var item = mappings.FirstOrDefault(x => x.TzdbIds.Contains(ianaId, StringComparer.OrdinalIgnoreCase));
			string windowsId = null;
			if (item == null)
			{
				// Try other variations
				if (string.Equals(ianaId, "Asia/Kolkata", StringComparison.OrdinalIgnoreCase))
				{
					return TimeZoneFromIANAId("Asia/Calcutta");
				}
				if (string.Equals(ianaId, "Etc/UTC", StringComparison.OrdinalIgnoreCase))
				{
					windowsId = "UTC";
				}
				if (string.Equals(ianaId, "Etc/UCT", StringComparison.OrdinalIgnoreCase))
				{
					windowsId = "UTC";
				}
			}
			else
			{
				windowsId = item.WindowsId;
			}
			if (windowsId == null)
			{
				return null;
			}
			return TimeZoneInfo.FindSystemTimeZoneById(windowsId);
		}

		/// <summary>
		/// Gets IANA timezone id from the given timezone
		/// </summary>
		/// <param name="timeZoneInfo">TimeZone</param>
		/// <returns>IANA Id</returns>
		public virtual string IANAIdFromTimeZone(TimeZoneInfo timeZoneInfo)
		{
			if (timeZoneInfo == null)
			{
				return null;
			}

			var windowsId = timeZoneInfo.Id;
			if (string.Equals(windowsId, "UTC", StringComparison.OrdinalIgnoreCase))
			{
				return "Etc/UTC";
			}
			var tzdbSource = NodaTime.TimeZones.TzdbDateTimeZoneSource.Default;
			var mappings = tzdbSource.WindowsMapping.MapZones;
			var item = mappings.FirstOrDefault(x => string.Equals(x.WindowsId, windowsId, StringComparison.OrdinalIgnoreCase));
			if (item == null)
			{
				// Try other variations
				if (string.Equals(windowsId, "Asia/Calcutta", StringComparison.OrdinalIgnoreCase))
				{
					return IANAIdFromTimeZone(TimeZoneInfo.FindSystemTimeZoneById("Asia/Kolkata"));
				}
				return null;
			}
			return item.TzdbIds.FirstOrDefault();
		}
	}
}
