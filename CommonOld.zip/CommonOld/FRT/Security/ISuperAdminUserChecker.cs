﻿using System.Security.Claims;
using System.Threading.Tasks;

namespace FRT
{
	/// <summary>
	/// Checks if a given user is a super admin
	/// </summary>
	public interface ISuperAdminUserChecker
	{
		/// <summary>
		/// Checks if the given user is a super admin user
		/// </summary>
		/// <param name="user">User</param>
		Task<bool> IsSuperAdminAsync(ClaimsPrincipal user);
	}
}
