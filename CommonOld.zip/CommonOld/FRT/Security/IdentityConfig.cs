﻿using System;

namespace FRT.Security
{
	/// <summary>
	/// Identity configuration
	/// </summary>
	public sealed class IdentityConfig : IInjectableConfig
	{
		/// <summary>
		/// Whether to confirm e-mail addresses
		/// </summary>
		public bool EmailConfirmation
		{
			get;
			set;
		} = true;

		/// <summary>
		/// Whether to confirm phone numbers
		/// </summary>
		public bool PhoneConfirmation
		{
			get;
			set;
		} = true;

		private int _lockoutTimeSeconds = (int) TimeSpan.FromMinutes(30.0).TotalSeconds;
		/// <summary>
		/// Period for which a user is loccked-out, once the lock out happens
		/// </summary>
		public int LockoutTimeSeconds
		{
			get => _lockoutTimeSeconds;
			set => _lockoutTimeSeconds = (value <= 0) ? (int)TimeSpan.FromMinutes(30.0).TotalSeconds : value;
		}

		private int _maxFailedAccessAttempts = 5;
		/// <summary>
		/// Number of failed access attempts after which a user is locked out
		/// </summary>
		public int MaxFailedAccessAttempts
		{
			get => _maxFailedAccessAttempts;
			set => _maxFailedAccessAttempts = (value < 0) ? 5 : value;
		}
	}
}
