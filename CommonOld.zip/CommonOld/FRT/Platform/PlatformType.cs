﻿namespace FRT
{
	/// <summary>
	/// Platform type
	/// </summary>
	public enum PlatformType
	{
		Unknown,
		Web,
		Azure,
		Android,
		IOS,
		UWP,
		Desktop
	}
}
