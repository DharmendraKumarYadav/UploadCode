﻿using System;
using System.Reflection;
using System.Text.RegularExpressions;

namespace FRT
{
	/// <summary>
	/// Platform specific functionality
	/// </summary>
	public interface IPlatform
	{
		#region Information

		/// <summary>
		/// Platform type
		/// </summary>
		PlatformType Type { get; }

		#endregion

		#region Assemblies

		/// <summary>
		/// Returns the names of all assemblies in the application folder
		/// </summary>
		Assembly[] GetAllAssemblies();

		/// <summary>
		/// Gets the referenced assembly names for the specified assembly
		/// </summary>
		/// <param name="assembly">Assembly</param>
		/// <returns>Referenced assembly names</returns>
		AssemblyName[] GetReferencedAssemblies(Assembly assembly);

		/// <summary>
		/// Returns the file path of the assembly
		/// </summary>
		/// <param name="assembly">Assembly</param>
		/// <returns>Assembly file path</returns>
		string GetAssemblyFilePath(Assembly assembly);

		#endregion

		#region Regex

		/// <summary>
		/// Creates a regex expression
		/// </summary>
		/// <param name="pattern">Regex pattern</param>
		Regex CreateRegex(string pattern);

		/// <summary>
		/// Creates a regex expression
		/// </summary>
		/// <param name="pattern">Regex pattern</param>
		/// <param name="options">Options</param>
		/// <param name="compiled">Whether compiled</param>
		Regex CreateRegex(string pattern, RegexOptions options, bool compiled = false);

		/// <summary>
		/// Creates a regex expression
		/// </summary>
		/// <param name="pattern">Regex pattern</param>
		/// <param name="options">Options</param>
		/// <param name="compiled">Whether compiled</param>
		/// <param name="matchTimeout">Timeout for finding a match</param>
		Regex CreateRegex(string pattern, RegexOptions options, bool compiled, TimeSpan matchTimeout);

		#endregion

		#region Diagnostics

		/// <summary>
		/// Creates stack trace frames from a given exception
		/// </summary>
		/// <param name="exception">Exception</param>
		/// <returns>Stack frames</returns>
		StackFrameModel[] GetStackFramesFromException(Exception exception);

		#endregion
	}
}
