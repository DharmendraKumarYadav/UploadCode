﻿using Microsoft.Extensions.DependencyInjection;
using AutoMapper;
using CacheManager.Core;
using FRT.Caching;
using FRT.Cryptography;
using FRT.Messaging;
using FRT.Security;
using FRT.Serialization;
using FRT.Validation;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace FRT
{
	/// <summary>
	/// Global access to cross-cutting services
	/// </summary>
	public static class Crosscuttings
	{
		#region Configurations

		/// <summary>
		/// Configuration
		/// </summary>
		public static IOptions<AppInformationConfig> AppInformationConfigOptions
			=> DI.Container.GetService<IOptions<AppInformationConfig>>();

		/// <summary>
		/// Configuration
		/// </summary>
		public static IOptions<CryptographySymmetricConfig> CryptographySymmetricConfigOptions
			=> DI.Container.GetService<IOptions<CryptographySymmetricConfig>>();

		/// <summary>
		/// Configuration
		/// </summary>
		public static IOptions<CryptographyHashConfig> CryptographyHashConfigOptions
			=> DI.Container.GetService<IOptions<CryptographyHashConfig>>();

		/// <summary>
		/// Configuration
		/// </summary>
		public static IOptions<MessagingConfig> MessagingConfigConfig
			=> DI.Container.GetService<IOptions<MessagingConfig>>();

		/// <summary>
		/// Configuration
		/// </summary>
		public static IOptions<MessagingTemplatesConfig> MessagingTemplatesConfigOptions
			=> DI.Container.GetService<IOptions<MessagingTemplatesConfig>>();

		/// <summary>
		/// Configuration
		/// </summary>
		public static IOptions<SmtpEmailConfig> SmtpEmailConfigOptions
			=> DI.Container.GetService<IOptions<SmtpEmailConfig>>();

		/// <summary>
		/// Configuration
		/// </summary>
		public static IOptions<TwilioSmsConfig> TwilioSmsConfigOptions
			=> DI.Container.GetService<IOptions<TwilioSmsConfig>>();

		/// <summary>
		/// Configuration
		/// </summary>
		public static IOptions<IdentityConfig> IdentityConfigOptions
			=> DI.Container.GetService<IOptions<IdentityConfig>>();

		/// <summary>
		/// Configuration
		/// </summary>
		public static IOptions<SerializationConfig> SerializationConfigOptions
			=> DI.Container.GetService<IOptions<SerializationConfig>>();

		/// <summary>
		/// Configuration
		/// </summary>
		public static IOptions<ValidationConfig> ValidationConfigOptions
			=> DI.Container.GetService<IOptions<ValidationConfig>>();

		#endregion

		#region Services

		/// <summary>
		/// Mapper
		/// </summary>
		public static IMapper Mapper
			=> DI.Container.GetService<IMapper>();

		/// <summary>
		/// TimeZone manager
		/// </summary>
		public static ITimeZoneManager TimeZoneManager
			=> DI.Container.GetService<ITimeZoneManager>();

		/// <summary>
		/// Validator
		/// </summary>
		public static IValidationManager ValidationManager
			=> DI.Container.GetService<IValidationManager>();

		/// <summary>
		/// Logger factory
		/// </summary>
		public static ILoggerFactory LoggerFactory
			=> DI.Container.GetService<ILoggerFactory>();

		/// <summary>
		/// Application logger
		/// </summary>
		public static ILogger Logger
			=> LoggerFactory.CreateLogger("Application");

		/// <summary>
		/// Returns the logger specific to the type
		/// </summary>
		public static ILogger<TType> GetTypedLogger<TType>()
		{
			return DI.Container.GetService<ILogger<TType>>();
		}

		/// <summary>
		/// Cache service
		/// </summary>
		public static ICacheManager<object> Cache
			=> DI.Container.GetService<ICacheManager<object>>();

		/// <summary>
		/// Crypto factory
		/// </summary>
		public static ICryptoFactory CryptoFactory => DI.Container.GetService<ICryptoFactory>();

		/// <summary>
		/// Default symmetric cryptographer
		/// </summary>
		public static ISymmetricCryptographer SymmetricCryptographer => DI.Container.GetService<ISymmetricCryptographer>();

		/// <summary>
		/// Default asymmetric cryptographer
		/// </summary>
		public static IAsymmetricCryptographer AsymmetricCryptographer => DI.Container.GetService<IAsymmetricCryptographer>();

		/// <summary>
		/// Default hasher
		/// </summary>
		public static IHasher Hasher => DI.Container.GetService<IHasher>();

		/// <summary>
		/// E-mail service
		/// </summary>
		public static IEmailService Email
			=> DI.Container.GetService<IEmailService>();

		/// <summary>
		/// Sms service
		/// </summary>
		public static ISmsService Sms
			=> DI.Container.GetService<ISmsService>();

		/// <summary>
		/// Super admin checker
		/// </summary>
		public static ISuperAdminUserChecker SuperAdminUserChecker
			=> DI.Container.GetService<ISuperAdminUserChecker>();

		#endregion
	}
}
