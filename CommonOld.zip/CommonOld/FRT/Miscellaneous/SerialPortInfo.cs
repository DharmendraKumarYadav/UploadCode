﻿namespace FRT
{
	/// <summary>
	/// Port information
	/// </summary>
	public sealed class SerialPortInfo
	{
		/// <summary>
		/// Constructor
		/// </summary>
		public SerialPortInfo(string port = null, int baudRate = 9600)
		{
			Port = port;
			BaudRate = baudRate;
		}

		private string _port;
		/// <summary>
		/// Port
		/// </summary>
		public string Port
		{
			get => _port;
			set => _port = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		/// <summary>
		/// Baud rate
		/// </summary>
		public int BaudRate
		{
			get;
			set;
		}

		private string _description;
		/// <summary>
		/// Description
		/// </summary>
		public string Description
		{
			get => _description;
			set => _description = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}
	}
}
