﻿using System;
using System.Reflection;
using System.Text;

namespace FRT
{
	/// <summary>
	/// Stack frame data for PCL libraries
	/// </summary>
	public sealed class StackFrameModel
	{
		/// <summary>
		/// Name of the method
		/// </summary>
		public MethodBase Method
		{
			get;
			set;
		}

		/// <summary>
		/// Offset in the method
		/// </summary>
		public int Offset
		{
			get;
			set;
		} = -1;

		private string _file;
		/// <summary>
		/// File name
		/// </summary>
		public string File
		{
			get => _file;
			set => _file = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		/// <summary>
		/// Line number in the file
		/// </summary>
		public int Line
		{
			get;
			set;
		}

		/// <summary>
		/// Column number
		/// </summary>
		public int Column
		{
			get;
			set;
		}

		/// <summary>
		/// String conversion
		/// </summary>
		/// <returns></returns>
		public override string ToString()
		{
			StringBuilder builder = new StringBuilder();
			if (Method != null)
			{
				builder.Append(Method.Name);

				var methodInfo = Method as MethodInfo;
				if ((methodInfo != null) && methodInfo.IsGenericMethod)
				{
					Type[] genericArguments = methodInfo.GetGenericArguments();
					builder.Append("<");

					int index = 0;
					bool flag2 = true;
					while (index < genericArguments.Length)
					{
						if (!flag2)
						{
							builder.Append(",");
						}
						else
						{
							flag2 = false;
						}
						builder.Append(genericArguments[index].Name);
						index++;
					}
					builder.Append(">");
				}

				builder.Append(" at offset ");
				if (Offset == -1)
				{
					builder.Append("<offset unknown>");
				}
				else
				{
					builder.Append(Offset);
				}

				builder.Append(" in file:line:column ");
				builder.Append(File ?? "<filename unknown>");

				builder.Append(":");
				builder.Append(Line);

				builder.Append(":");
				builder.Append(Column);
			}
			else
			{
				builder.Append("<null>");
			}

			builder.Append(Environment.NewLine);
			return builder.ToString();
		}
	}
}
