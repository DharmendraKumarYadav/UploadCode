﻿using System.Diagnostics.CodeAnalysis;

namespace FRT
{
	/// <summary>
	/// Claim object config
	/// </summary>
	public class ClaimConfig
	{
		private string _type;
		/// <summary>
		/// Claim type
		/// </summary>
		[SuppressMessage("Microsoft.Naming", "CA1721:PropertyNamesShouldNotMatchGetMethods")]
		public string Type
		{
			get => _type;
			set => _type = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private string _value;
		/// <summary>
		/// Claim value
		/// </summary>
		public string Value
		{
			get => _value;
			set => _value = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private string _valueType;
		/// <summary>
		/// Claim value type
		/// </summary>
		public string ValueType
		{
			get => _valueType;
			set => _valueType = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private string _issuer;
		/// <summary>
		/// Claim issuer
		/// </summary>
		public string Issuer
		{
			get => _issuer;
			set => _issuer = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private string _originalIssuer;
		/// <summary>
		/// Claim original issuer
		/// </summary>
		public string OriginalIssuer
		{
			get => _originalIssuer;
			set => _originalIssuer = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}
	}
}
