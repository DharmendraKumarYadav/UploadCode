﻿namespace FRT
{
	/// <summary>
	/// Gender
	/// </summary>
	public enum Gender
	{
		Unspecified,
		Male,
		Female
	}
}
