﻿using System;

namespace FRT
{
	/// <summary>
	/// DbFileServer
	/// </summary>
	public static class DbFileServer
	{
		public const string TokenAction = "DbBFS";
		public const string BaseUrl = "/dbs";

		/// <summary>
		/// Returns the url for the resource
		/// </summary>
		/// <param name="expiryTime">Expiry time span</param>
		/// <param name="tableName">Table name</param>
		/// <param name="idColumnName">Identity column name</param>
		/// <param name="idValue">Id value of the record</param>
		/// <param name="contentColumnName">Content column name</param>
		/// <param name="mimeColumnName">Mime column name</param>
		/// <param name="asAttachment">Whether to be served as an attachment</param>
		/// <param name="fileNameColumnName">File name column name - applicable in attachment mode</param>
		/// <returns></returns>
		public static string GetDbResourceUrl(TimeSpan? expiryTime, string tableName, string idColumnName, object idValue,
			string contentColumnName, string mimeColumnName, bool asAttachment = false, string fileNameColumnName = null)
		{
			if (string.IsNullOrWhiteSpace(tableName))
			{
				throw new ArgumentNullException(nameof(tableName));
			}
			if (string.IsNullOrWhiteSpace(idColumnName))
			{
				throw new ArgumentNullException(nameof(idColumnName));
			}
			if (idValue == null)
			{
				throw new ArgumentNullException(nameof(idValue));
			}
			if (string.IsNullOrWhiteSpace(contentColumnName))
			{
				throw new ArgumentNullException(nameof(contentColumnName));
			}
			if (string.IsNullOrWhiteSpace(mimeColumnName))
			{
				throw new ArgumentNullException(nameof(mimeColumnName));
			}
			tableName = tableName.Trim();
			idColumnName = idColumnName.Trim();
			contentColumnName = contentColumnName.Trim();
			mimeColumnName = mimeColumnName.Trim();
			fileNameColumnName = string.IsNullOrWhiteSpace(fileNameColumnName) ? null : fileNameColumnName.Trim();

			// Create token
			return Url.AppendQueryParameters(BaseUrl, new
			{
				// ReSharper disable once RedundantExplicitParamsArrayCreation
				t = TokenUtil.CreateToken(TokenAction, expiryTime, new[]
				{
					tableName,
					idColumnName,
					idValue.GetType().AssemblyQualifiedName,
					idValue.ToString(),
					contentColumnName,
					mimeColumnName,
					asAttachment.ToString(),
					fileNameColumnName
				})
			});
		}
	}
}
