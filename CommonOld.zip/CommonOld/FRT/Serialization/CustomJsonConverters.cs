﻿using System;
using System.Diagnostics.CodeAnalysis;
using Newtonsoft.Json;

namespace FRT.Serialization
{
#pragma warning disable CS0649
	/// <summary>
	/// Internal serializable class
	/// </summary>
	internal sealed class ClaimLite
	{
		public string Type;
		public string Value;
		public string ValueType;
		public string Issuer;
		public string OriginalIssuer;
	}

	/// <summary>
	/// Internal serializable class
	/// </summary>
	internal sealed class ClaimsIdentityLite
	{
		public string AuthenticationType;
		public ClaimLite[] Claims;
		public string NameClaimType;
		public string RoleClaimType;
	}

	/// <summary>
	/// Internal serializable class
	/// </summary>
	internal sealed class ClaimsPrincipalLite
	{
		public ClaimsIdentityLite[] Identities;
	}
#pragma warning restore CS0649

	/// <summary>
	/// Custom Json Converters
	/// </summary>
	public static class CustomJsonConverters
	{
		/// <summary>
		/// Returns all custom json converters
		/// </summary>
		[SuppressMessage("Microsoft.Performance", "CA1819:PropertiesShouldNotReturnArrays")]
		public static JsonConverter[] All => new JsonConverter[]
		{
			new CustomClaimJsonConverter(),
			new CustomClaimsIdentityJsonConverter(),
			new CustomClaimsPrincipalJsonConverter()
		};
	}

	/// <summary>
	/// Claim converter
	/// </summary>
	internal sealed class CustomClaimJsonConverter : JsonConverter
	{
		#region Overrides of JsonConverter
		/// <summary>
		/// Determines whether this instance can convert the specified object type.
		/// </summary>
		/// <param name="objectType">Type of the object.</param>
		/// <returns>
		/// <c>true</c> if this instance can convert the specified object type; otherwise, <c>false</c>.
		/// </returns>
		public override bool CanConvert(Type objectType)
		{
			return objectType?.FullName == "System.Security.Claims.Claim";
		}

		/// <summary>
		/// Writes the JSON representation of the object.
		/// </summary>
		/// <param name="writer">The <see cref="T:Newtonsoft.Json.JsonWriter"/> to write to.</param><param name="value">The value.</param><param name="serializer">The calling serializer.</param>
		public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
		{
			// Object
			var isClaim = value?.GetType()?.FullName == "System.Security.Claims.Claim";
			if (!isClaim)
			{
				writer?.WriteNull();
			}
			else
			{
				// Object
				var obj = Crosscuttings.Mapper.Map(value, new ClaimLite());

				// Write
				serializer?.Serialize(writer, obj);
			}
		}

		/// <summary>
		/// Reads the JSON representation of the object.
		/// </summary>
		/// <param name="reader">The <see cref="T:Newtonsoft.Json.JsonReader"/> to read from.</param><param name="objectType">Type of the object.</param><param name="existingValue">The existing value of object being read.</param><param name="serializer">The calling serializer.</param>
		/// <returns>
		/// The object value.
		/// </returns>
		public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
		{
			// Check null
			if ((reader?.TokenType == JsonToken.Null)
				|| (serializer == null))
			{
				return null;
			}

			// Deserialize
			var obj = serializer.Deserialize<ClaimLite>(reader);
			return Activator.CreateInstance(objectType, obj.Type, obj.Value, obj.ValueType, obj.Issuer, obj.OriginalIssuer);
		}
		#endregion
	}

	/// <summary>
	/// Claim converter
	/// </summary>
	internal sealed class CustomClaimsIdentityJsonConverter : JsonConverter
	{
		#region Overrides of JsonConverter
		/// <summary>
		/// Determines whether this instance can convert the specified object type.
		/// </summary>
		/// <param name="objectType">Type of the object.</param>
		/// <returns>
		/// <c>true</c> if this instance can convert the specified object type; otherwise, <c>false</c>.
		/// </returns>
		public override bool CanConvert(Type objectType)
		{
			return objectType?.FullName == "System.Security.Claims.ClaimsIdentity";
		}

		/// <summary>
		/// Writes the JSON representation of the object.
		/// </summary>
		/// <param name="writer">The <see cref="T:Newtonsoft.Json.JsonWriter"/> to write to.</param><param name="value">The value.</param><param name="serializer">The calling serializer.</param>
		public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
		{
			// Object
			var isClaimsIdentity = value?.GetType()?.FullName == "System.Security.Claims.ClaimsIdentity";
			if (!isClaimsIdentity)
			{
				writer?.WriteNull();
			}
			else
			{
				// Object
				var obj = Crosscuttings.Mapper.Map(value, new ClaimsIdentityLite());

				// Write
				serializer?.Serialize(writer, obj);
			}
		}

		/// <summary>
		/// Reads the JSON representation of the object.
		/// </summary>
		/// <param name="reader">The <see cref="T:Newtonsoft.Json.JsonReader"/> to read from.</param><param name="objectType">Type of the object.</param><param name="existingValue">The existing value of object being read.</param><param name="serializer">The calling serializer.</param>
		/// <returns>
		/// The object value.
		/// </returns>
		public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
		{
			// Check null
			if ((reader?.TokenType == JsonToken.Null)
				|| (serializer == null))
			{
				return null;
			}

			// Deserialize
			var obj = serializer.Deserialize<ClaimsIdentityLite>(reader);
			return Activator.CreateInstance(objectType, obj.Claims, obj.AuthenticationType, obj.NameClaimType, obj.RoleClaimType);
		}
		#endregion
	}


	/// <summary>
	/// Claim converter
	/// </summary>
	internal sealed class CustomClaimsPrincipalJsonConverter : JsonConverter
	{
		#region Overrides of JsonConverter
		/// <summary>
		/// Determines whether this instance can convert the specified object type.
		/// </summary>
		/// <param name="objectType">Type of the object.</param>
		/// <returns>
		/// <c>true</c> if this instance can convert the specified object type; otherwise, <c>false</c>.
		/// </returns>
		public override bool CanConvert(Type objectType)
		{
			return objectType?.FullName == "System.Security.Claims.ClaimsPrincipal";
		}

		/// <summary>
		/// Writes the JSON representation of the object.
		/// </summary>
		/// <param name="writer">The <see cref="T:Newtonsoft.Json.JsonWriter"/> to write to.</param><param name="value">The value.</param><param name="serializer">The calling serializer.</param>
		public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
		{
			// Object
			var isClaimsIdentity = value?.GetType()?.FullName == "System.Security.Claims.ClaimsPrincipal";
			if (!isClaimsIdentity)
			{
				writer?.WriteNull();
			}
			else
			{
				var obj = Crosscuttings.Mapper.Map(value, new ClaimsPrincipalLite());

				// Write
				serializer?.Serialize(writer, obj);
			}
		}

		/// <summary>
		/// Reads the JSON representation of the object.
		/// </summary>
		/// <param name="reader">The <see cref="T:Newtonsoft.Json.JsonReader"/> to read from.</param><param name="objectType">Type of the object.</param><param name="existingValue">The existing value of object being read.</param><param name="serializer">The calling serializer.</param>
		/// <returns>
		/// The object value.
		/// </returns>
		public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
		{
			// Check null
			if ((reader?.TokenType == JsonToken.Null)
				|| (serializer == null))
			{
				return null;
			}

			// Deserialize
			var obj = serializer.Deserialize<ClaimsPrincipalLite>(reader);
			// ReSharper disable once CoVariantArrayConversion
			return Activator.CreateInstance(objectType, obj.Identities);
		}
		#endregion
	}
}
