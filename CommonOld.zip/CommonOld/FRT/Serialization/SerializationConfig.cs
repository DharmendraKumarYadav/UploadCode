﻿namespace FRT.Serialization
{
	/// <summary>
	/// Serialization Configuration
	/// </summary>
	public sealed class SerializationConfig : IInjectableConfig
	{
	}
}
