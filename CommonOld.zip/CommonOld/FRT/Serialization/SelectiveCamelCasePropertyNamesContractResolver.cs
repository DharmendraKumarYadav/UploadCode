﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reflection;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace FRT.Serialization
{
	/// <summary>
	/// Selective camel case property names resolver
	/// http://www.strathweb.com/2014/11/formatters-asp-net-mvc-6/
	/// </summary>
	public class SelectiveCamelCasePropertyNamesContractResolver : DefaultContractResolver
	{
		[ThreadStatic]
		private static bool _callContextCamelCaseProperties;
		[ThreadStatic]
		private static Type _callContextCurrentType;

		#region Properties
		private bool? _camelCaseProperties;
		/// <summary>
		/// Turn property names into camel case
		/// </summary>
		public bool CamelCaseProperties
		{
			get
			{
				if (_camelCaseProperties.HasValue)
				{
					return _camelCaseProperties.Value;
				}
				else
				{
					return _callContextCamelCaseProperties;
				}
			}
			set => _camelCaseProperties = value;
		}

		private List<Assembly> _camelCaseTypeAssemblies = new List<Assembly>();
		/// <summary>
		/// Assemblies to include for camel casing
		/// </summary>
		[SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		public virtual IList<Assembly> CamelCaseTypeAssemblies
		{
			get => _camelCaseTypeAssemblies;
			set => _camelCaseTypeAssemblies = (value ?? new List<Assembly>()).Where(p => p != null).Distinct().ToList();
		}

		private List<Type> _camelCaseTypes = new List<Type>();
		/// <summary>
		/// Types to include for camel casing
		/// </summary>
		[SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		public virtual IList<Type> CamelCaseTypes
		{
			get => _camelCaseTypes;
			set => _camelCaseTypes = (value ?? new List<Type>()).Where(p => p != null).Distinct().ToList();
		}

		/// <summary>
		/// Assembly selector
		/// </summary>
		public virtual Func<Assembly[]> CamelCaseTypeAssemblySelector
		{
			get;
			set;
		}
		#endregion

		#region Helpers
		/// <summary>
		/// Sets the camel casing for this call context and returns a disposable
		/// to reset the setting back
		/// </summary>
		/// <param name="camelCase">Whether to turn-on the camel casing</param>
		/// <returns>Disposable to reset the setting back</returns>
		public static IDisposable SetSerializerCamelCasing(bool camelCase = true)
		{
			// Set
			_callContextCamelCaseProperties = camelCase;

			// Unset callback
			// ReSharper disable once ConvertToLocalFunction
			Action<bool> resetContext = d =>
			{
				_callContextCamelCaseProperties = false;
			};

			// Return
			return new DisposableAction(resetContext);
		}

		/// <summary>
		/// Default Json Serializer Settings
		/// http://www.strathweb.com/2014/11/formatters-asp-net-mvc-6/
		/// </summary>
		public static SelectiveCamelCasePropertyNamesContractResolver ApplyDefaultSettings(JsonSerializerSettings serializerSettings,
			bool camelCaseProperties = true)
		{
			if (serializerSettings == null)
			{
				throw new ArgumentNullException(nameof(serializerSettings));
			}

			// Set Resolver
			var resolver = new SelectiveCamelCasePropertyNamesContractResolver();
			serializerSettings.ContractResolver = resolver;

			// Camel Case
			if (camelCaseProperties)
			{
				resolver.CamelCaseProperties = true;
			}

			// Return
			return resolver;
		}
		#endregion

		#region Implementation
		/// <summary>
		/// Cache of assemblies from the selector
		/// </summary>
		private Assembly[] _camelCaseTypeAssemblySelectorAssemblies;

		/// <summary>
		/// Assemblies from the selector
		/// </summary>
		private Assembly[] GetCamelCaseTypeAssemblySelectorAssemblies()
		{
			return (CamelCaseTypeAssemblySelector != null)
				? (_camelCaseTypeAssemblySelectorAssemblies ??
						(_camelCaseTypeAssemblySelectorAssemblies = (CamelCaseTypeAssemblySelector() ?? new Assembly[0])))
				: new Assembly[0];
		}

		/// <summary>
		/// Configures the property
		/// </summary>
		/// <param name="member">Member info</param>
		/// <param name="property">Property</param>
		[SuppressMessage("Microsoft.Naming", "CA1716:IdentifiersShouldNotMatchKeywords", MessageId = "Property")]
		protected virtual void ConfigureProperty(MemberInfo member, JsonProperty property)
		{
			if (property == null)
			{
				throw new ArgumentNullException(nameof(property));
			}
			if (IsRequiredMember(member))
			{
				property.Required = Required.AllowNull;
				property.DefaultValueHandling = 0;
				property.NullValueHandling = 0;
			}
			else
			{
				property.Required = Required.Default;
			}
		}

		/// <summary>
		/// Checks if a member is a required member
		/// </summary>
		/// <param name="memberInfo">Member info</param>
		/// <returns></returns>
		protected virtual bool IsRequiredMember(MemberInfo memberInfo)
		{
			return false;
		}

		/// <summary>
		/// Creates a property on the specified class by using the specified parameters.
		/// </summary>
		/// <param name="member">The member info.</param>
		/// <param name="memberSerialization">The member serialization.</param>
		/// <returns>A Newtonsoft.Json.Serialization.JsonProperty to create on the specified class
		/// by using the specified parameters.</returns>
		protected override JsonProperty CreateProperty(MemberInfo member, MemberSerialization memberSerialization)
		{
			try
			{
				// Current Type
				if (member != null)
				{
					_callContextCurrentType = member.DeclaringType;
				}

				// base
				var property = base.CreateProperty(member, memberSerialization);

				// Configure
				ConfigureProperty(member, property);

				// Apply Json Property name if specified by the attribute
				var attr = member.GetCustomAttributes<JsonPropertyAttribute>(true).FirstOrDefault();
				if ((attr != null) && (property.PropertyName != null))
				{
					property.PropertyName = attr.PropertyName;
				}

				// Return
				return property;
			}
			finally
			{
				_callContextCurrentType = null;
			}
		}

		/// <summary>
		/// Create dictionary contract
		/// </summary>
		/// <param name="objectType">Object type</param>
		/// <returns>Contract</returns>
		protected override JsonDictionaryContract CreateDictionaryContract(Type objectType)
		{
			try
			{
				// Current Type
				_callContextCurrentType = objectType;

				// base
				return base.CreateDictionaryContract(objectType);
			}
			finally
			{
				_callContextCurrentType = null;
			}
		}

		/// <summary>
		/// Creates contract for dynamic types
		/// </summary>
		/// <param name="objectType">Object type</param>
		/// <returns>Contract</returns>
		protected override JsonDynamicContract CreateDynamicContract(Type objectType)
		{
			try
			{
				// Current Type
				_callContextCurrentType = objectType;

				// base
				return base.CreateDynamicContract(objectType);
			}
			finally
			{
				_callContextCurrentType = null;
			}
		}

		/// <summary>
		/// Creates contract for a property from constructor parameter
		/// </summary>
		/// <param name="matchingMemberProperty">Matching member property</param>
		/// <param name="parameterInfo">Constructor parameter</param>
		/// <returns>Contract</returns>
		[SuppressMessage("Microsoft.Design", "CA1062:Validate arguments of public methods", MessageId = "0")]
		protected override JsonProperty CreatePropertyFromConstructorParameter(JsonProperty matchingMemberProperty,
			ParameterInfo parameterInfo)
		{
			if (matchingMemberProperty?.PropertyType == null)
			{
				// base
				return base.CreatePropertyFromConstructorParameter(matchingMemberProperty, parameterInfo);
			}
			try
			{
				// Current Type
				_callContextCurrentType = matchingMemberProperty.PropertyType.DeclaringType;

				// base
				return base.CreatePropertyFromConstructorParameter(matchingMemberProperty, parameterInfo);
			}
			finally
			{
				_callContextCurrentType = null;
			}
		}

		/// <summary>
		/// Resolves the specified property name to Json equivalent
		/// </summary>
		/// <param name="propertyName">Property name</param>
		/// <returns>Json equivalent of the property name</returns>
		[SuppressMessage("Microsoft.Globalization", "CA1308:NormalizeStringsToUppercase")]
		protected override string ResolvePropertyName(string propertyName)
		{
			if (string.IsNullOrWhiteSpace(propertyName))
			{
				return propertyName;
			}

			// If not camel casing, return the property name itself
			if (!CamelCaseProperties)
			{
				return base.ResolvePropertyName(propertyName);
			}
			propertyName = propertyName.Trim();

			// If there are no filters, camel case all
			var camelCase = true;

			// If there are filters, check
			var camelCaseAssemblies = GetCamelCaseTypeAssemblySelectorAssemblies().Concat(CamelCaseTypeAssemblies).ToList();
			if ((CamelCaseTypes.Count != 0)
				|| (camelCaseAssemblies.Count != 0))
			{
				// Get the current type
				var currentType = _callContextCurrentType;
				var currentTypeAssembly = currentType?.GetTypeInfo()?.Assembly;

				// When there are filters, camel casing is off
				camelCase = false;

				// Check type
				if (CamelCaseTypes.Count > 0)
				{
					camelCase = (currentType != null) && CamelCaseTypes.Contains(currentType);
				}
				if (!camelCase && (camelCaseAssemblies.Count > 0))
				{
					camelCase = (currentTypeAssembly != null) && camelCaseAssemblies.Contains(currentTypeAssembly);
				}
			}

			return camelCase
				? propertyName.Substring(0, 1).ToLowerInvariant() + propertyName.Substring(1)
				: propertyName;
		}
		#endregion
	}
}
