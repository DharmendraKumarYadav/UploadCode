﻿using System;
using System.Diagnostics.CodeAnalysis;
using AutoMapper.Configuration;

namespace FRT
{
	/// <summary>
	/// App mapper overrides
	/// </summary>
	public interface IAppMapper
	{
		/// <summary>
		/// Creates a custom mapping for the specified types
		/// </summary>
		/// <typeparam name="TType1">Type 1</typeparam>
		/// <typeparam name="TType2">Type 2</typeparam>
		/// <param name="configuration">Configuration object</param>
		/// <returns>True if a map is created. False to use the default configuration for the types</returns>
		[SuppressMessage("Microsoft.Design", "CA1004:GenericMethodsShouldProvideTypeParameter")]
		bool CreateMap<TType1, TType2>(MapperConfigurationExpression configuration);

		/// <summary>
		/// Creates a custom mapping for the specified types
		/// </summary>
		/// <param name="configuration">Configuration object</param>
		/// <param name="type1">Type 1</param>
		/// <param name="type2">Type 2</param>
		/// <returns>True if a map is created. False to use the default configuration for the types</returns>
		bool CreateMap(MapperConfigurationExpression configuration, Type type1, Type type2);
	}
}
