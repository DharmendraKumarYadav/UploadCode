﻿using System;
using System.Collections.Generic;
using System.Globalization;
using AutoMapper;
using AutoMapper.Configuration;
// ReSharper disable RedundantTypeArgumentsOfMethod

namespace FRT
{
	/// <summary>
	/// Mapper wrapper
	/// </summary>
	public sealed class ObjectMapper : IMapper
	{
		private readonly IAppMapper _appMapper;
		private readonly MapperConfigurationExpression _configExpression;
		private readonly Dictionary<string, bool> _mapInfo;

		/// <summary>
		/// Constructor
		/// </summary>
		public ObjectMapper(IAppMapper appMapper)
		{
			_appMapper = appMapper;
			_mapInfo = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
			_configExpression = new MapperConfigurationExpression();
			Mapper.Initialize(_configExpression);
		}

		/// <summary>
		/// Mapper configuration
		/// </summary>
		public MapperConfigurationExpression Configuration => _configExpression;

		#region Helpers
		/// <summary>
		/// Ensures a map exists between the given types
		/// </summary>
		/// <typeparam name="TType1">Type 1</typeparam>
		/// <typeparam name="TType2">Type 2</typeparam>
		private void EnsureMap<TType1, TType2>()
		{
			EnsureMap(typeof(TType1), typeof(TType2));
		}

		/// <summary>
		/// Ensures a map exists between the given types
		/// </summary>
		private void EnsureMap(Type type1, Type type2)
		{
			var infoKey1 = string.Format(CultureInfo.InvariantCulture, "{0}$$${1}", type1, type2);
			var infoKey2 = string.Format(CultureInfo.InvariantCulture, "{0}$$${1}", type2, type1);
			lock (_mapInfo)
			{
				// Check if already mapped
				bool infoValue;
				if (_mapInfo.TryGetValue(infoKey1, out infoValue) || _mapInfo.TryGetValue(infoKey2, out infoValue))
				{
					return;
				}

				// Map now
				infoValue = _appMapper.CreateMap(_configExpression, type1, type2);
				if (!infoValue)
				{
					// Create default
					_configExpression.CreateMap(type1, type2).ReverseMap();
				}
				_mapInfo[infoKey1] = infoValue;
				_mapInfo[infoKey2] = infoValue;
				Mapper.Initialize(_configExpression);
			}
		}
		#endregion

		#region Overrides

		/// <inheritdoc />
		public TDestination Map<TDestination>(object source)
		{
			if (source == null)
			{
				return default(TDestination);
			}
			EnsureMap(source.GetType(), typeof(TDestination));
			return Mapper.Instance.Map<TDestination>(source);
		}

		/// <inheritdoc />
		public TDestination Map<TDestination>(object source, Action<IMappingOperationOptions> opts)
		{
			if (source == null)
			{
				return default(TDestination);
			}
			EnsureMap(source.GetType(), typeof(TDestination));
			return Mapper.Instance.Map<TDestination>(source, opts);
		}

		/// <inheritdoc />
		public TDestination Map<TSource, TDestination>(TSource source)
		{
			EnsureMap<TSource, TDestination>();
			return Mapper.Instance.Map<TSource, TDestination>(source);
		}

		/// <inheritdoc />
		public TDestination Map<TSource, TDestination>(TSource source, Action<IMappingOperationOptions<TSource, TDestination>> opts)
		{
			EnsureMap<TSource, TDestination>();
			return Mapper.Instance.Map<TSource, TDestination>(source, opts);
		}

		/// <inheritdoc />
		public TDestination Map<TSource, TDestination>(TSource source, TDestination destination)
		{
			EnsureMap<TSource, TDestination>();
			return Mapper.Instance.Map<TSource, TDestination>(source, destination);
		}

		/// <inheritdoc />
		public TDestination Map<TSource, TDestination>(TSource source, TDestination destination, Action<IMappingOperationOptions<TSource, TDestination>> opts)
		{
			EnsureMap<TSource, TDestination>();
			return Mapper.Instance.Map<TSource, TDestination>(source, destination, opts);
		}

		/// <inheritdoc />
		public object Map(object source, Type sourceType, Type destinationType)
		{
			EnsureMap(sourceType, destinationType);
			return Mapper.Instance.Map(source, sourceType, destinationType);
		}

		/// <inheritdoc />
		public object Map(object source, Type sourceType, Type destinationType, Action<IMappingOperationOptions> opts)
		{
			EnsureMap(sourceType, destinationType);
			return Mapper.Instance.Map(source, sourceType, destinationType, opts);
		}

		/// <inheritdoc />
		public object Map(object source, object destination, Type sourceType, Type destinationType)
		{
			EnsureMap(sourceType, destinationType);
			return Mapper.Instance.Map(source, destination, sourceType, destinationType);
		}

		/// <inheritdoc />
		public object Map(object source, object destination, Type sourceType, Type destinationType, Action<IMappingOperationOptions> opts)
		{
			EnsureMap(sourceType, destinationType);
			return Mapper.Instance.Map(source, destination, sourceType, destinationType, opts);
		}

		/// <inheritdoc />
		public IConfigurationProvider ConfigurationProvider => Mapper.Instance.ConfigurationProvider;

		/// <inheritdoc />
		public Func<Type, object> ServiceCtor => Mapper.Instance.ServiceCtor;

		#endregion
	}
}
