﻿using System;
using Microsoft.Extensions.DependencyInjection;

namespace FRT
{
	/// <summary>
	/// Dependency Injection Manager
	/// </summary>
	public static class DI
	{
		/// <summary>
		/// Registrar
		/// </summary>
		public static IServiceCollection Registrar
		{
			get;
			set;
		}

		/// <summary>
		/// Container
		/// </summary>
		public static IServiceProvider Container
		{
			get;
			set;
		}

		/// <summary>
		/// Global platform
		/// </summary>
		public static IPlatform Platform
		{
			get;
			set;
		}
	}
}
