﻿using System;
using Microsoft.Extensions.Logging;

namespace FRT
{
	/// <summary>
	/// Typed logger wrapper
	/// </summary>
	/// <typeparam name="TType"></typeparam>
	public class Logger<TType> : ILogger<TType>
	{
		private readonly ILogger<TType> _logger;

		/// <summary>
		/// Constructor
		/// </summary>
		public Logger(ILoggerFactory loggerFactory)
		{
			_logger = loggerFactory.CreateLogger<TType>();
		}

		public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
		{
			_logger.Log(logLevel, eventId, state, exception, formatter);
		}

		public bool IsEnabled(LogLevel logLevel)
		{
			return _logger.IsEnabled(logLevel);
		}

		public IDisposable BeginScope<TState>(TState state)
		{
			return _logger.BeginScope(state);
		}
	}
}
