﻿using System;
using FRT.Properties;
using Microsoft.Extensions.Logging;

namespace FRT
{
	/// <summary>
	/// Logger extensions
	/// </summary>
	public static class LoggingExtensions
	{
		public static void LogCritical(this ILogger logger, Exception ex)
		{
			LogCritical(logger, 0, ex);
		}

		public static void LogCritical(this ILogger logger, EventId eventId, Exception ex)
		{
			logger.LogCritical(eventId, ex, CommonResources.S_UnknownError);
		}

		public static void LogCritical(this ILogger logger, Exception ex, string message, params object[] args)
		{
			logger.LogCritical(0, ex, message, args);
		}

		public static void LogError(this ILogger logger, Exception ex)
		{
			LogError(logger, 0, ex);
		}

		public static void LogError(this ILogger logger, EventId eventId, Exception ex)
		{
			logger.LogError(eventId, ex, CommonResources.S_UnknownError);
		}

		public static void LogError(this ILogger logger, Exception ex, string message, params object[] args)
		{
			logger.LogError(0, ex, message, args);
		}

		public static void LogWarning(this ILogger logger, Exception ex)
		{
			LogWarning(logger, 0, ex);
		}

		public static void LogWarning(this ILogger logger, EventId eventId, Exception ex)
		{
			logger.LogWarning(eventId, ex, CommonResources.S_UnknownError);
		}

		public static void LogWarning(this ILogger logger, Exception ex, string message, params object[] args)
		{
			logger.LogWarning(0, ex, message, args);
		}

		public static void LogTrace(this ILogger logger, Exception ex)
		{
			LogTrace(logger, 0, ex);
		}

		public static void LogTrace(this ILogger logger, EventId eventId, Exception ex)
		{
			logger.LogTrace(eventId, ex, CommonResources.S_UnknownError);
		}

		public static void LogTrace(this ILogger logger, Exception ex, string message, params object[] args)
		{
			logger.LogTrace(0, ex, message, args);
		}

		public static void LogDebug(this ILogger logger, Exception ex)
		{
			LogDebug(logger, 0, ex);
		}

		public static void LogDebug(this ILogger logger, EventId eventId, Exception ex)
		{
			logger.LogDebug(eventId, ex, CommonResources.S_UnknownError);
		}

		public static void LogDebug(this ILogger logger, Exception ex, string message, params object[] args)
		{
			logger.LogDebug(0, ex, message, args);
		}
	}
}
