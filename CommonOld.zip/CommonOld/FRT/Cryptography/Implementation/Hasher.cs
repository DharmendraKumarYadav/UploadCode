﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using FRT.Properties;

namespace FRT.Cryptography
{
	/// <summary>
	/// Hash Provider
	/// </summary>
	public sealed class Hasher : IHasher
	{
		private HashAlgorithm _hashAlgorithm;

		#region Construction

		/// <summary>
		/// Constructor
		/// </summary>
		public Hasher(byte[] salt, string algorithm = null)
		{
			Salt = salt ?? throw new ArgumentException(string.Format(CultureInfo.InvariantCulture,
							CommonResources.S_NullOrEmptyValue_Name, nameof(salt)),
						nameof(salt));

			// Create algorithm
			algorithm = string.IsNullOrWhiteSpace(algorithm) ? "SHA512" : algorithm.Trim();
			_hashAlgorithm = CreateHashAlgorithm(algorithm);
			if (_hashAlgorithm == null)
			{
				throw new ArgumentException(string.Format(CultureInfo.InvariantCulture,
						LocalResources.S_FailedToCreateProvider_Type_Algorithm, "hash", algorithm),
					nameof(algorithm));
			}
		}

		#endregion

		#region Finalizer & Disposal

		/// <summary>
		/// Finalizer
		/// </summary>
		~Hasher()
		{
			Dispose(false);
		}

		/// <summary>
		/// Disposes this instance
		/// </summary>
		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}

		/// <summary>
		/// Disposes this instance
		/// </summary>
		/// <param name="disposing">True if being called from IDisposable.Dispose. False if being called from the Finalizer</param>
		// ReSharper disable once UnusedParameter.Local
		private void Dispose(bool disposing)
		{
			// This
			_hashAlgorithm?.Dispose();
			_hashAlgorithm = null;
		}

		#endregion

		#region Properties

		/// <summary>
		/// Salt
		/// </summary>
		[SuppressMessage("Microsoft.Performance", "CA1819:PropertiesShouldNotReturnArrays")]
		public byte[] Salt { get; }

		#endregion

		#region IHasher

		/// <summary>
		/// Creates an HashAlgorithm instance from name
		/// </summary>
		/// <param name="name">Name of the algorithm</param>
		/// <returns>Hash Algorithm</returns>
		private static HashAlgorithm CreateHashAlgorithm(string name)
		{
			if (string.IsNullOrWhiteSpace(name))
			{
				throw new ArgumentNullException(nameof(name));
			}
			name = name.Trim().ToUpperInvariant();

			// Create
			if (name == "MD5")
			{
				return MD5.Create();
			}
			else if (name == "SHA1")
			{
				return SHA1.Create();
			}
			else if (name == "SHA256")
			{
				return SHA256.Create();
			}
			else if (name == "SHA384")
			{
				return SHA384.Create();
			}
			else if (name == "SHA512")
			{
				return SHA512.Create();
			}
			return null;
		}

		/// <summary>
		/// Computes hash for the data
		/// </summary>
		/// <param name="dataBuffer">Data to hash</param>
		/// <returns>Hash</returns>
		public byte[] ComputeHash(byte[] dataBuffer)
		{
			if (dataBuffer == null)
			{
				throw new ArgumentNullException(nameof(dataBuffer));
			}

			byte[] hashBuffer = new byte[Salt.Length + dataBuffer.Length];
			Buffer.BlockCopy(Salt, 0, hashBuffer, 0, Salt.Length);
			Buffer.BlockCopy(dataBuffer, 0, hashBuffer, Salt.Length, dataBuffer.Length);

			// Return
			return _hashAlgorithm.ComputeHash(hashBuffer);
		}

		/// <summary>
		/// Computes hash for the data in the stream
		/// </summary>
		/// <param name="dataStream">Stream to hash</param>
		/// <returns>Hash</returns>
		public byte[] ComputeHash(Stream dataStream)
		{
			if (dataStream == null)
			{
				throw new ArgumentNullException(nameof(dataStream));
			}

			using (var memStream = new MemoryStream())
			{
				dataStream.CopyTo(memStream);
				return ComputeHash(memStream.ToArray());
			}
		}

		/// <summary>
		/// Computes hash for the text
		/// </summary>
		/// <param name="textBuffer">Text to hash</param>
		/// <returns>Hash</returns>
		public byte[] ComputeHash(string textBuffer)
		{
			if (textBuffer == null)
			{
				throw new ArgumentNullException(nameof(textBuffer));
			}
			return ComputeHash(Encoding.UTF8.GetBytes(textBuffer));
		}

		#endregion
	}
}
