﻿using System;
using System.Diagnostics.CodeAnalysis;
using Microsoft.Extensions.DependencyInjection;

namespace FRT.Cryptography
{
	/// <summary>
	/// Crypto factory
	/// </summary>
	[SuppressMessage("Microsoft.Performance", "CA1812:AvoidUninstantiatedInternalClasses")]
	public sealed class CryptoFactory : ICryptoFactory
	{
		/// <inheritdoc />
		public ISymmetricCryptographer CreateSymmetricCryptographer(CryptographySymmetricConfig config = null)
		{
			config = config ?? DI.Container.GetService<CryptographySymmetricConfig>();
			return new SymmetricCryptographer(
				(config.Key != null) ? Convert.FromBase64String(config.Key) : null,
				(config.IV != null) ? Convert.FromBase64String(config.IV) : null,
				config.Algorithm);
		}

		/// <inheritdoc />
		public IAsymmetricCryptographer CreateAsymmetricCryptographer(CryptographyAsymmetricConfig config = null)
		{
			config = config ?? DI.Container.GetService<CryptographyAsymmetricConfig>();
			return new AsymmetricCryptographer(
				(config.Key != null) ? Convert.FromBase64String(config.Key) : null,
				config.Algorithm,
				config.HashAlgorithm);
		}

		/// <inheritdoc />
		public IHasher CreateHasher(CryptographyHashConfig config = null)
		{
			config = config ?? DI.Container.GetService<CryptographyHashConfig>();
			return new Hasher(
				(config.Salt != null) ? Convert.FromBase64String(config.Salt) : null,
				config.Algorithm);
		}
	}
}
