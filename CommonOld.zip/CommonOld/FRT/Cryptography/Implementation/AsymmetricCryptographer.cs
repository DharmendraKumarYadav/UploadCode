﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using FRT.Properties;

namespace FRT.Cryptography
{
	/// <summary>
	/// IAsymmetricCryptographer
	/// </summary>
	public sealed class AsymmetricCryptographer : Cryptographer, IAsymmetricCryptographer
	{
		private AsymmetricAlgorithm _algorithm;
		private readonly HashAlgorithmName _hashAlgorithmName;

		private readonly Func<Stream, HashAlgorithmName, RSASignaturePadding, byte[]> _signData;
		private readonly Func<Stream, byte[], HashAlgorithmName, RSASignaturePadding, bool> _verifyData;
		private readonly Func<byte[], HashAlgorithmName, RSASignaturePadding, byte[]> _signHash;
		private readonly Func<byte[], byte[], HashAlgorithmName, RSASignaturePadding, bool> _verifyHash;

		/// <summary>
		/// Constructor
		/// </summary>
		public AsymmetricCryptographer(byte[] key, string algorithm = null, string hashAlgorithm = null)
		{
			if (key == null)
			{
				throw new ArgumentException(string.Format(CultureInfo.InvariantCulture,
					CommonResources.S_NullOrEmptyValue_Name, nameof(key)),
					nameof(key));
			}

			// Create algorithm
			algorithm = string.IsNullOrWhiteSpace(algorithm) ? "RSA" : algorithm.Trim();
			_algorithm = CreateAsymmetricAlgorithm(algorithm);
			if (_algorithm == null)
			{
				throw new ArgumentException(string.Format(CultureInfo.InvariantCulture,
					LocalResources.S_FailedToCreateProvider_Type_Algorithm, "asymmetric", algorithm),
					nameof(algorithm));
			}

			// Set Key
			var cspAsymmetricAlgorithm = _algorithm as ICspAsymmetricAlgorithm;
			if (cspAsymmetricAlgorithm == null)
			{
				throw new ArgumentException(string.Format(CultureInfo.InvariantCulture,
					CommonResources.S_ObjectDoesNotImplementRequiredInterface_Object_Interface,
						"Asymmetric cryptography algorithm(" + algorithm + ")", typeof(ICspAsymmetricAlgorithm)),
					nameof(algorithm));
			}
			cspAsymmetricAlgorithm.ImportCspBlob(key);

			// Hash Algorithm name
			hashAlgorithm = string.IsNullOrWhiteSpace(hashAlgorithm) ? "SHA512" : hashAlgorithm.Trim();
			_hashAlgorithmName = new HashAlgorithmName(hashAlgorithm);

			// Properties
			var algName = algorithm.ToUpperInvariant();
			if (algName == "RSA")
			{
				var rsaProv = _algorithm as RSA;

				CanEncrypt = true;
				CanSign = true;
				CanVerify = true;

				// ReSharper disable once PossibleNullReferenceException
				_signData = rsaProv.SignData;
				_verifyData = rsaProv.VerifyData;
				_signHash = rsaProv.SignHash;
				_verifyHash = rsaProv.VerifyHash;
			}
		}

		/// <summary>
		/// Disposes this instance
		/// </summary>
		/// <param name="disposing">True if being called from IDisposable.Dispose. False if being called from the Finalizer</param>
		protected override void Dispose(bool disposing)
		{
			// This
			_algorithm?.Dispose();
			_algorithm = null;

			// Base
			base.Dispose(disposing);
		}

		/// <summary>
		/// Creates an AsymmetricAlgorithm instance from name
		/// </summary>
		/// <returns>Asymmetric Algorithm</returns>
		private static AsymmetricAlgorithm CreateAsymmetricAlgorithm(string name)
		{
			if (string.IsNullOrWhiteSpace(name))
			{
				throw new ArgumentNullException(nameof(name));
			}
			name = name.Trim().ToUpperInvariant();

			// Create
			if (name == "RSA")
			{
				return new RSACryptoServiceProvider();
			}
			return null;
		}

		/// <summary>
		/// Whether this provider can encrypt/decrypt
		/// </summary>
		public bool CanEncrypt { get; }

		/// <summary>
		/// Whether this provider can sign
		/// </summary>
		public bool CanSign { get; }

		/// <summary>
		/// Whether this provider can verify
		/// </summary>
		public bool CanVerify { get; }

		/// <summary>
		/// Encrypt stream
		/// </summary>
		/// <param name="stream">Data stream</param>
		/// <returns>Encrypted stream</returns>
		[SuppressMessage("Microsoft.Reliability", "CA2000:Dispose objects before losing scope")]
		public override MemoryStream EncryptStream(Stream stream)
		{
			if (stream == null)
			{
				throw new ArgumentNullException(nameof(stream));
			}

			var resultStream = new MemoryStream();
			// ReSharper disable once RedundantArgumentDefaultValue
			using (ICryptoTransform cryptoTransform = new AsymmetricCryptoTransform(_algorithm, false))
			using (CryptoStream cryptoStream = new CryptoStream(resultStream, cryptoTransform, CryptoStreamMode.Write))
			{
				stream.CopyTo(cryptoStream);
				cryptoStream.FlushFinalBlock();
			}
			return resultStream;
		}

		/// <summary>
		/// Decrypts stream
		/// </summary>
		/// <param name="stream">Data stream</param>
		/// <returns>Decrypted stream</returns>
		[SuppressMessage("Microsoft.Reliability", "CA2000:Dispose objects before losing scope")]
		public override MemoryStream DecryptStream(Stream stream)
		{
			if (stream == null)
			{
				throw new ArgumentNullException(nameof(stream));
			}

			var resultStream = new MemoryStream();
			using (ICryptoTransform cryptoTransform = new AsymmetricCryptoTransform(_algorithm, true))
			using (CryptoStream cryptoStream = new CryptoStream(resultStream, cryptoTransform, CryptoStreamMode.Write))
			{
				stream.CopyTo(cryptoStream);
				cryptoStream.FlushFinalBlock();
				return resultStream;
			}
		}

		/// <summary>Generates a signature for the specified data stream, reading to the end of the stream.</summary>
		/// <returns>A digital signature for the specified data stream.</returns>
		/// <param name="data">The data stream to be signed.</param>
		/// <exception cref="T:System.ArgumentNullException">
		/// <paramref name="data" /> is null.</exception>
		/// <exception cref="T:System.Security.Cryptography.CryptographicException">The key information that is associated with the instance does not have a private key.</exception>
		public MemoryStream SignData(Stream data)
		{
			if (_signData == null)
			{
				return null;
			}
			return new MemoryStream(_signData(data, _hashAlgorithmName, RSASignaturePadding.Pss));
		}

		/// <summary>Generates a digital signature for the specified length of data, beginning at the specified offset. </summary>
		/// <returns>A digital signature for the specified length of data.</returns>
		/// <param name="data">The message data to be signed.</param>
		/// <param name="offset">The location in the string at which to start signing.</param>
		/// <param name="count">The length of the string, in characters, following <paramref name="offset" /> that will be signed.</param>
		/// <exception cref="T:System.ArgumentNullException">
		/// <paramref name="data" /> is null.</exception>
		/// <exception cref="T:System.ArgumentOutOfRangeException">
		/// <paramref name="count" /> or <paramref name="offset" /> caused reading outside the bounds of the data string. </exception>
		/// <exception cref="T:System.Security.Cryptography.CryptographicException">The key information that is associated with the instance does not have a private key.</exception>
		public byte[] SignData(byte[] data, int offset = 0, int count = 0)
		{
			if (_signData == null)
			{
				return null;
			}
			using (var memStream = new MemoryStream(data, offset, count))
			{
				using (var signedStream = SignData(memStream))
				{
					return signedStream.ToArray();
				}
			}
		}

		/// <summary>Verifies the digital signature of the specified data stream, reading to the end of the stream.</summary>
		/// <returns>true if the signature is valid; otherwise, false.</returns>
		/// <param name="data">The data stream that was signed.</param>
		/// <param name="signature">The signature to be verified.</param>
		/// <exception cref="T:System.ArgumentNullException">
		/// <paramref name="data" /> or <paramref name="signature" /> is null.</exception>
		public bool VerifyData(Stream data, byte[] signature)
		{
			if (_verifyData == null)
			{
				return false;
			}
			return _verifyData(data, signature, _hashAlgorithmName, RSASignaturePadding.Pss);
		}

		/// <summary>Verifies a signature for the specified length of data, beginning at the specified offset.</summary>
		/// <returns>true if the signature is valid; otherwise, false.</returns>
		/// <param name="data">The data that was signed.</param>
		/// <param name="offset">The location in the data at which the signed data begins.</param>
		/// <param name="count">The length of the data, in characters, following <paramref name="offset" /> that will be signed.</param>
		/// <param name="signature">The signature to be verified.</param>
		/// <exception cref="T:System.ArgumentOutOfRangeException">
		/// <paramref name="offset" /> or <paramref name="count" /> is less then zero. -or-<paramref name="offset" /> or <paramref name="count" /> is larger than the length of the byte array passed in the <paramref name="data" /> parameter.</exception>
		/// <exception cref="T:System.ArgumentNullException">
		/// <paramref name="data" /> or <paramref name="signature" /> is null.</exception>
		public bool VerifyData(byte[] data, byte[] signature, int offset = 0, int count = 0)
		{
			if (_verifyData == null)
			{
				return false;
			}

			using (var memStream = new MemoryStream(data, offset, count))
			{
				return VerifyData(memStream, signature);
			}
		}

		/// <summary>Generates a signature for the specified hash value.</summary>
		/// <returns>A digital signature for the specified hash value.</returns>
		/// <param name="hash">The hash value of the data to be signed.</param>
		/// <exception cref="T:System.ArgumentNullException">
		/// <paramref name="hash" /> is null.</exception>
		/// <exception cref="T:System.Security.Cryptography.CryptographicException">The key information that is associated with the instance does not have a private key.</exception>
		public byte[] SignHash(byte[] hash)
		{
			// ReSharper disable once UseNullPropagation
			if (_signHash == null)
			{
				return null;
			}
			return _signHash(hash, _hashAlgorithmName, RSASignaturePadding.Pss);
		}

		/// <summary>Verifies the specified digital signature against a specified hash value.</summary>
		/// <returns>true if the signature is valid; otherwise, false.</returns>
		/// <param name="hash">The hash value of the data to be verified.</param>
		/// <param name="signature">The digital signature of the data to be verified against the hash value.</param>
		/// <exception cref="T:System.ArgumentNullException">
		/// <paramref name="hash" /> or <paramref name="signature" /> is null.</exception>
		public bool VerifyHash(byte[] hash, byte[] signature)
		{
			if (_verifyHash == null)
			{
				return false;
			}
			return _verifyHash(hash, signature, _hashAlgorithmName, RSASignaturePadding.Pss);
		}
	}
}
