﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Text;

namespace FRT.Cryptography
{
	/// <summary>
	/// Base class
	/// </summary>
	public abstract class Cryptographer : ICryptographer
	{
		#region Finalizer & Disposal

		/// <summary>
		/// Finalizer
		/// </summary>
		~Cryptographer()
		{
			Dispose(false);
		}

		/// <summary>
		/// Disposes this instance
		/// </summary>
		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}

		/// <summary>
		/// Disposes this instance
		/// </summary>
		/// <param name="disposing">True if being called from IDisposable.Dispose. False if being called from the Finalizer</param>
		protected virtual void Dispose(bool disposing)
		{
		}
		#endregion

		#region Implementation of ICryptographer
		/// <summary>
		/// Encrypt stream
		/// </summary>
		/// <param name="stream">Data stream</param>
		/// <returns>Encrypted stream</returns>
		[SuppressMessage("Microsoft.Reliability", "CA2000:Dispose objects before losing scope")]
		public abstract MemoryStream EncryptStream(Stream stream);

		/// <summary>
		/// Decrypts stream
		/// </summary>
		/// <param name="stream">Data stream</param>
		/// <returns>Decrypted stream</returns>
		[SuppressMessage("Microsoft.Reliability", "CA2000:Dispose objects before losing scope")]
		public abstract MemoryStream DecryptStream(Stream stream);

		/// <summary>
		/// Encrypt Data
		/// </summary>
		/// <param name="dataBlob">Data</param>
		/// <returns>Encrypted Data</returns>
		public virtual byte[] EncryptData(byte[] dataBlob)
		{
			if ((dataBlob == null) || (dataBlob.Length == 0))
			{
				throw new ArgumentNullException(nameof(dataBlob));
			}

			using (var stream = new MemoryStream(dataBlob))
			{
				using (var resultStream = EncryptStream(stream))
				{
					return resultStream.ToArray();
				}
			}
		}

		/// <summary>
		/// Encrypts text
		/// </summary>
		/// <param name="textData">Text</param>
		/// <returns>Encrypted text</returns>
		public virtual string EncryptString(string textData)
		{
			if (textData == null)
			{
				return null;
			}
			if (textData.Length == 0)
			{
				return string.Empty;
			}

			return Convert.ToBase64String(EncryptData(Encoding.UTF8.GetBytes(textData)));
		}

		/// <summary>
		/// Decrypts data
		/// </summary>
		/// <param name="dataBlob">Data</param>
		/// <returns>Decrypted data</returns>
		public virtual byte[] DecryptData(byte[] dataBlob)
		{
			if ((dataBlob == null) || (dataBlob.Length == 0))
			{
				throw new ArgumentNullException(nameof(dataBlob));
			}

			using (var stream = new MemoryStream(dataBlob))
			{
				using (var resultStream = DecryptStream(stream))
				{
					return resultStream.ToArray();
				}
			}
		}

		/// <summary>
		/// Decrypts text
		/// </summary>
		/// <param name="textData">Text</param>
		/// <returns>Decrypted text</returns>
		public virtual string DecryptString(string textData)
		{
			if (textData == null)
			{
				return null;
			}
			if (textData.Length == 0)
			{
				return string.Empty;
			}

			byte[] data = DecryptData(Convert.FromBase64String(textData));
			return Encoding.UTF8.GetString(data, 0, data.Length);
		}
		#endregion
	}
}
