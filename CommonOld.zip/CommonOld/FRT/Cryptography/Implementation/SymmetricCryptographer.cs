﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using FRT.Properties;

namespace FRT.Cryptography
{
	/// <summary>
	/// Symmetric Cryptographer
	/// </summary>
	[SuppressMessage("Microsoft.Design", "CA1063:ImplementIDisposableCorrectly")]
	public sealed class SymmetricCryptographer : Cryptographer, ISymmetricCryptographer
	{
		private SymmetricAlgorithm _algorithm;

		/// <summary>
		/// Constructor
		/// </summary>
		public SymmetricCryptographer(byte[] key, byte[] iv, string algorithm = null)
		{
			if (key == null)
			{
				throw new ArgumentException(string.Format(CultureInfo.InvariantCulture,
					CommonResources.S_NullOrEmptyValue_Name, nameof(key)),
					nameof(key));
			}

			if (iv == null)
			{
				throw new ArgumentException(string.Format(CultureInfo.InvariantCulture,
					CommonResources.S_NullOrEmptyValue_Name, nameof(iv)),
					nameof(iv));
			}

			// Create algorithm
			algorithm = string.IsNullOrWhiteSpace(algorithm) ? "AES" : algorithm.Trim();
			_algorithm = CreateSymmetricAlgorithm(algorithm);
			if (_algorithm == null)
			{
				throw new ArgumentException(string.Format(CultureInfo.InvariantCulture,
						LocalResources.S_FailedToCreateProvider_Type_Algorithm, "symmetric", algorithm),
					nameof(algorithm));
			}

			// Set properties
			_algorithm.Key = key;
			_algorithm.IV = iv;
		}

		/// <summary>
		/// Disposes this instance
		/// </summary>
		/// <param name="disposing">True if being called from IDisposable.Dispose. False if being called from the Finalizer</param>
		protected override void Dispose(bool disposing)
		{
			// This
			_algorithm?.Dispose();
			_algorithm = null;

			// Base
			base.Dispose(disposing);
		}

		/// <summary>
		/// Creates an SymmetricAlgorithm instance from name
		/// </summary>
		/// <param name="name">Name of the algorithm</param>
		/// <returns>Symmetric Algorithm</returns>
		private static SymmetricAlgorithm CreateSymmetricAlgorithm(string name)
		{
			if (string.IsNullOrWhiteSpace(name))
			{
				throw new ArgumentNullException(nameof(name));
			}
			name = name.Trim().ToUpperInvariant();

			// Create
			if (name == "AES")
			{
				return Aes.Create();
			}
			else if (name == "TRIPLEDES")
			{
				return TripleDES.Create();
			}
			return null;
		}

		/// <summary>
		/// Encrypt stream
		/// </summary>
		/// <param name="stream">Data stream</param>
		/// <returns>Encrypted stream</returns>
		[SuppressMessage("Microsoft.Reliability", "CA2000:Dispose objects before losing scope")]
		public override MemoryStream EncryptStream(Stream stream)
		{
			if (stream == null)
			{
				throw new ArgumentNullException(nameof(stream));
			}

			var resultStream = new MemoryStream();
			using (ICryptoTransform cryptoTransform = _algorithm?.CreateEncryptor())
			using (CryptoStream cryptoStream = new CryptoStream(resultStream, cryptoTransform, CryptoStreamMode.Write))
			{
				stream.CopyTo(cryptoStream);
				cryptoStream.FlushFinalBlock();
			}
			return resultStream;
		}

		/// <summary>
		/// Decrypts stream
		/// </summary>
		/// <param name="stream">Data stream</param>
		/// <returns>Decrypted stream</returns>
		[SuppressMessage("Microsoft.Reliability", "CA2000:Dispose objects before losing scope")]
		public override MemoryStream DecryptStream(Stream stream)
		{
			if (stream == null)
			{
				throw new ArgumentNullException(nameof(stream));
			}

			var resultStream = new MemoryStream();
			using (ICryptoTransform cryptoTransform = _algorithm?.CreateDecryptor())
			using (CryptoStream cryptoStream = new CryptoStream(resultStream, cryptoTransform, CryptoStreamMode.Write))
			{
				stream.CopyTo(cryptoStream);
				cryptoStream.FlushFinalBlock();
				return resultStream;
			}
		}
	}
}
