﻿using System;
using System.Security.Cryptography;

namespace FRT.Cryptography
{
	/// <summary>
	/// ICryptoTransform implementation for asymmetric algorithms
	/// </summary>
	public sealed class AsymmetricCryptoTransform : ICryptoTransform
	{
		private readonly AsymmetricAlgorithm _algorithm;
		private readonly bool _valid;
		private readonly bool _decrypting;
		private readonly Func<byte[], bool, byte[]> _encrypt;
		private readonly Func<byte[], bool, byte[]> _decrypt;

		#region Construction & Disposal
		/// <summary>
		/// Constructor
		/// </summary>
		public AsymmetricCryptoTransform(AsymmetricAlgorithm algorithm, bool decrypting = false)
		{
			_algorithm = algorithm ?? throw new ArgumentNullException(nameof(algorithm));
			_decrypting = decrypting;
			_valid = false;
			_encrypt = (b, f) => null;
			_decrypt = (b, f) => null;

			var rsaProv = algorithm as RSACryptoServiceProvider;
			if (rsaProv != null)
			{
				_encrypt = rsaProv.Encrypt;
				_decrypt = rsaProv.Decrypt;
				_valid = true;
			}
		}

		/// <summary>
		/// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
		/// </summary>
		public void Dispose()
		{
		}
		#endregion

		#region Implementation of ICryptoTransform
		/// <summary>
		/// Transform block
		/// </summary>
		public int TransformBlock(byte[] inputBuffer, int inputOffset, int inputCount, byte[] outputBuffer, int outputOffset)
		{
			if (!_valid)
			{
				return 0;
			}

			byte[] tempBuffer = new byte[inputCount];
			Array.Copy(inputBuffer, inputOffset, tempBuffer, 0, inputCount);
			tempBuffer = _decrypting ? _decrypt(tempBuffer, true) : _encrypt(tempBuffer, true);
			Array.Copy(tempBuffer, 0, outputBuffer, outputOffset, tempBuffer.Length);
			return tempBuffer.Length;
		}

		/// <summary>
		/// Transform final block
		/// </summary>
		public byte[] TransformFinalBlock(byte[] inputBuffer, int inputOffset, int inputCount)
		{
			if (!_valid)
			{
				return null;
			}

			byte[] tempBuffer = new byte[inputCount];
			Array.Copy(inputBuffer, inputOffset, tempBuffer, 0, inputCount);
			return _decrypting ? _decrypt(tempBuffer, true) : _encrypt(tempBuffer, true);
		}

		/// <summary>
		/// Whether this instance is valid
		/// </summary>
		public bool IsValid => _valid;

		/// <summary>
		/// Whether decrypting
		/// </summary>
		public bool IsDecrypting => _decrypting;

		/// <summary>
		/// Whether this transform can be reused
		/// </summary>
		public bool CanReuseTransform => true;

		/// <summary>
		/// Whether this instance can transform multiple blocks
		/// </summary>
		public bool CanTransformMultipleBlocks => true;

		/// <summary>
		/// Input block size
		/// </summary>
		public int InputBlockSize => !_decrypting? (_algorithm.KeySize - 11) : _algorithm.KeySize;

		/// <summary>
		/// Output block size
		/// </summary>
		public int OutputBlockSize => !_decrypting ? _algorithm.KeySize : (_algorithm.KeySize - 11);
		#endregion
	}
}
