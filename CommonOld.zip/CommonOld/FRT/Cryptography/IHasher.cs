﻿using System;
using System.IO;

namespace FRT.Cryptography
{
	/// <summary>
	/// Hash provider
	/// </summary>
	public interface IHasher : IDisposable
	{
		/// <summary>
		/// Computes hash for the data in the stream
		/// </summary>
		/// <param name="dataStream">Stream to hash</param>
		/// <returns>Hash</returns>
		byte[] ComputeHash(Stream dataStream);

		/// <summary>
		/// Computes hash for the data
		/// </summary>
		/// <param name="dataBuffer">Data to hash</param>
		/// <returns>Hash</returns>
		byte[] ComputeHash(byte[] dataBuffer);

		/// <summary>
		/// Computes hash for the text
		/// </summary>
		/// <param name="textBuffer">Text to hash</param>
		/// <returns>Hash</returns>
		byte[] ComputeHash(string textBuffer);
	}
}
