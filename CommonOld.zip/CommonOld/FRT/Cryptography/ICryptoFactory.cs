﻿namespace FRT.Cryptography
{
	/// <summary>
	/// Crypto factory
	/// </summary>
	public interface ICryptoFactory
	{
		/// <summary>
		/// Creates a disposable symmetric cryptographer
		/// </summary>
		/// <param name="config">Cryptography configuration</param>
		/// <returns>Cryptographer</returns>
		ISymmetricCryptographer CreateSymmetricCryptographer(CryptographySymmetricConfig config = null);

		/// <summary>
		/// Creates a disposable asymmetric cryptographer
		/// </summary>
		/// <param name="config">Cryptography configuration</param>
		/// <returns>Cryptographer</returns>
		IAsymmetricCryptographer CreateAsymmetricCryptographer(CryptographyAsymmetricConfig config = null);

		/// <summary>
		/// Creates a disposable hasher
		/// </summary>
		/// <param name="config">Hash configuration</param>
		/// <returns>Hasher</returns>
		IHasher CreateHasher(CryptographyHashConfig config = null);
	}
}
