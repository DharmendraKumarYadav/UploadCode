﻿namespace FRT.Cryptography
{
	/// <summary>
	/// Cryptography Configuration
	/// </summary>
	public sealed class CryptographyConfig : IInjectableConfig
	{
		/// <summary>
		/// Symmetric configuration
		/// </summary>
		public CryptographySymmetricConfig Symmetric
		{
			get;
			set;
		} = new CryptographySymmetricConfig();

		/// <summary>
		/// Asymmetric configuration
		/// </summary>
		public CryptographyAsymmetricConfig Asymmetric
		{
			get;
			set;
		} = new CryptographyAsymmetricConfig();

		/// <summary>
		/// Hash configuration
		/// </summary>
		public CryptographyHashConfig Hash
		{
			get;
			set;
		} = new CryptographyHashConfig();
	}

	/// <summary>
	/// Cryptography Configuration
	/// </summary>
	public abstract class CryptographyConfigBase : IInjectableConfig
	{
		private string _algorithm;
		/// <summary>
		/// Algorithm name
		/// </summary>
		public string Algorithm
		{
			get => _algorithm;
			set => _algorithm = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private string _key;
		/// <summary>
		/// Key
		/// </summary>
		public string Key
		{
			get => _key;
			set => _key = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}
	}

	/// <summary>
	/// Config for symmetric provider
	/// </summary>
	public sealed class CryptographySymmetricConfig : CryptographyConfigBase
	{
		/// <summary>
		/// Constructor
		/// </summary>
		public CryptographySymmetricConfig()
		{
			Algorithm = "AES";
		}

		private string _iv;
		/// <summary>
		/// Initialization Vector
		/// </summary>
		public string IV
		{
			get => _iv;
			set => _iv = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}
	}

	/// <summary>
	/// Config for asymmetric provider
	/// </summary>
	public sealed class CryptographyAsymmetricConfig : CryptographyConfigBase
	{
		/// <summary>
		/// Constructor
		/// </summary>
		public CryptographyAsymmetricConfig()
		{
			Algorithm = "RSA";
			HashAlgorithm = "SHA512";
		}

		private string _hashAlgorithm;
		/// <summary>
		/// Hash algorithm name
		/// </summary>
		public string HashAlgorithm
		{
			get => _hashAlgorithm;
			set => _hashAlgorithm = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}
	}

	/// <summary>
	/// Config for symmetric provider
	/// </summary>
	public sealed class CryptographyHashConfig : IInjectableConfig
	{
		/// <summary>
		/// Constructor
		/// </summary>
		public CryptographyHashConfig()
		{
			Algorithm = "SHA256";
		}

		private string _algorithm;
		/// <summary>
		/// Algorithm name
		/// </summary>
		public string Algorithm
		{
			get => _algorithm;
			set => _algorithm = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private string _salt;
		/// <summary>
		/// Salt
		/// </summary>
		public string Salt
		{
			get => _salt;
			set => _salt = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}
	}
}
