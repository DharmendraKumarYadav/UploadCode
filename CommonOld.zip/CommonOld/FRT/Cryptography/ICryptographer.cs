﻿using System;
using System.IO;

namespace FRT.Cryptography
{
	/// <summary>
	/// Cryptography provider
	/// </summary>
	public interface ICryptographer : IDisposable
	{
		/// <summary>
		/// Encrypt stream
		/// </summary>
		/// <param name="stream">Data stream</param>
		/// <returns>Encrypted stream</returns>
		MemoryStream EncryptStream(Stream stream);

		/// <summary>
		/// Encrypt data
		/// </summary>
		/// <param name="dataBlob">Data</param>
		/// <returns>Encrypted data</returns>
		byte[] EncryptData(byte[] dataBlob);

		/// <summary>
		/// Encrypts text
		/// </summary>
		/// <param name="textData">Text</param>
		/// <returns>Encrypted text</returns>
		string EncryptString(string textData);

		/// <summary>
		/// Decrypts stream
		/// </summary>
		/// <param name="stream">Data stream</param>
		/// <returns>Decrypted stream</returns>
		MemoryStream DecryptStream(Stream stream);

		/// <summary>
		/// Decrypts data
		/// </summary>
		/// <param name="dataBlob">Data</param>
		/// <returns>Decrypted data</returns>
		byte[] DecryptData(byte[] dataBlob);

		/// <summary>
		/// Decrypts text
		/// </summary>
		/// <param name="textData">Text</param>
		/// <returns>Decrypted text</returns>
		string DecryptString(string textData);
	}

	/// <summary>
	/// Symmetric Provider
	/// </summary>
	public interface ISymmetricCryptographer : ICryptographer
	{
	}

	/// <summary>
	/// Asymmetric Provider
	/// </summary>
	public interface IAsymmetricCryptographer : ICryptographer
	{
		/// <summary>
		/// Whether this provider can encrypt/decrypt
		/// </summary>
		bool CanEncrypt { get; }

		/// <summary>
		/// Whether this provider can sign
		/// </summary>
		bool CanSign { get; }

		/// <summary>
		/// Whether this provider can verify
		/// </summary>
		bool CanVerify { get; }

		/// <summary>Generates a signature for the specified data stream, reading to the end of the stream.</summary>
		/// <returns>A digital signature for the specified data stream.</returns>
		/// <param name="data">The data stream to be signed.</param>
		/// <exception cref="T:System.ArgumentNullException">
		/// <paramref name="data" /> is null.</exception>
		/// <exception cref="T:System.Security.Cryptography.CryptographicException">The key information that is associated with the instance does not have a private key.</exception>
		MemoryStream SignData(Stream data);

		/// <summary>Generates a digital signature for the specified length of data, beginning at the specified offset. </summary>
		/// <returns>A digital signature for the specified length of data.</returns>
		/// <param name="data">The message data to be signed.</param>
		/// <param name="offset">The location in the string at which to start signing.</param>
		/// <param name="count">The length of the string, in characters, following <paramref name="offset" /> that will be signed.</param>
		/// <exception cref="T:System.ArgumentNullException">
		/// <paramref name="data" /> is null.</exception>
		/// <exception cref="T:System.ArgumentOutOfRangeException">
		/// <paramref name="count" /> or <paramref name="offset" /> caused reading outside the bounds of the data string. </exception>
		/// <exception cref="T:System.Security.Cryptography.CryptographicException">The key information that is associated with the instance does not have a private key.</exception>
		byte[] SignData(byte[] data, int offset = 0, int count = 0);

		/// <summary>Verifies the digital signature of the specified data stream, reading to the end of the stream.</summary>
		/// <returns>true if the signature is valid; otherwise, false.</returns>
		/// <param name="data">The data stream that was signed.</param>
		/// <param name="signature">The signature to be verified.</param>
		/// <exception cref="T:System.ArgumentNullException">
		/// <paramref name="data" /> or <paramref name="signature" /> is null.</exception>
		bool VerifyData(Stream data, byte[] signature);

		/// <summary>Verifies a signature for the specified length of data, beginning at the specified offset.</summary>
		/// <returns>true if the signature is valid; otherwise, false.</returns>
		/// <param name="data">The data that was signed.</param>
		/// <param name="offset">The location in the data at which the signed data begins.</param>
		/// <param name="count">The length of the data, in characters, following <paramref name="offset" /> that will be signed.</param>
		/// <param name="signature">The signature to be verified.</param>
		/// <exception cref="T:System.ArgumentOutOfRangeException">
		/// <paramref name="offset" /> or <paramref name="count" /> is less then zero. -or-<paramref name="offset" /> or <paramref name="count" /> is larger than the length of the byte array passed in the <paramref name="data" /> parameter.</exception>
		/// <exception cref="T:System.ArgumentNullException">
		/// <paramref name="data" /> or <paramref name="signature" /> is null.</exception>
		bool VerifyData(byte[] data, byte[] signature, int offset = 0, int count = 0);

		/// <summary>Generates a signature for the specified hash value.</summary>
		/// <returns>A digital signature for the specified hash value.</returns>
		/// <param name="hash">The hash value of the data to be signed.</param>
		/// <exception cref="T:System.ArgumentNullException">
		/// <paramref name="hash" /> is null.</exception>
		/// <exception cref="T:System.Security.Cryptography.CryptographicException">The key information that is associated with the instance does not have a private key.</exception>
		byte[] SignHash(byte[] hash);

		/// <summary>Verifies the specified digital signature against a specified hash value.</summary>
		/// <returns>true if the signature is valid; otherwise, false.</returns>
		/// <param name="hash">The hash value of the data to be verified.</param>
		/// <param name="signature">The digital signature of the data to be verified against the hash value.</param>
		/// <exception cref="T:System.ArgumentNullException">
		/// <paramref name="hash" /> or <paramref name="signature" /> is null.</exception>
		bool VerifyHash(byte[] hash, byte[] signature);
	}
}
