﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

namespace FRT.Validation
{
	/// <summary>
	/// Validation exception
	/// </summary>
	[SuppressMessage("Microsoft.Design", "CA1032:ImplementStandardExceptionConstructors")]
	public sealed class ValidationException : Exception
	{
		private readonly List<ValidationError> _errors;

		/// <summary>
		/// Construction
		/// </summary>
		/// <param name="errors">Error collection</param>
		public ValidationException(IEnumerable<ValidationError> errors)
		{
			_errors = errors?.Where(e => e != null).ToList() ?? throw new ArgumentNullException(nameof(errors));
			if (_errors.Count <= 0)
			{
				throw new ArgumentNullException(nameof(errors));
			}
		}

		/// <summary>
		/// Errors
		/// </summary>
		public IEnumerable<ValidationError> Errors => _errors;

		/// <summary>
		/// Message
		/// </summary>
		public override string Message
		{
			get { return string.Join(Environment.NewLine, _errors.Select(e => e.ToString())); }
		}
	}
}
