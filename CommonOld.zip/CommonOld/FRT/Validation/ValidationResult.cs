﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using FRT.Properties;
using FRT.Validation;

namespace FRT
{
	/// <summary>
	/// Validation result
	/// </summary>
	public class ValidationResult
	{
		private static readonly ValidationError[] _emptyErrors = new ValidationError[0];
		private ValidationError[] _errors = _emptyErrors;

		/// <summary>
		/// Success
		/// </summary>
		public bool Success
		{
			get;
			set;
		}

		/// <summary>
		/// Errors
		/// </summary>
		[SuppressMessage("Microsoft.Performance", "CA1819:PropertiesShouldNotReturnArrays")]
		public ValidationError[] Errors
		{
			get => _errors;
			set => _errors = (value ?? _emptyErrors).Where(v => v != null).ToArray();
		}

		/// <summary>
		/// Boolean conversion
		/// </summary>
		/// <param name="result">Result object</param>
		public static implicit operator bool(ValidationResult result)
		{
			return result?.Success ?? false;
		}

		/// <summary>
		/// Throw in case of error
		/// </summary>
		public void ThrowIfError()
		{
			if (!Success)
			{
				throw new ValidationException(Errors);
			}
		}
	}

	/// <summary>
	/// Individual error
	/// </summary>
	public class ValidationError
	{
		private string _message;

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="propertyName"></param>
		public ValidationError(string propertyName)
		{
			if (string.IsNullOrWhiteSpace(propertyName))
			{
				throw new ArgumentNullException(nameof(propertyName));
			}
			PropertyName = propertyName.Trim();
		}

		/// <summary>
		/// PropertyName name
		/// </summary>
		public string PropertyName { get; }

		/// <summary>
		/// PropertyName value
		/// </summary>
		public object AttemptedValue
		{
			get;
			set;
		}

		/// <summary>
		/// Error message
		/// </summary>
		public string Message
		{
			get
			{
				if (_message == null)
				{
					return string.Format(CultureInfo.CurrentCulture, CommonResources.S_InvalidParameter_Name, PropertyName);
				}
				return _message;
			}
			set => _message = string.IsNullOrWhiteSpace(value) ? null : string.Format(CultureInfo.CurrentCulture, value, PropertyName);
		}

		/// <summary>
		/// To string
		/// </summary>
		/// <returns></returns>
		public override string ToString()
		{
			return Message;
		}
	}
}
