﻿using System.Diagnostics.CodeAnalysis;

namespace FRT.Validation
{
	/// <summary>
	/// Validation manager
	/// </summary>
	public interface IValidationManager
	{
		/// <summary>
		/// Gets the default validator for the given object type
		/// </summary>
		/// <typeparam name="TType">Object type</typeparam>
		/// <returns>Default validator</returns>
		IValidator<TType> GetDefaultValidator<TType>();

		/// <summary>
		/// Validates the object within the scope of the given rule set names
		/// </summary>
		/// <param name="obj">Object instance</param>
		/// <param name="includeDefaultRules">Whether to include rules not in any rulesets</param>
		/// <param name="ruleSetNames">Names of the rule sets to validate. If not specified the complete object is validated</param>
		/// <returns>Validation result</returns>
		ValidationResult Validate<TType>(TType obj, bool includeDefaultRules = true, params string[] ruleSetNames);

		/// <summary>
		/// Validates the object within the scope of the given rule set names and throws an exception if an error occurs
		/// </summary>
		/// <param name="obj">Object instance</param>
		/// <param name="includeDefaultRules">Whether to include rules not in any rulesets</param>
		/// <param name="ruleSetNames">Names of the rule sets to validate. If not specified the complete object is validated</param>
		void ThrowOnValidationError<TType>(TType obj, bool includeDefaultRules = true, params string[] ruleSetNames);

		/// <summary>
		/// Validates the object within the scope of the given rule set names
		/// </summary>
		/// <param name="obj">Object instance</param>
		/// <param name="includeDefaultRules">Whether to include rules not in any rulesets</param>
		/// <param name="ruleSetNames">Names of the rule sets to validate. If not specified the complete object is validated</param>
		/// <returns>Validation result</returns>
		[SuppressMessage("Microsoft.Design", "CA1004:GenericMethodsShouldProvideTypeParameter")]
		ValidationResult Validate<TType, TValidatorType>(TType obj, bool includeDefaultRules = true, params string[] ruleSetNames)
			where TValidatorType : IValidator<TType>, new();

		/// <summary>
		/// Validates the object within the scope of the given rule set names and throws an exception if an error occurs
		/// </summary>
		/// <param name="obj">Object instance</param>
		/// <param name="includeDefaultRules">Whether to include rules not in any rulesets</param>
		/// <param name="ruleSetNames">Names of the rule sets to validate. If not specified the complete object is validated</param>
		[SuppressMessage("Microsoft.Design", "CA1004:GenericMethodsShouldProvideTypeParameter")]
		void ThrowOnValidationError<TType, TValidatorType>(TType obj, bool includeDefaultRules = true, params string[] ruleSetNames)
			where TValidatorType : IValidator<TType>, new();

		/// <summary>
		/// Validates the object within the scope of the given rule set names
		/// </summary>
		/// <param name="obj">Object instance</param>
		/// <param name="validator">Validator to be used</param>
		/// <param name="includeDefaultRules">Whether to include rules not in any rulesets</param>
		/// <param name="ruleSetNames">Names of the rule sets to validate. If not specified the complete object is validated</param>
		/// <returns>Validation result</returns>
		ValidationResult Validate<TType, TValidatorType>(TType obj, TValidatorType validator, bool includeDefaultRules = true, params string[] ruleSetNames)
			where TValidatorType: IValidator<TType>;

		/// <summary>
		/// Validates the object within the scope of the given rule set names and throws an exception if an error occurs
		/// </summary>
		/// <param name="obj">Object instance</param>
		/// <param name="validator">Validator to be used</param>
		/// <param name="includeDefaultRules">Whether to include rules not in any rulesets</param>
		/// <param name="ruleSetNames">Names of the rule sets to validate. If not specified the complete object is validated</param>
		void ThrowOnValidationError<TType, TValidatorType>(TType obj, TValidatorType validator, bool includeDefaultRules = true, params string[] ruleSetNames)
			where TValidatorType : IValidator<TType>;
	}
}
