﻿namespace FRT.Validation
{
	/// <summary>
	/// Default validator accessor
	/// </summary>
	public interface IDefaultValidatorAccessor
	{
		/// <summary>
		/// Gets the default validator for the given object type
		/// </summary>
		/// <typeparam name="TType">Object type</typeparam>
		/// <returns>Default validator</returns>
		IValidator<TType> GetDefaultValidator<TType>();
	}
}
