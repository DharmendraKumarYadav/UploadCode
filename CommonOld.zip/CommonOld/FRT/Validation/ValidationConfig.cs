﻿namespace FRT.Validation
{
	/// <summary>
	/// Validation Configuration
	/// </summary>
	public sealed class ValidationConfig : IInjectableConfig
	{
	}
}
