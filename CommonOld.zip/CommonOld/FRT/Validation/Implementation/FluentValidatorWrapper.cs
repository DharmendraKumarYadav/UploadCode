﻿using System;
using System.Linq;
using FluentValidation;

namespace FRT.Validation
{
	/// <summary>
	/// Wrapper for Fluent Validation Wrapper
	/// </summary>
	internal sealed class FluentValidatorWrapper<TType> : Validator<TType>
	{
		private readonly FluentValidation.IValidator<TType> _validator;

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="validator">Fluent validator</param>
		public FluentValidatorWrapper(FluentValidation.IValidator<TType> validator)
		{
			_validator = validator;
		}

		/// <summary>
		/// Validates the object within the scope of the given rule set names
		/// </summary>
		/// <param name="obj">Object instance</param>
		/// <param name="includeDefaultRules">Whether to include rules not in any rulesets</param>
		/// <param name="ruleSetNames">Names of the rule sets to validate. If not specified the complete object is validated</param>
		/// <returns>Validation result</returns>
		public override ValidationResult Validate(TType obj, bool includeDefaultRules = true, params string[] ruleSetNames)
		{
			if (obj == null)
			{
				throw new ArgumentNullException(nameof(obj));
			}
			ruleSetNames = (ruleSetNames ?? new string[0]).Where(r => !string.IsNullOrWhiteSpace(r)).Select(r => r.Trim()).ToArray();

			// Validate
			FluentValidation.Results.ValidationResult fluentResult;
			if (ruleSetNames.Any())
			{
				if (includeDefaultRules)
				{
					ruleSetNames = ruleSetNames.Union(new[] {"default"}).Distinct().ToArray();
				}
				fluentResult = _validator.Validate(obj, ruleSet: string.Join(",", ruleSetNames));
			}
			else
			{
				fluentResult = _validator.Validate(obj);
			}

			// Convert
			var result = new ValidationResult {Success = fluentResult.IsValid};
			if (!result.Success)
			{
				result.Errors = fluentResult.Errors.Select(e => new ValidationError(e.PropertyName)
				{
					AttemptedValue = e.AttemptedValue,
					Message = e.ErrorMessage
				}).ToArray();
			}

			// Return
			return result;
		}
	}
}
