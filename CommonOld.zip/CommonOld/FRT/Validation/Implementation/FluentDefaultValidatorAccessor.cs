﻿using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using Microsoft.Extensions.DependencyInjection;
using FluentValidation.Attributes;
using FluentValidation.Internal;

namespace FRT.Validation
{
	/// <summary>
	/// IDefaultValidatorAccessor
	/// </summary>
	public class FluentDefaultValidatorAccessor : IDefaultValidatorAccessor
	{
		private readonly InstanceCache _instanceCache = new InstanceCache();

		/// <summary>
		/// Gets the default validator for the given object type
		/// </summary>
		/// <typeparam name="TType">Object type</typeparam>
		/// <returns>Default validator</returns>
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
		public IValidator<TType> GetDefaultValidator<TType>()
		{
			// Check if there is any validator registered
			IValidator<TType> validator = null;
			try { validator = DI.Container.GetService<IValidator<TType>>(); }
			// ReSharper disable once EmptyGeneralCatchClause
			catch { }
			if (validator != null)
			{
				return validator;
			}

			// Check attribute
			var valAttr = typeof(TType).GetTypeInfo().GetCustomAttribute<ValidatorAttribute>();
			if (valAttr != null)
			{
				var flVal = _instanceCache.GetOrCreateInstance(valAttr.ValidatorType) as FluentValidation.IValidator<TType>;
				if (flVal != null)
				{
					return new FluentValidatorWrapper<TType>(flVal);
				}
			}
			return null;
		}
	}
}
