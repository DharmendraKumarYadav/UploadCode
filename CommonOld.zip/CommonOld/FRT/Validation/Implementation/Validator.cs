﻿using System;

namespace FRT.Validation
{
	/// <summary>
	/// IValidator
	/// </summary>
	public abstract class Validator<TType> : IValidator<TType>
	{
		/// <summary>
		/// Validates the object within the scope of the given rule set names
		/// </summary>
		/// <param name="obj">Object instance</param>
		/// <param name="includeDefaultRules">Whether to include rules not in any rulesets</param>
		/// <param name="ruleSetNames">Names of the rule sets to validate. If not specified the complete object is validated</param>
		/// <returns>Validation result</returns>
		public abstract ValidationResult Validate(TType obj, bool includeDefaultRules = true, params string[] ruleSetNames);

		/// <summary>
		/// Validates the object within the scope of the given rule set names and throws an exception if an error occurs
		/// </summary>
		/// <param name="obj">Object instance</param>
		/// <param name="includeDefaultRules">Whether to include rules not in any rulesets</param>
		/// <param name="ruleSetNames">Names of the rule sets to validate. If not specified the complete object is validated</param>
		public void ThrowOnValidationError(TType obj, bool includeDefaultRules = true, params string[] ruleSetNames)
		{
			if (obj == null)
			{
				throw new ArgumentNullException(nameof(obj));
			}

			var result = Validate(obj, includeDefaultRules, ruleSetNames);
			if (!result)
			{
				throw new ValidationException(result.Errors);
			}
		}
	}
}
