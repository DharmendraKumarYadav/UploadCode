﻿using System;
using System.Linq;

namespace FRT.Validation
{
	/// <summary>
	/// IValidationManager
	/// </summary>
	public class ValidationManager : IValidationManager
	{
		private readonly IDefaultValidatorAccessor _defaultValidatorAccessor;

		/// <summary>
		/// Constructor
		/// </summary>
		public ValidationManager(IDefaultValidatorAccessor defaultValidatorAccessor)
		{
			_defaultValidatorAccessor = defaultValidatorAccessor;
		}

		/// <summary>
		/// Gets the default validator for the given object type
		/// </summary>
		/// <typeparam name="TType">Object type</typeparam>
		/// <returns>Default validator</returns>
		public IValidator<TType> GetDefaultValidator<TType>()
		{
			return _defaultValidatorAccessor.GetDefaultValidator<TType>();
		}

		/// <summary>
		/// Validates the object within the scope of the given rule set names
		/// </summary>
		/// <param name="obj">Object instance</param>
		/// <param name="includeDefaultRules">Whether to include rules not in any rulesets</param>
		/// <param name="ruleSetNames">Names of the rule sets to validate. If not specified the complete object is validated</param>
		/// <returns>Validation result</returns>
		public ValidationResult Validate<TType>(TType obj, bool includeDefaultRules = true, params string[] ruleSetNames)
		{
			if (obj == null)
			{
				throw new ArgumentNullException(nameof(obj));
			}
			return Validate(obj, GetDefaultValidator<TType>(), includeDefaultRules, ruleSetNames);
		}

		/// <summary>
		/// Validates the object within the scope of the given rule set names and throws an exception if an error occurs
		/// </summary>
		/// <param name="obj">Object instance</param>
		/// <param name="includeDefaultRules">Whether to include rules not in any rulesets</param>
		/// <param name="ruleSetNames">Names of the rule sets to validate. If not specified the complete object is validated</param>
		public void ThrowOnValidationError<TType>(TType obj, bool includeDefaultRules = true, params string[] ruleSetNames)
		{
			if (obj == null)
			{
				throw new ArgumentNullException(nameof(obj));
			}
			ThrowOnValidationError(obj, GetDefaultValidator<TType>(), includeDefaultRules, ruleSetNames);
		}

		/// <summary>
		/// Validates the object within the scope of the given rule set names
		/// </summary>
		/// <param name="obj">Object instance</param>
		/// <param name="includeDefaultRules">Whether to include rules not in any rulesets</param>
		/// <param name="ruleSetNames">Names of the rule sets to validate. If not specified the complete object is validated</param>
		/// <returns>Validation result</returns>
		public ValidationResult Validate<TType, TValidatorType>(TType obj, bool includeDefaultRules = true, params string[] ruleSetNames)
			where TValidatorType : IValidator<TType>, new()
		{
			if (obj == null)
			{
				throw new ArgumentNullException(nameof(obj));
			}
			return Validate(obj, new TValidatorType(), includeDefaultRules, ruleSetNames);
		}

		/// <summary>
		/// Validates the object within the scope of the given rule set names and throws an exception if an error occurs
		/// </summary>
		/// <param name="obj">Object instance</param>
		/// <param name="includeDefaultRules">Whether to include rules not in any rulesets</param>
		/// <param name="ruleSetNames">Names of the rule sets to validate. If not specified the complete object is validated</param>
		public void ThrowOnValidationError<TType, TValidatorType>(TType obj, bool includeDefaultRules = true, params string[] ruleSetNames)
			where TValidatorType : IValidator<TType>, new()
		{
			if (obj == null)
			{
				throw new ArgumentNullException(nameof(obj));
			}
			ThrowOnValidationError(obj, new TValidatorType(), includeDefaultRules, ruleSetNames);
		}

		/// <summary>
		/// Validates the object within the scope of the given rule set names
		/// </summary>
		/// <param name="obj">Object instance</param>
		/// <param name="validator">Validator to be used</param>
		/// <param name="includeDefaultRules">Whether to include rules not in any rulesets</param>
		/// <param name="ruleSetNames">Names of the rule sets to validate. If not specified the complete object is validated</param>
		/// <returns>Validation result</returns>
		public virtual ValidationResult Validate<TType, TValidatorType>(TType obj, TValidatorType validator,
			bool includeDefaultRules = true, params string[] ruleSetNames)
			where TValidatorType : IValidator<TType>
		{
			if (obj == null)
			{
				throw new ArgumentNullException(nameof(obj));
			}
			if (validator == null)
			{
				throw new ArgumentNullException(nameof(validator));
			}

			ruleSetNames = (ruleSetNames ?? new string[0]).Where(r => !string.IsNullOrWhiteSpace(r)).Select(r => r.Trim()).ToArray();
			return validator.Validate(obj, includeDefaultRules, ruleSetNames);
		}

		/// <summary>
		/// Validates the object within the scope of the given rule set names and throws an exception if an error occurs
		/// </summary>
		/// <param name="obj">Object instance</param>
		/// <param name="validator">Validator to be used</param>
		/// <param name="includeDefaultRules">Whether to include rules not in any rulesets</param>
		/// <param name="ruleSetNames">Names of the rule sets to validate. If not specified the complete object is validated</param>
		public void ThrowOnValidationError<TType, TValidatorType>(TType obj, TValidatorType validator,
			bool includeDefaultRules = true, params string[] ruleSetNames)
			where TValidatorType : IValidator<TType>
		{
			if (obj == null)
			{
				throw new ArgumentNullException(nameof(obj));
			}
			if (validator == null)
			{
				throw new ArgumentNullException(nameof(validator));
			}

			var result = Validate(obj, validator, includeDefaultRules, ruleSetNames);
			if (!result)
			{
				throw new ValidationException(result.Errors);
			}
		}
	}
}
