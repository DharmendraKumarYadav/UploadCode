﻿namespace FRT
{
	/// <summary>
	/// Wrapper object to hold a value as a property
	/// </summary>
	/// <typeparam name="TPropertyType">PropertyName type</typeparam>
	public class PropertyContainer<TPropertyType>
	{
		/// <summary>
		/// Creates an instance of this type
		/// </summary>
		public PropertyContainer(TPropertyType value = default(TPropertyType))
		{
			Value = value;
		}

		/// <summary>
		/// Value
		/// </summary>
		public TPropertyType Value
		{
			get;
			set;
		}
	}
}
