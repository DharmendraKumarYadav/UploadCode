﻿namespace FRT
{
	/// <summary>
	/// Validator factory
	/// </summary>
	public interface IValidator<in TType>
	{
		/// <summary>
		/// Validates the object within the scope of the given rule set names
		/// </summary>
		/// <param name="obj">Object instance</param>
		/// <param name="includeDefaultRules">Whether to include rules not in any rulesets</param>
		/// <param name="ruleSetNames">Names of the rule sets to validate. If not specified the complete object is validated</param>
		/// <returns>Validation result</returns>
		ValidationResult Validate(TType obj, bool includeDefaultRules = true, params string[] ruleSetNames);

		/// <summary>
		/// Validates the object within the scope of the given rule set names and throws an exception if an error occurs
		/// </summary>
		/// <param name="obj">Object instance</param>
		/// <param name="includeDefaultRules">Whether to include rules not in any rulesets</param>
		/// <param name="ruleSetNames">Names of the rule sets to validate. If not specified the complete object is validated</param>
		void ThrowOnValidationError(TType obj, bool includeDefaultRules = true, params string[] ruleSetNames);
	}
}
