﻿using System;
using System.Linq;
using System.Reflection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace FRT.Web
{
	/// <summary>
	/// Base class for config files
	/// </summary>
	public static class ConfigBuilder
	{
		private static readonly Type _optionsType = typeof(IOptions<>);
		private static readonly MethodInfo _configureInternalMethod = typeof(ConfigBuilder).GetMethod("ConfigureInternal", BindingFlags.NonPublic | BindingFlags.Static);

		// ReSharper disable once UnusedMember.Local
		private static void ConfigureInternal<TConfig>(IServiceCollection services, Type parentType, PropertyInfo propertyInfo, Dictionary<Type, bool> configuredTypes)
			where TConfig : class
		{
			// Return if already configured
			var configType = typeof(TConfig);
			if (configuredTypes.ContainsKey(configType))
			{
				return;
			}

			// Create a configure options object
			var parentOptionsType = _optionsType.MakeGenericType(parentType);
			var parentOptionsValueProperty = parentOptionsType.GetProperty("Value", BindingFlags.Public | BindingFlags.Instance);
			var configureOptions = new ConfigureOptions<TConfig>(config =>
			{
				if (config == null)
				{
					return;
				}

				var parentOptions = DI.Container.GetService(parentOptionsType);
				var parentInstance = parentOptionsValueProperty.GetValue(parentOptions);
				var propertyValue = propertyInfo.GetValue(parentInstance);

				if (propertyValue != null)
				{
					Crosscuttings.Mapper.Map(propertyValue, config, propertyValue.GetType(), config.GetType());
				}
			});

			// Register it
			services.AddSingleton<IConfigureOptions<TConfig>>(configureOptions);

			// Add in configured types
			configuredTypes[configType] = true;

			// Config type
			services.AddScoped(configType, sp =>
			{
				var optionsType = _optionsType.MakeGenericType(configType);
				var optionsValueProperty = optionsType.GetProperty("Value", BindingFlags.Public | BindingFlags.Instance);
				return optionsValueProperty.GetValue(sp.GetRequiredService(optionsType));
			});

			// Enumerate sub-properties
			configType.GetProperties(BindingFlags.Public | BindingFlags.Instance)
				.Select(p => new { Property = p, Type = p.PropertyType, TypeInfo = p.PropertyType.GetTypeInfo() })
				.Where(p => typeof(IInjectableConfig).IsAssignableFrom(p.Type)
							&& p.Property.CanRead && !p.TypeInfo.IsArray
							&& p.TypeInfo.IsClass && !p.TypeInfo.IsAbstract
							&& p.TypeInfo.IsPublic)
				.ToList()
				.ForEach(p =>
				{
					_configureInternalMethod.MakeGenericMethod(p.Type)
						.Invoke(null, new object[] { services, configType, p.Property, configuredTypes });
				});
		}

		[SuppressMessage("Microsoft.Maintainability", "CA1506:AvoidExcessiveClassCoupling")]
		public static void BuildOptionsConfigurations<TConfig>(this IServiceCollection services, IConfiguration configuration)
			where TConfig : class
		{
			// Create a configure options object
			var configType = typeof(TConfig);
			var configureOptions = new ConfigureOptions<TConfig>(configuration.Bind);

			// Register it
			services.AddSingleton<IConfigureOptions<TConfig>>(configureOptions);
			services.AddScoped(configType, sp =>
			{
				var optionsType = _optionsType.MakeGenericType(configType);
				var optionsValueProperty = optionsType.GetProperty("Value", BindingFlags.Public | BindingFlags.Instance);
				return optionsValueProperty.GetValue(sp.GetRequiredService(optionsType));
			});

			// Do it for Sub-properties of IInjectableConfig
			var configuredTypes = new Dictionary<Type, bool> {[configType] = true};

			// Enumerate sub-properties
			configType.GetProperties(BindingFlags.Public | BindingFlags.Instance)
				.Select(p => new {Property = p, Type = p.PropertyType, TypeInfo = p.PropertyType.GetTypeInfo()})
				.Where(p => typeof(IInjectableConfig).IsAssignableFrom(p.Type)
				            && p.Property.CanRead && !p.TypeInfo.IsArray
				            && p.TypeInfo.IsClass && !p.TypeInfo.IsAbstract
				            && p.TypeInfo.IsPublic)
				.ToList()
				.ForEach(p =>
				{
					_configureInternalMethod.MakeGenericMethod(p.Type)
						.Invoke(null, new object[] {services, configType, p.Property, configuredTypes});
				});

			// Work on already registered option types
			services.ToList().Select(sd => new { Sd = sd, Type = sd.ServiceType.GetTypeInfo() })
				.Where(t => t.Type.IsGenericType && (t.Type.GetGenericTypeDefinition() == typeof(IConfigureOptions<>)))
				.ForEach(t =>
				{
					var configType1 = t.Type.GenericTypeArguments[0];
					if (!configuredTypes.ContainsKey(configType1))
					{
						// Add as configured
						configuredTypes[configType1] = true;

						// Options type
						var optionsType = typeof(IOptions<>).MakeGenericType(configType1);
						var valueProperty = optionsType
							.GetProperty("Value", BindingFlags.Public | BindingFlags.Instance);
						services.Add(new ServiceDescriptor(
							configType1, sp => valueProperty.GetValue(sp.GetRequiredService(optionsType)), t.Sd.Lifetime));
					}
				});
		}
	}
}
