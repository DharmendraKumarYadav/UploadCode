﻿namespace FRT
{
	/// <summary>
	/// Interface marker for all injectable configuration classes
	/// </summary>
	public interface IInjectableConfig
	{
	}
}
