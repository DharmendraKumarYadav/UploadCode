﻿using CacheManager.Core;

namespace FRT.Caching
{
	/// <summary>
	/// Cache Factory
	/// </summary>
	public interface ICacheFactory
	{
		/// <summary>
		/// Cache manager
		/// </summary>
		ICacheManager<object> Create();
	}
}
