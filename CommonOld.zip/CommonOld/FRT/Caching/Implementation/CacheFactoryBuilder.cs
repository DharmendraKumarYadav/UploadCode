﻿using System;
using CacheManager.Core;

namespace FRT.Caching
{
	/// <summary>
	/// Cache builder
	/// </summary>
	public sealed class CacheFactoryBuilder : ICacheFactory
	{
		private readonly ICacheManagerConfiguration _configuration;

		/// <summary>
		/// Constructor
		/// </summary>
		public CacheFactoryBuilder(ICacheManagerConfiguration config)
		{
			_configuration = config;
		}

		/// <summary>
		/// Cache manager
		/// </summary>
		public ICacheManager<object> Create() => CacheFactory.FromConfiguration<object>(_configuration);
	}
}
