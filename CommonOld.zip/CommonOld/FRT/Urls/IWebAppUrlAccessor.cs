﻿using System;

namespace FRT
{
	/// <summary>
	/// Provides a base url context for url resolution
	/// </summary>
	public interface IWebAppUrlAccessor
	{
		/// <summary>
		/// Base Uri of the application root
		/// </summary>
		Uri ApplicationBaseUri { get; }

		/// <summary>
		/// Request Uri
		/// </summary>
		Uri RequestUri { get; }
	}
}
