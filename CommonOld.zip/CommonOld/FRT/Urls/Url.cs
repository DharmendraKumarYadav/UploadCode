﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Text;
using Microsoft.Extensions.DependencyInjection;
using FRT.Properties;

namespace FRT
{
	/// <summary>
	/// Type
	/// </summary>
	public enum UrlType
	{
		None,
		Relative,
		AppRelative,
		Server,
		Absolute
	}

	/// <summary>
	/// Url processor
	/// </summary>
	public sealed class Url
	{
		private static readonly Lazy<Uri> _applicationDomainUri;
		private static readonly Lazy<string> _applicationVirtualPath;

		#region Static

		/// <summary>
		/// Static Construction
		/// </summary>
		[SuppressMessage("Microsoft.Performance", "CA1810:InitializeReferenceTypeStaticFieldsInline")]
		static Url()
		{
			_applicationDomainUri = new Lazy<Uri>(() =>
			{
				var baseUri = WebApplicationBaseUri;
				if (baseUri == null)
				{
					return null;
				}
				return new Uri(baseUri.GetComponents(UriComponents.SchemeAndServer, UriFormat.Unescaped));
			});
			_applicationVirtualPath = new Lazy<string>(() =>
			{
				var baseUri = WebApplicationBaseUri;
				if (baseUri == null)
				{
					return null;
				}
				var path = baseUri.GetComponents(UriComponents.Path, UriFormat.Unescaped);
				return "/" + path.Trim('/');
			});
		}

		/// <summary>
		/// Application web uri
		/// </summary>
		[SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
		public static Uri WebApplicationBaseUri => DI.Container.GetService<IWebAppUrlAccessor>()?.ApplicationBaseUri;

		/// <summary>
		/// Domain root for url resolution
		/// </summary>
		public static Uri WebApplicationDomainUri => _applicationDomainUri.Value;

		/// <summary>
		/// Virtual path for url resolution
		/// </summary>
		public static string WebApplicationVirtualPath => _applicationVirtualPath.Value;

		/// <summary>
		/// Current Request Uri
		/// </summary>
		public static Uri WebApplicationCurrentRequestUri => DI.Container.GetService<IWebAppUrlAccessor>()?.RequestUri;

		#endregion

		#region Constructor

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="url">Url string</param>
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#")]
		public Url(string url)
		{
			RawUrl = url;
			Type = GetType(url);
		}

		#endregion

		#region Properties

		/// <summary>
		/// Raw url
		/// </summary>
		[SuppressMessage("Microsoft.Design", "CA1056:UriPropertiesShouldNotBeStrings")]
		public string RawUrl { get; }

		/// <summary>
		/// Url type
		/// </summary>
		[SuppressMessage("Microsoft.Naming", "CA1721:PropertyNamesShouldNotMatchGetMethods")]
		public UrlType Type { get; }

		#endregion

		#region Overrides

		/// <summary>
		/// To string
		/// </summary>
		public override string ToString()
		{
			return RawUrl;
		}

		/// <summary>
		/// Hash code
		/// </summary>
		public override int GetHashCode()
		{
			return RawUrl.GetHashCode();
		}

		/// <summary>
		/// Equality
		/// </summary>
		/// <param name="other">Other instance</param>
		public override bool Equals(object other)
		{
			var otherUrl = other as Url;
			if (otherUrl == null)
			{
				return false;
			}
			return string.Equals(RawUrl, otherUrl.RawUrl, StringComparison.OrdinalIgnoreCase);
		}

		#endregion

		#region Operators

		/// <summary>
		/// String conversion
		/// </summary>
		/// <param name="url">Url instance</param>
		public static implicit operator string(Url url)
		{
			return url?.RawUrl;
		}

		/// <summary>
		/// Url conversion
		/// </summary>
		/// <param name="url">Url string</param>
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#")]
		public static implicit operator Url(string url)
		{
			return new Url(url);
		}

		#endregion

		#region Methods

		/// <summary>
		/// Checks if the specified url is valid
		/// </summary>
		/// <param name="url"></param>
		/// <param name="uriKind"></param>
		/// <returns></returns>
		[SuppressMessage("Microsoft.Usage", "CA1806:DoNotIgnoreMethodResults", MessageId = "System.Uri")]
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
		private static bool IsValidUrlFormat(string url, UriKind uriKind)
		{
			try
			{
				// ReSharper disable once ObjectCreationAsStatement
				new Uri(url, uriKind);
				return true;
			}
			catch
			{
				return false;
			}
		}

		/// <summary>
		/// Converts the url to the specified type
		/// </summary>
		/// <param name="type">Target type</param>
		/// <param name="contextUrl">Url for relative url context</param>
		/// <returns>Url</returns>
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "1#")]
		public Url ToType(UrlType type, string contextUrl = null)
		{
			return Convert(RawUrl, type, contextUrl);
		}

		#endregion

		#region Conversion
		/// <summary>
		/// Current context url
		/// </summary>
		/// <param name="contextUrl">Specified context url</param>
		/// <returns></returns>
		private static string GetContextUrlDir(string contextUrl = null)
		{
			// Adjust
			contextUrl = string.IsNullOrWhiteSpace(contextUrl)
				? WebApplicationCurrentRequestUri?.ToString()
				: Convert(contextUrl, UrlType.Absolute);
			if (contextUrl == null)
			{
				throw new InvalidOperationException(LocalResources.S_UrlConversionFailedContextUrlNotAvailable);
			}

			// Strip trailers
			contextUrl = StripTrailers(contextUrl);

			// Remove the file name part
			if (!contextUrl.EndsWith("/", StringComparison.OrdinalIgnoreCase))
			{
				var lastSlashIndex = contextUrl.LastIndexOf('/');
				if (lastSlashIndex >= 0)
				{
					contextUrl = contextUrl.Substring(0, lastSlashIndex + 1);
				}
				else
				{
					contextUrl += "/";
				}
			}

			// Determine
			return contextUrl;
		}

		/// <summary>
		/// Url type
		/// </summary>
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
		[SuppressMessage("Microsoft.Usage", "CA1806:DoNotIgnoreMethodResults", MessageId = "System.Uri")]
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#")]
		public static UrlType GetType(string url)
		{
			// Validate
			if (string.IsNullOrWhiteSpace(url)
				|| !IsValidUrlFormat(url = url.Trim(), UriKind.RelativeOrAbsolute))
			{
				return UrlType.None;
			}

			// Check App
			if (string.Equals(url, "~", StringComparison.Ordinal)
				|| url.StartsWith("~/", StringComparison.Ordinal))
			{
				return UrlType.AppRelative;
			}

			// Check Server
			if (url.StartsWith("/", StringComparison.Ordinal))
			{
				return UrlType.Server;
			}

			// Check Absolute
			try
			{
				// ReSharper disable once ObjectCreationAsStatement
				new Uri(url, UriKind.Absolute);
				return UrlType.Absolute;
			}
			// ReSharper disable once EmptyGeneralCatchClause
			catch { }

			// Relative
			return UrlType.Relative;
		}

		/// <summary>
		/// Converts one type to the other
		/// </summary>
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "2#")]
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		public static string Convert(string url, UrlType type, string contextUrl = null)
		{
			// Validate
			if (string.IsNullOrWhiteSpace(url))
			{
				throw new ArgumentNullException(nameof(url));
			}
			if (!IsValidUrlFormat(url = url.Trim(), UriKind.RelativeOrAbsolute))
			{
				throw new ArgumentException(CommonResources.S_InvalidUrlFormat, nameof(url));
			}
			contextUrl = string.IsNullOrWhiteSpace(contextUrl) ? null : contextUrl.Trim();
			contextUrl = (contextUrl != null) ? StripTrailers(contextUrl) : null;
			if ((contextUrl != null) && !IsValidUrlFormat(contextUrl, UriKind.RelativeOrAbsolute))
			{
				throw new ArgumentException(CommonResources.S_InvalidUrlFormat, nameof(contextUrl));
			}
			if (type == UrlType.None)
			{
				throw new ArgumentOutOfRangeException(nameof(type));
			}

			// Convert
			var srcType = GetType(url);
			string newUrl = null;

			string trailers;
			url = StripTrailers(url, out trailers);

			// Helper
			// ReSharper disable once ConvertToLocalFunction
			Func<string, string> trailSlashIt = url1 =>
			{
				if (url1 == null)
				{
					return null;
				}
				return url1.Trim().TrimEnd('/', '\\', ' ', '\t', '\f', '\v') + "/";
			};

			// Same type
			if (srcType == type)
			{
				newUrl = url;
			}
			else
			{
				if (type == UrlType.Absolute)
				{
					if (srcType == UrlType.AppRelative)
					{
						if (WebApplicationBaseUri == null)
						{
							throw new InvalidOperationException(LocalResources.S_UrlConversionFailedContextUrlNotAvailable);
						}
						var appUrl = trailSlashIt(WebApplicationBaseUri.ToString());
						newUrl = (url.Length == 1) ? appUrl : Combine(appUrl, url.Substring(1));
					}
					else if (srcType == UrlType.Server)
					{
						if (WebApplicationDomainUri == null)
						{
							throw new InvalidOperationException(LocalResources.S_UrlConversionFailedContextUrlNotAvailable);
						}
						var domainUrl = trailSlashIt(WebApplicationDomainUri.ToString());
						newUrl = Combine(domainUrl, url);
					}
					else if (srcType == UrlType.Relative)
					{
						newUrl = Combine(GetContextUrlDir(contextUrl), url);
					}
				}
				else if (type == UrlType.Server)
				{
					if (srcType == UrlType.Absolute)
					{
						newUrl = new Uri(url, UriKind.Absolute).GetComponents(UriComponents.Path, UriFormat.Unescaped);
					}
					else if (srcType == UrlType.AppRelative)
					{
						if (WebApplicationVirtualPath == null)
						{
							throw new InvalidOperationException(LocalResources.S_UrlConversionFailedContextUrlNotAvailable);
						}
						var appVPath = WebApplicationVirtualPath;
						newUrl = (url.Length == 1) ? appVPath : Combine(appVPath, url.Substring(1));
					}
					else if (srcType == UrlType.Relative)
					{
						newUrl = new Uri(Combine(GetContextUrlDir(contextUrl), url), UriKind.Absolute).GetComponents(UriComponents.Path, UriFormat.Unescaped);
					}
				}
				else if (type == UrlType.AppRelative)
				{
					if (WebApplicationVirtualPath == null)
					{
						throw new InvalidOperationException(LocalResources.S_UrlConversionFailedContextUrlNotAvailable);
					}
					var appVPath = WebApplicationVirtualPath;
					if (srcType == UrlType.Absolute)
					{
						var serverPath = new Uri(url, UriKind.Absolute).GetComponents(UriComponents.Path, UriFormat.Unescaped);
						newUrl = Combine("~", serverPath.StartsWith(appVPath, StringComparison.OrdinalIgnoreCase)
							? serverPath.Substring(appVPath.Length)
							: serverPath);
					}
					else if (srcType == UrlType.Server)
					{
						newUrl = Combine("~", url.StartsWith(appVPath, StringComparison.OrdinalIgnoreCase)
							? url.Substring(appVPath.Length)
							: url);
					}
					else if (srcType == UrlType.Relative)
					{
						var serverPath = new Uri(Combine(GetContextUrlDir(contextUrl), url), UriKind.Absolute).GetComponents(UriComponents.Path, UriFormat.Unescaped);
						newUrl = Combine("~", serverPath.StartsWith(appVPath, StringComparison.OrdinalIgnoreCase)
							? serverPath.Substring(appVPath.Length)
							: serverPath);
					}
				}
				else if (type == UrlType.Relative)
				{
					contextUrl = GetContextUrlDir(contextUrl);
					var contextUri = new Uri(contextUrl, UriKind.Absolute);
					if (srcType == UrlType.Absolute)
					{
						var contextDomain = trailSlashIt(contextUri.GetComponents(UriComponents.SchemeAndServer, UriFormat.Unescaped));
						var uri = new Uri(url, UriKind.Absolute);
						var uriDomain = uri.GetComponents(UriComponents.SchemeAndServer, UriFormat.Unescaped);
						if (!string.Equals(contextDomain, uriDomain, StringComparison.OrdinalIgnoreCase))
						{
							throw new InvalidOperationException(LocalResources.S_AbsoluteToRelativeUrlConversionDomainsDoNotMatch);
						}
						newUrl = uri.MakeRelativeUri(contextUri).ToString();
					}
					else if (srcType == UrlType.Server)
					{
						if (WebApplicationDomainUri == null)
						{
							throw new InvalidOperationException(LocalResources.S_UrlConversionFailedContextUrlNotAvailable);
						}
						newUrl = new Uri(Combine(WebApplicationDomainUri.ToString(), url), UriKind.Absolute)
							.MakeRelativeUri(contextUri).ToString();
					}
					else if (srcType == UrlType.AppRelative)
					{
						if (WebApplicationBaseUri == null)
						{
							throw new InvalidOperationException(LocalResources.S_UrlConversionFailedContextUrlNotAvailable);
						}
						var appUrl = trailSlashIt(WebApplicationBaseUri.ToString());
						newUrl = new Uri((url.Length == 1) ? appUrl : Combine(appUrl, url.Substring(1)), UriKind.Absolute)
							.MakeRelativeUri(contextUri).ToString();
					}
				}
			}

			// Return
			return newUrl + (trailers ?? string.Empty);
		}
		#endregion

		#region Miscellaneous
		/// <summary>
		/// Combines two urls by stripping extra / characters between them
		/// </summary>
		/// <param name="url1">First url</param>
		/// <param name="url2">Second url</param>
		/// <returns>Combined url</returns>
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "1#")]
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#")]
		public static string Combine(string url1, string url2)
		{
			if (string.IsNullOrWhiteSpace(url1))
			{
				return url2;
			}
			else if (string.IsNullOrWhiteSpace(url2))
			{
				return url1;
			}
			else
			{
				var trimmedUrl1 = url1.TrimEnd('/', '\\', ' ');
				var trimmedUrl2 = url2.TrimStart('/', '\\', ' ');
				if (string.IsNullOrWhiteSpace(trimmedUrl1))
				{
					return url2;
				}
				else if (string.IsNullOrWhiteSpace(trimmedUrl2))
				{
					return url1;
				}
				return trimmedUrl1 + "/" + trimmedUrl2;
			}
		}

		/// <summary>
		/// Appends the specified query parameters to the url
		/// </summary>
		/// <param name="urlEncodedQueryParameters">Object dictionary containing the url encoded query parameter name-value properties</param>
		/// <returns>New url with the query parameters appended</returns>
		public Url AppendQueryParameters(object urlEncodedQueryParameters)
		{
			return new Url(AppendQueryParameters(RawUrl, urlEncodedQueryParameters));
		}

		/// <summary>
		/// Appends the specified query parameters to the url
		/// </summary>
		/// <param name="url">Url</param>
		/// <param name="urlEncodedQueryParameters">Object dictionary containing the url encoded query parameter name-value properties</param>
		/// <returns>New url with the query parameters appended</returns>
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#")]
		public static string AppendQueryParameters(string url, object urlEncodedQueryParameters)
		{
			if (urlEncodedQueryParameters == null)
			{
				return url;
			}
			return AppendQueryParameters(url, urlEncodedQueryParameters.ToDictionary());
		}

		/// <summary>
		/// Appends the specified query parameters to the url
		/// </summary>
		/// <param name="queryString">String dictionary containing the url encoded query parameter name-value pairs</param>
		/// <returns>New url with the query parameters appended</returns>
		public Url AppendQueryParameters(IDictionary<string, object> queryString)
		{
			return AppendQueryParameters(RawUrl, queryString);
		}

		/// <summary>
		/// Appends the specified query parameters to the url
		/// </summary>
		/// <param name="url">Url</param>
		/// <param name="queryString">String dictionary containing the url encoded query parameter name-value pairs</param>
		/// <returns>New url with the query parameters appended</returns>
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#")]
		public static Url AppendQueryParameters(string url, IDictionary<string, object> queryString)
		{
			IDictionary<string, string> data = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
			data.AddRange(queryString.Select(q => new KeyValuePair<string, string>(q.Key, q.Value?.ToString() ?? String.Empty)));
			return new Url(AppendQueryParameters(url, data));
		}

		/// <summary>
		/// Appends the specified query parameters to the url
		/// </summary>
		/// <param name="queryString">String dictionary containing the url encoded query parameter name-value pairs</param>
		/// <returns>New url with the query parameters appended</returns>
		public Url AppendQueryParameters(IDictionary<string, string> queryString)
		{
			return AppendQueryParameters(RawUrl, queryString);
		}

		/// <summary>
		/// Appends the specified query parameters to the url
		/// </summary>
		/// <param name="url">Url</param>
		/// <param name="queryString">String dictionary containing the url encoded query parameter name-value pairs</param>
		/// <returns>New url with the query parameters appended</returns>
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#")]
		public static Url AppendQueryParameters(string url, IDictionary<string, string> queryString)
		{
			IDictionary<string, List<string>> data = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);
			data.AddRange(queryString.Select(q => new KeyValuePair<string, List<string>>(q.Key, new List<string>(new[] { q.Value }))));
			return new Url(AppendQueryParameters(url, data));
		}

		/// <summary>
		/// Appends the specified query parameters to the url
		/// </summary>
		/// <param name="urlEncodedQueryParameters">String dictionary containing the url encoded query parameter name-value pairs</param>
		/// <returns>New url with the query parameters appended</returns>
		public Url AppendQueryParameters(IDictionary<string, List<object>> urlEncodedQueryParameters)
		{
			return new Url(AppendQueryParameters(RawUrl, urlEncodedQueryParameters));
		}

		/// <summary>
		/// Appends the specified query parameters to the url
		/// </summary>
		/// <param name="url">Url</param>
		/// <param name="urlEncodedQueryParameters">String dictionary containing the url encoded query parameter name-value pairs</param>
		/// <returns>New url with the query parameters appended</returns>
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#")]
		public static string AppendQueryParameters(string url, IDictionary<string, List<object>> urlEncodedQueryParameters)
		{
			url = (url ?? string.Empty).Trim();
			if (url.Length == 0)
			{
				throw new ArgumentNullException(nameof(url));
			}

			if (urlEncodedQueryParameters == null)
			{
				return url;
			}

			Dictionary<string, List<string>> data = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);
			data.AddRange(urlEncodedQueryParameters.Select(q => new KeyValuePair<string, List<string>>(q.Key, new List<string>(new[] { q.Value?.ToString() ?? string.Empty }))));
			return AppendQueryParameters(url, data);
		}

		/// <summary>
		/// Appends the specified query parameters to the url
		/// </summary>
		/// <param name="queryString">String dictionary containing the url encoded query parameter name-value pairs</param>
		/// <returns>New url with the query parameters appended</returns>
		public Url AppendQueryParameters(IDictionary<string, List<string>> queryString)
		{
			return new Url(AppendQueryParameters(RawUrl, queryString));
		}

		/// <summary>
		/// Appends the specified query parameters to the url
		/// </summary>
		/// <param name="url">Url</param>
		/// <param name="queryString">String dictionary containing the url encoded query parameter name-value pairs</param>
		/// <returns>New url with the query parameters appended</returns>
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#")]
		public static string AppendQueryParameters(string url, IDictionary<string, List<string>> queryString)
		{
			url = (url ?? string.Empty).Trim();
			if (url.Length == 0)
			{
				throw new ArgumentNullException(nameof(url));
			}

			if (queryString == null)
			{
				return url;
			}

			StringBuilder sbBuffer = new StringBuilder();
			foreach (KeyValuePair<string, List<string>> entry in queryString)
			{
				string key = (entry.Key ?? string.Empty).Trim();
				if (key.Length > 0)
				{
					string[] values = entry.Value?.Select(v => v ?? string.Empty).ToArray() ?? new[] { string.Empty };

					// Append to buffer
					foreach (string str in values)
					{
						if (sbBuffer.Length > 0)
						{
							sbBuffer.Append("&");
						}
						sbBuffer.AppendFormat(CultureInfo.InvariantCulture, "{0}={1}", key, str);
					}
				}
			}

			// Append
			return AppendQueryParameters(url, sbBuffer.ToString());
		}

		/// <summary>
		/// Appends the specified query parameters to the url
		/// </summary>
		/// <param name="urlEncodedQueryString">Url encoded query string</param>
		/// <returns>New url with the query parameters appended</returns>
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#")]
		public Url AppendQueryParameters(string urlEncodedQueryString)
		{
			return new Url(AppendQueryParameters(RawUrl, urlEncodedQueryString));
		}

		/// <summary>
		/// Appends the specified query parameters to the url
		/// </summary>
		/// <param name="url">Url</param>
		/// <param name="urlEncodedQueryString">Url encoded query string</param>
		/// <returns>New url with the query parameters appended</returns>
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "1#")]
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#")]
		public static string AppendQueryParameters(string url, string urlEncodedQueryString)
		{
			url = (url ?? string.Empty).Trim();
			if (url.Length == 0)
			{
				throw new ArgumentNullException(nameof(url));
			}

			urlEncodedQueryString = (urlEncodedQueryString ?? string.Empty).Trim().Trim('&');
			if (urlEncodedQueryString.Length == 0)
			{
				return url;
			}

			string fragment;
			url = StripFragment(url, out fragment);

			if (url.IndexOf('?') >= 0)
			{
				if (url.EndsWith("&", StringComparison.Ordinal))
				{
					return url + urlEncodedQueryString + fragment;
				}
				else
				{
					return url + "&" + urlEncodedQueryString + fragment;
				}
			}
			else
			{
				return url + "?" + urlEncodedQueryString + fragment;
			}
		}

		/// <summary>
		/// Removes the specified query parameters from the url
		/// </summary>
		/// <param name="urlEncodedQueryParameterName">Parameter url encoded name to remove</param>
		/// <returns>New url with the query parameter removed</returns>
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#")]
		public Url StripQueryParameter(string urlEncodedQueryParameterName)
		{
			return new Url(StripQueryParameter(RawUrl, urlEncodedQueryParameterName));
		}

		/// <summary>
		/// Removes the specified query parameters from the url
		/// </summary>
		/// <param name="url">Url</param>
		/// <param name="urlEncodedQueryParameterName">Parameter url encoded name to remove</param>
		/// <returns>New url with the query parameter removed</returns>
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "1#")]
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#")]
		public static string StripQueryParameter(string url, string urlEncodedQueryParameterName)
		{
			return StripQueryParameters(url, new[] { urlEncodedQueryParameterName });
		}

		/// <summary>
		/// Splits the query string into name-value pairs
		/// </summary>
		/// <param name="queryString">Query string</param>
		/// <returns>Name-value pairs</returns>
		public static Dictionary<string, List<string>> ParseQueryString(string queryString)
		{
			Dictionary<string, List<string>> queryParams = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);
			if (!string.IsNullOrWhiteSpace(queryString))
			{
				queryString = queryString.StartsWith("?", StringComparison.Ordinal) ? queryString.Substring(1) : queryString;
				if (!string.IsNullOrWhiteSpace(queryString))
				{
					string[] nameValuePairParts = queryString.Split('&');

					// Split entries
					foreach (string str in nameValuePairParts)
					{
						Tuple<string, string> pair = SplitQueryParameterEntry(str);
						if (pair != null)
						{
							queryParams.Add(pair.Item1, pair.Item2);
						}
					}
				}
			}
			return queryParams;
		}

		/// <summary>
		/// Removes the specified query parameters from the url
		/// </summary>
		/// <param name="urlEncodedQueryParameterNames">List of parameter url encoded names to remove</param>
		/// <returns>New url with the query parameters removed</returns>
		public Url StripQueryParameters(IEnumerable<string> urlEncodedQueryParameterNames)
		{
			return new Url(StripQueryParameters(RawUrl, urlEncodedQueryParameterNames));
		}

		/// <summary>
		/// Removes the specified query parameters from the url
		/// </summary>
		/// <param name="url">Url</param>
		/// <param name="urlEncodedQueryParameterNames">List of parameter url encoded names to remove</param>
		/// <returns>New url with the query parameters removed</returns>
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#")]
		public static string StripQueryParameters(string url, IEnumerable<string> urlEncodedQueryParameterNames)
		{
			// Strip parts
			string queryString, fragment;
			url = StripTrailers(url, out queryString, out fragment);

			// Modify only if we have query string
			queryString = queryString?.TrimStart('?');
			if (!string.IsNullOrEmpty(queryString))
			{
				// Split
				string[] nameValuePairParts = queryString.Split('&');

				// Split entries
				var nameValuePairs = nameValuePairParts.Select(SplitQueryParameterEntry).ToList();
				nameValuePairs.RemoveAll(p => p == null);

				// Remove all matching parameters
				var urlEncodedQueryParameterNamesList = new List<string>(urlEncodedQueryParameterNames);
				string[] urlEncodedQueryParameterNamesArray = urlEncodedQueryParameterNamesList.ToArray();
				if (0 < nameValuePairs.RemoveAll(delegate (Tuple<string, string> p)
				{
					return Array.Find(urlEncodedQueryParameterNamesArray,
								str => string.Equals(p.Item1, str, StringComparison.OrdinalIgnoreCase)) != null;
				}))
				{
					// Rejoin them if atleast one is removed
					var sbBuffer = new StringBuilder();
					foreach (Tuple<string, string> item in nameValuePairs)
					{
						if (sbBuffer.Length > 0)
						{
							sbBuffer.Append("&");
						}
						sbBuffer.AppendFormat(CultureInfo.InvariantCulture, "{0}={1}", item.Item1, item.Item2);
					}
					queryString = sbBuffer.ToString();
					if (queryString.Length > 0)
					{
						queryString = "?" + queryString;
					}
				}
			}
			return url + queryString + fragment;
		}

		/// <summary>
		/// Splits the query parameter - value entry to name and value
		/// </summary>
		/// <param name="queryParameterEntry">Entry</param>
		/// <returns>Tuple of name and value</returns>
		private static Tuple<string, string> SplitQueryParameterEntry(string queryParameterEntry)
		{
			string[] parts = queryParameterEntry.Split('=');
			string value = string.Empty;

			// Split
			if (parts.Length > 0)
			{
				var name = parts[0].Trim();
				if (parts.Length > 1)
				{
					value = parts[1].Trim();
				}
				return new Tuple<string, string>(name, value);
			}
			return null;
		}

		/// <summary>
		/// Removes query string from the specified url
		/// </summary>
		/// <returns>Url with query string stripped</returns>
		public Url StripQueryString()
		{
			return new Url(StripQueryString(RawUrl));
		}

		/// <summary>
		/// Removes query string from the specified url
		/// </summary>
		/// <param name="url">Url</param>
		/// <returns>Url with query string stripped</returns>
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#")]
		public static string StripQueryString(string url)
		{
			string queryString;
			return StripQueryString(url, out queryString);
		}

		/// <summary>
		/// Removes query string from the specified url
		/// </summary>
		/// <param name="queryString">Stripped query string</param>
		/// <returns>Url with query string stripped</returns>
		[SuppressMessage("Microsoft.Design", "CA1021:AvoidOutParameters", MessageId = "0#")]
		[SuppressMessage("Microsoft.Design", "CA1021:AvoidOutParameters", MessageId = "1#")]
		public Url StripQueryString(out string queryString)
		{
			return new Url(StripQueryString(RawUrl, out queryString));
		}

		/// <summary>
		/// Removes query string from the specified url
		/// </summary>
		/// <param name="url">Url</param>
		/// <param name="queryString">Stripped query string</param>
		/// <returns>Url with query string stripped</returns>
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#")]
		[SuppressMessage("Microsoft.Design", "CA1021:AvoidOutParameters", MessageId = "1#")]
		public static string StripQueryString(string url, out string queryString)
		{
			// Trim & check
			url = (url ?? string.Empty).Trim();
			if (url.Length == 0)
			{
				throw new ArgumentNullException(nameof(url));
			}

			// Strip
			int qIndex = url.IndexOf('?');
			int hashIndex = url.IndexOf('#');

			if (qIndex >= 0)
			{
				if (hashIndex > qIndex)
				{
					queryString = url.Substring(qIndex, hashIndex - qIndex);
					url = url.Substring(0, qIndex) + url.Substring(hashIndex);
				}
				else
				{
					queryString = url.Substring(qIndex);
					url = url.Substring(0, qIndex);
				}
			}
			else
			{
				queryString = string.Empty;
			}
			return url;
		}

		/// <summary>
		/// Removes fragment from the specified url
		/// </summary>
		/// <returns>Url with fragment stripped</returns>
		public Url StripFragment()
		{
			return new Url(StripFragment(RawUrl));
		}

		/// <summary>
		/// Removes fragment from the specified url
		/// </summary>
		/// <param name="url">Url</param>
		/// <returns>Url with fragment stripped</returns>
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#")]
		public static string StripFragment(string url)
		{
			string fragment;
			return StripFragment(url, out fragment);
		}

		/// <summary>
		/// Removes fragment from the specified url
		/// </summary>
		/// <param name="fragment">Stripped fragment</param>
		/// <returns>Url with fragment stripped</returns>
		[SuppressMessage("Microsoft.Design", "CA1021:AvoidOutParameters", MessageId = "0#")]
		[SuppressMessage("Microsoft.Design", "CA1021:AvoidOutParameters", MessageId = "1#")]
		public Url StripFragment(out string fragment)
		{
			return new Url(StripFragment(RawUrl, out fragment));
		}

		/// <summary>
		/// Removes fragment from the specified url
		/// </summary>
		/// <param name="url">Url</param>
		/// <param name="fragment">Stripped fragment</param>
		/// <returns>Url with fragment stripped</returns>
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#")]
		[SuppressMessage("Microsoft.Design", "CA1021:AvoidOutParameters", MessageId = "1#")]
		public static string StripFragment(string url, out string fragment)
		{
			// Trim & check
			url = (url ?? string.Empty).Trim();
			if (url.Length == 0)
			{
				throw new ArgumentNullException(nameof(url));
			}

			// Strip
			int hashIndex = url.IndexOf('#');
			if (hashIndex >= 0)
			{
				fragment = url.Substring(hashIndex);
				url = url.Substring(0, hashIndex);
			}
			else
			{
				fragment = string.Empty;
			}
			return url;
		}

		/// <summary>
		/// Removes trailers from the specified url
		/// </summary>
		/// <returns>Url with trailers stripped</returns>
		public Url StripTrailers()
		{
			return new Url(StripTrailers(RawUrl));
		}

		/// <summary>
		/// Removes trailers from the specified url
		/// </summary>
		/// <param name="url">Url</param>
		/// <returns>Url with trailers stripped</returns>
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#")]
		public static string StripTrailers(string url)
		{
			string trailers;
			return StripTrailers(url, out trailers);
		}

		/// <summary>
		/// Removes trailers from the specified url
		/// </summary>
		/// <param name="trailers">Stripped trailers</param>
		/// <returns>Url with trailers stripped</returns>
		[SuppressMessage("Microsoft.Design", "CA1021:AvoidOutParameters", MessageId = "0#")]
		[SuppressMessage("Microsoft.Design", "CA1021:AvoidOutParameters", MessageId = "1#")]
		public Url StripTrailers(out string trailers)
		{
			return new Url(StripTrailers(RawUrl, out trailers));
		}

		/// <summary>
		/// Removes trailers from the specified url
		/// </summary>
		/// <param name="url">Url</param>
		/// <param name="trailers">Stripped trailers</param>
		/// <returns>Url with trailers stripped</returns>
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#")]
		[SuppressMessage("Microsoft.Design", "CA1021:AvoidOutParameters", MessageId = "1#")]
		public static string StripTrailers(string url, out string trailers)
		{
			// Trim & check
			url = (url ?? string.Empty).Trim();
			if (url.Length == 0)
			{
				throw new ArgumentNullException(nameof(url));
			}

			// Strip
			int sepIndex = url.IndexOfAny(new[] { '#', '?' });
			if (sepIndex >= 0)
			{
				trailers = url.Substring(sepIndex);
				url = url.Substring(0, sepIndex);
			}
			else
			{
				trailers = string.Empty;
			}
			return url;
		}

		/// <summary>
		/// Removes trailers from the specified url
		/// </summary>
		/// <param name="queryString">Stripped query string</param>
		/// <param name="fragment">Stripped fragment</param>
		/// <returns>Url with trailers stripped</returns>
		[SuppressMessage("Microsoft.Design", "CA1021:AvoidOutParameters", MessageId = "0#")]
		[SuppressMessage("Microsoft.Design", "CA1021:AvoidOutParameters", MessageId = "1#")]
		[SuppressMessage("Microsoft.Design", "CA1021:AvoidOutParameters", MessageId = "2#")]
		public Url StripTrailers(out string queryString, out string fragment)
		{
			return new Url(StripTrailers(RawUrl, out queryString, out fragment));
		}

		/// <summary>
		/// Removes trailers from the specified url
		/// </summary>
		/// <param name="url">Url</param>
		/// <param name="queryString">Stripped query string</param>
		/// <param name="fragment">Stripped fragment</param>
		/// <returns>Url with trailers stripped</returns>
		[SuppressMessage("Microsoft.Design", "CA1054:UriParametersShouldNotBeStrings", MessageId = "0#")]
		[SuppressMessage("Microsoft.Design", "CA1021:AvoidOutParameters", MessageId = "1#")]
		[SuppressMessage("Microsoft.Design", "CA1021:AvoidOutParameters", MessageId = "2#")]
		public static string StripTrailers(string url, out string queryString, out string fragment)
		{
			return StripQueryString(StripFragment(url, out fragment), out queryString);
		}
		#endregion
	}
}
