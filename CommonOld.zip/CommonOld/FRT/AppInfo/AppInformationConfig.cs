﻿using System.Diagnostics.CodeAnalysis;

namespace FRT
{
	/// <summary>
	/// Application information configuration
	/// </summary>
	public sealed class AppInformationConfig : IInjectableConfig
	{
		private string _applicationName;
		/// <summary>
		/// Display name of the application
		/// </summary>
		public string ApplicationName
		{
			get => _applicationName;
			set => _applicationName = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private string _applicationVersion;
		/// <summary>
		/// Semantic version of the application
		/// </summary>
		public string ApplicationVersion
		{
			get => _applicationVersion;
			set => _applicationVersion = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private string _applicationDisplayVersion;
		/// <summary>
		/// Display version of the application
		/// </summary>
		public string ApplicationDisplayVersion
		{
			get => _applicationDisplayVersion;
			set => _applicationDisplayVersion = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private string _applicationShortName;
		/// <summary>
		/// Application short name
		/// </summary>
		public string ApplicationShortName
		{
			get => _applicationShortName;
			set => _applicationShortName = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private string _companyShortName;
		/// <summary>
		/// Company short name
		/// </summary>
		public string CompanyShortName
		{
			get => _companyShortName;
			set => _companyShortName = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private string _companyUrl;
		/// <summary>
		/// Company url
		/// </summary>
		[SuppressMessage("Microsoft.Design", "CA1056:UriPropertiesShouldNotBeStrings")]
		public string CompanyUrl
		{
			get => _companyUrl;
			set => _companyUrl = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private string _companyName;
		/// <summary>
		/// Company name
		/// </summary>
		public string CompanyName
		{
			get => _companyName;
			set => _companyName = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private const string _defaultCopyrightOwner = "FR Tech&trade; Technologies Private Limited, INDIA. All rights reserved.";
		private string _copyrightOwner = _defaultCopyrightOwner;
		/// <summary>
		/// Copyright owner
		/// </summary>
		public string CopyrightOwner
		{
			get => _copyrightOwner;
			set => _copyrightOwner = string.IsNullOrWhiteSpace(value) ? _defaultCopyrightOwner : value.Trim();
		}

		private string _trademarks;
		/// <summary>
		/// Trademarks
		/// </summary>
		public string Trademarks
		{
			get => _trademarks;
			set => _trademarks = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		/// <summary>
		/// Copyright start year
		/// </summary>
		public int CopyrightStartYear
		{
			get;
			set;
		} = 2016;

		private string _applicationSupportEmail;
		/// <summary>
		/// Support email the application
		/// </summary>
		[SuppressMessage("Microsoft.Globalization", "CA1308:NormalizeStringsToUppercase")]
		[SuppressMessage("Microsoft.Design", "CA1056:UriPropertiesShouldNotBeStrings")]
		public string ApplicationSupportEmail
		{
			get => _applicationSupportEmail;
			set => _applicationSupportEmail = string.IsNullOrWhiteSpace(value) ? null : value.Trim().ToLowerInvariant();
		}

		private string _applicationTechSupportEmail;
		/// <summary>
		/// Tech Support email the application
		/// </summary>
		[SuppressMessage("Microsoft.Globalization", "CA1308:NormalizeStringsToUppercase")]
		[SuppressMessage("Microsoft.Design", "CA1056:UriPropertiesShouldNotBeStrings")]
		public string ApplicationTechSupportEmail
		{
			get => _applicationTechSupportEmail;
			set => _applicationTechSupportEmail = string.IsNullOrWhiteSpace(value) ? null : value.Trim().ToLowerInvariant();
		}
	}
}
