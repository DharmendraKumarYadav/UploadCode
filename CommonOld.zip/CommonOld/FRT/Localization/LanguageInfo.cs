﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;

namespace FRT.Localization
{
	/// <summary>
	/// Language information
	/// </summary>
	public class LanguageInfo
	{
		/// <summary>
		/// Creates an instance of this type
		/// </summary>
		/// <param name="code">Two letter ISO code of the language</param>
		/// <param name="name">Display name of the language in English</param>
		public LanguageInfo(string code, string name = null)
		{
			if (string.IsNullOrWhiteSpace(code))
			{
				throw new ArgumentNullException(nameof(code));
			}

			Code = code;
			Name = name;
		}

		/// <summary>
		/// Neutral language
		/// </summary>
		public LanguageInfo NeutralLanguage
		{
			get
			{
				if (RegionCode != null)
				{
					return new LanguageInfo(NeutralCode);
				}
				return this;
			}
		}

		private string _code;
		/// <summary>
		/// Two letter ISO code of the language
		/// </summary>
		[SuppressMessage("Microsoft.Globalization", "CA1308:NormalizeStringsToUppercase")]
		public string Code
		{
			get => _code;
			private set
			{
				_code = string.IsNullOrWhiteSpace(value) ? null : value.Trim().ToLowerInvariant();
				if (_code != null)
				{
					var parts = _code.Split('-').Select(p => p.Trim()).Where(p => p.Length > 0).ToArray();
					NeutralCode = parts[0].ToLowerInvariant();
					RegionCode = (parts.Length > 1) ? parts[1].ToUpperInvariant() : null;
				}
				else
				{
					NeutralCode = null;
					RegionCode = null;
				}
			}
		}

		/// <summary>
		/// Language neutral code
		/// </summary>
		public string NeutralCode
		{
			get;
			private set;
		}

		/// <summary>
		/// Region code
		/// </summary>
		public string RegionCode
		{
			get;
			private set;
		}

		/// <summary>
		/// Whether this is a neutral language
		/// </summary>
		public bool IsNeutral => RegionCode == null;

		private string _name;
		/// <summary>
		/// Display name of the language in English
		/// </summary>
		public string Name
		{
			get => _name ?? Code; private set => _name = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		#region Overrides of Object
		/// <summary>
		/// Determines whether the specified object is equal to the current object.
		/// </summary>
		/// <returns>
		/// true if the specified object  is equal to the current object; otherwise, false.
		/// </returns>
		/// <param name="obj">The object to compare with the current object. </param>
		public override bool Equals(object obj)
		{
			var lang = obj as LanguageInfo;
			if (lang == null)
			{
				return false;
			}
			return Code.Equals(lang.Code, StringComparison.OrdinalIgnoreCase);
		}

		/// <summary>
		/// Returns a string that represents the current object.
		/// </summary>
		/// <returns>
		/// A string that represents the current object.
		/// </returns>
		public override string ToString()
		{
			if (Code != Name)
			{
				return string.Format(CultureInfo.CurrentCulture, "{0} - {1}", Code, Name);
			}
			else
			{
				return string.Format(CultureInfo.CurrentCulture, "{0}", Code);
			}
		}

		/// <summary>
		/// Serves as the default hash function.
		/// </summary>
		/// <returns>
		/// A hash code for the current object.
		/// </returns>
		public override int GetHashCode()
		{
			return Code.GetHashCode();
		}
		#endregion
	}
}
