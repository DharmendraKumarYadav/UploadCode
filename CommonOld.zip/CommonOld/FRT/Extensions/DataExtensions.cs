﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;

namespace FRT
{
	/// <summary>
	/// Data extensions
	/// </summary>
	public static class DataExtensions
	{
		/// <summary>
		/// Checks if a named UDF exists
		/// </summary>
		/// <param name="conn"></param>
		/// <param name="functionName"></param>
		/// <param name="schemaName"></param>
		/// <returns></returns>
		public static bool UserDefinedFunctionExists(this SqlConnection conn, string functionName, string schemaName = "dbo")
		{
			if (conn == null)
			{
				throw new ArgumentNullException(nameof(conn));
			}
			if (string.IsNullOrWhiteSpace(functionName))
			{
				throw new ArgumentNullException(nameof(functionName));
			}
			if (string.IsNullOrWhiteSpace(schemaName))
			{
				schemaName = "dbo";
			}
			schemaName = schemaName.Trim();

			// Check
			using (var cmd = new SqlCommand(@"SELECT COUNT(*) FROM Information_schema.Routines WHERE Specific_schema = @schema AND specific_name = @name AND Routine_Type = 'FUNCTION'", conn))
			{
				cmd.Parameters.AddWithValue("@schema", schemaName);
				cmd.Parameters.AddWithValue("@name", functionName);
				cmd.CommandType = CommandType.Text;
				return Convert.ToInt32(cmd.ExecuteScalar(), CultureInfo.InvariantCulture) >= 1;
			}
		}

		/// <summary>
		/// Checks if a named UDF exists
		/// </summary>
		/// <param name="conn"></param>
		/// <param name="procedureName"></param>
		/// <param name="schemaName"></param>
		/// <returns></returns>
		[SuppressMessage("Microsoft.Security", "CA2100:Review SQL queries for security vulnerabilities")]
		public static bool StoredProcedureExists(this SqlConnection conn, string procedureName, string schemaName = "dbo")
		{
			if (conn == null)
			{
				throw new ArgumentNullException(nameof(conn));
			}
			if (string.IsNullOrWhiteSpace(procedureName))
			{
				throw new ArgumentNullException(nameof(procedureName));
			}
			if (string.IsNullOrWhiteSpace(schemaName))
			{
				schemaName = "dbo";
			}
			schemaName = schemaName.Trim();

			// Check
			using (var cmd = new SqlCommand(string.Format(CultureInfo.CurrentCulture,
				@"SELECT COUNT(*) FROM Information_schema.Routines WHERE Specific_schema = '{0}' AND specific_name = '{1}' AND Routine_Type = 'PROCEDURE'", schemaName, procedureName), conn))
			{
				cmd.CommandType = CommandType.Text;
				return Convert.ToInt32(cmd.ExecuteScalar(), CultureInfo.InvariantCulture) >= 1;
			}
		}
	}
}
