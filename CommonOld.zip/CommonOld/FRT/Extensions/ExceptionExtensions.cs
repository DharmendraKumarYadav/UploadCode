﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.Encodings.Web;

namespace FRT
{
	/// <summary>
	/// Exception Utilities
	/// </summary>
	public static class ExceptionExtensions
	{
		/// <summary>
		/// Gets the actual/underlying exception
		/// </summary>
		/// <param name="ex">Exception</param>
		/// <returns>Actual/underlying exception</returns>
		public static Exception GetActualException(this Exception ex)
		{
			if (ex == null)
			{
				return null;
			}
			else
			{
				TargetInvocationException targetInvokeEx = ex as TargetInvocationException;
				if (targetInvokeEx?.InnerException != null)
				{
					return GetActualException(targetInvokeEx.InnerException);
				}
				else
				{
					return ex;
				}
			}
		}

		/// <summary>
		/// Retrieves underlying exception of the specified type
		/// </summary>
		/// <param name="ex">Actual exception</param>
		/// <returns>Matching exception</returns>
		[SuppressMessage("Microsoft.Design", "CA1062:Validate arguments of public methods", MessageId = "0")]
		public static TExceptionType GetUnderlyingException<TExceptionType>(this Exception ex)
			where TExceptionType : Exception
		{
			if (ex == null)
			{
				return null;
			}

			// Exception
			TExceptionType ex1 = ex as TExceptionType;
			if (ex1 != null)
			{
				return ex1;
			}

			// Base exception
			Exception baseEx = ex.GetBaseException();
			// ReSharper disable once RedundantNameQualifier
			if (!object.ReferenceEquals(baseEx, ex))
			{
				TExceptionType baseTypedEx = baseEx as TExceptionType;
				if (baseTypedEx != null)
				{
					return baseTypedEx;
				}

				baseTypedEx = GetUnderlyingException<TExceptionType>(baseEx);
				if (baseTypedEx != null)
				{
					return baseTypedEx;
				}
			}

			// Inner Exception
			Exception innerEx = ex.InnerException;
			if (innerEx != null)
			{
				TExceptionType innerTypedEx = innerEx as TExceptionType;
				if (innerTypedEx != null)
				{
					return innerTypedEx;
				}

				innerTypedEx = GetUnderlyingException<TExceptionType>(innerEx);
				return innerTypedEx;
			}

			return null;
		}

		/// <summary>
		/// Creates stack trace frames from a given exception
		/// </summary>
		/// <param name="exception">Exception</param>
		/// <returns>Stack frames</returns>
		public static StackFrameModel[] GetStackFramesFromException(this Exception exception)
		{
			return DI.Platform.GetStackFramesFromException(exception);
		}

		/// <summary>
		/// Formsts the exception in html
		/// </summary>
		/// <returns></returns>
		public static string FormatText(this Exception ex, bool includeExceptionType = true, bool includeMessage = true,
			bool includeStackTrace = false, bool includeInnerException = false, bool includeMiscProperties = false,
			string tableStart = null, string tableEnd = "\r\n", string rowStart = null, string rowEnd = "\r\n",
			string nameCellStart = null, string nameCellEnd = ":        ", string valueCellStart = null, string valueCellEnd = null,
			IDictionary<string, object> extraProperties = null, Func<string, string> textEncoder = null)
		{
			return Format(ex, includeExceptionType, includeMessage, includeStackTrace, includeInnerException, includeMiscProperties,
				tableStart, tableEnd, rowStart, rowEnd, nameCellStart, nameCellEnd, valueCellStart, valueCellEnd, extraProperties, textEncoder);
		}

		/// <summary>
		/// Formsts the exception in html
		/// </summary>
		/// <returns></returns>
		public static string FormatHtml(this Exception ex, bool includeExceptionType = true, bool includeMessage = true,
			bool includeStackTrace = false, bool includeInnerException = false, bool includeMiscProperties = false,
			string tableStart = "<table class\"table\">", string tableEnd = "</table>",
			string rowStart = "<tr>", string rowEnd = "</tr>",
			string nameCellStart = "<td class=\"name\" style=\"font-weight: bold; text-align: left; vertical-align: top;\">", string nameCellEnd = "</td>",
			string valueCellStart = "<td class=\"value\" style=\"text-align: left; vertical-align: top;\">", string valueCellEnd = "</td>",
			IDictionary<string, object> extraProperties = null, Func<string, string> textEncoder = null)
		{
			textEncoder = textEncoder ?? (s => HtmlEncoder.Default.Encode(s));
			return Format(ex, includeExceptionType, includeMessage, includeStackTrace, includeInnerException, includeMiscProperties,
				tableStart, tableEnd, rowStart, rowEnd, nameCellStart, nameCellEnd, valueCellStart, valueCellEnd, extraProperties, textEncoder);
		}

		/// <summary>
		/// Gets formatted text representing the exception
		/// </summary>
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
		[SuppressMessage("Microsoft.Maintainability", "CA1505:AvoidUnmaintainableCode")]
		[SuppressMessage("Microsoft.Maintainability", "CA1506:AvoidExcessiveClassCoupling")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		public static string Format(this Exception ex, bool includeExceptionType = true, bool includeMessage = true,
			bool includeStackTrace = false, bool includeInnerException = false, bool includeMiscProperties = false,
			string tableStart = null, string tableEnd = null, string rowStart = null, string rowEnd = null,
			string nameCellStart = null, string nameCellEnd = null, string valueCellStart = null, string valueCellEnd = null,
			IDictionary<string, object> extraProperties = null, Func<string, string> textEncoder = null)
		{
			if (ex == null)
			{
				throw new ArgumentNullException(nameof(ex));
			}

			// Adjust
			tableStart = tableStart ?? string.Empty;
			tableEnd = tableEnd ?? string.Empty;
			rowStart = rowStart ?? string.Empty;
			rowEnd = rowEnd ?? string.Empty;
			nameCellStart = nameCellStart ?? string.Empty;
			nameCellEnd = nameCellEnd ?? string.Empty;
			valueCellStart = valueCellStart ?? string.Empty;
			valueCellEnd = valueCellEnd ?? string.Empty;
			textEncoder = textEncoder ?? (s => s);

			// Buffer
			var buffer = new StringBuilder();
			var processedInstances = new Dictionary<object, bool>();

			// Property Appender
			// ReSharper disable once ConvertToLocalFunction
			Action<StringBuilder, string, object> propRowAppender = null;
			propRowAppender = (buf, name, value) =>
			{
				// Skip processed instances
				if ((value != null) && processedInstances.ContainsKey(value))
				{
					return;
				}
				if (value != null)
				{
					processedInstances[value] = true;
				}

				var propName = string.IsNullOrWhiteSpace(name) ? null : name.Trim();
				var propDisplayName = propName?.NameToDisplayName(" ");
				var propValueObj = value;
				var propType = value?.GetType();
				var propTypeInfo = propType?.GetTypeInfo();
				var nameCellBuf = new StringBuilder();
				var valueCellBuf = new StringBuilder();

				// Name Cell only if we have a name
				if (propDisplayName != null)
				{
					nameCellBuf.Append(textEncoder(propDisplayName));
				}

				// Determine Value
				if (propValueObj == null)
				{
					valueCellBuf.Append("NULL");
				}
				// ReSharper disable once PossibleNullReferenceException
				else if (propTypeInfo.IsPrimitive || propTypeInfo.IsEnum || (propType == typeof(string))
					|| (typeof(Delegate).GetTypeInfo().IsAssignableFrom(propTypeInfo))
					|| (typeof(MemberInfo).GetTypeInfo().IsAssignableFrom(propTypeInfo)))
				{
					valueCellBuf.Append(textEncoder(propValueObj.ToString()));
				}
				else if (typeof(Exception).GetTypeInfo().IsAssignableFrom(propTypeInfo))
				{
					valueCellBuf.Append(Format(propValueObj as Exception, includeExceptionType, includeMessage, includeStackTrace, includeInnerException,
						includeMiscProperties, tableStart, tableEnd, rowStart, rowEnd, nameCellStart, nameCellEnd, valueCellStart, valueCellEnd, extraProperties, textEncoder));
				}
				else if (typeof(IDictionary).GetTypeInfo().IsAssignableFrom(propTypeInfo))
				{
					var valueBuffer = new StringBuilder();
					// ReSharper disable once PossibleNullReferenceException
					foreach (DictionaryEntry kv in propValueObj as IDictionary)
					{
						propRowAppender(valueBuffer, kv.Key?.ToString(), kv.Value);
					}
					if (valueBuffer.Length > 0)
					{
						valueCellBuf.Append(tableStart);
						valueCellBuf.Append(valueBuffer);
						valueCellBuf.Append(tableEnd);
					}
				}
				else if ((propType != typeof(string)) &&
				         typeof(IEnumerable).GetTypeInfo().IsAssignableFrom(propTypeInfo))
				{
					var valueBuffer = new StringBuilder();
					// ReSharper disable once PossibleNullReferenceException
					foreach (var valItem in propValueObj as IEnumerable)
					{
						propRowAppender(valueBuffer, null, valItem);
					}
					if (valueBuffer.Length > 0)
					{
						valueCellBuf.Append(tableStart);
						valueCellBuf.Append(valueBuffer);
						valueCellBuf.Append(tableEnd);
					}
				}
				else if (propTypeInfo.IsClass || (propTypeInfo.IsValueType && !propTypeInfo.IsEnum))
				{
					var valueBuffer = new StringBuilder();
					// ReSharper disable once PossibleNullReferenceException
					foreach (var subPropInfo in propType.GetRuntimeProperties().Where(p => p.CanRead && !p.IsSpecialName))
					{
						try { propRowAppender(valueBuffer, subPropInfo.Name, subPropInfo.GetValue(propValueObj)); }
						// ReSharper disable once EmptyGeneralCatchClause
						catch { }
					}
					if (valueBuffer.Length > 0)
					{
						valueCellBuf.Append(tableStart);
						valueCellBuf.Append(valueBuffer);
						valueCellBuf.Append(tableEnd);
					}
					else
					{
						valueCellBuf.Append(propValueObj.ToString());
					}
				}
				else
				{
					valueCellBuf.Append(textEncoder(propValueObj.ToString()));
				}

				// Append
				if (valueCellBuf.Length > 0)
				{
					buf.Append(rowStart);
					if (nameCellBuf.Length > 0)
					{
						buf.Append(nameCellStart);
						buf.Append(nameCellBuf);
						buf.Append(nameCellEnd);
					}
					buf.Append(valueCellStart);
					buf.Append(valueCellBuf);
					buf.Append(valueCellEnd);
					buf.Append(rowEnd);
				}
			};

			// Special Properties
			var specialProps = new[] {"Message", "StackTrace", "InnerException"};

			// Special Property Handling
			var specialPropsBuffer = new StringBuilder();
			if (includeExceptionType)
			{
				propRowAppender(specialPropsBuffer, "Type", ex.GetType().FullName);
			}
			if (includeMessage)
			{
				propRowAppender(specialPropsBuffer, "Message", ex.Message);
			}
			if (extraProperties != null)
			{
				foreach (var kv in extraProperties)
				{
					propRowAppender(specialPropsBuffer, kv.Key, kv.Value);
				}
			}
			if (includeStackTrace)
			{
				var stackFrames = ex.GetStackFramesFromException();
				if (stackFrames.Length > 0)
				{
					propRowAppender(specialPropsBuffer, "Stack trace", stackFrames);
				}
			}
			if (includeInnerException && (ex.InnerException != null))
			{
				propRowAppender(specialPropsBuffer, "Inner exception", ex.InnerException);
			}
			if (includeMiscProperties)
			{
				foreach (var propInfo in ex.GetType().GetRuntimeProperties().Where(p => !p.IsSpecialName && p.CanRead && !specialProps.Contains(p.Name, StringComparer.Ordinal)))
				{
					propRowAppender(specialPropsBuffer, propInfo.Name, propInfo.GetValue(ex));
				}
			}

			// Full Buffer
			if (specialPropsBuffer.Length > 0)
			{
				buffer.Append(tableStart);
				buffer.Append(specialPropsBuffer);
				buffer.Append(tableEnd);
			}

			// Return
			return buffer.ToString();
		}
	}
}
