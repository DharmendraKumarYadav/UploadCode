﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using FRT.Properties;

namespace FRT
{
	/// <summary>
	/// Extensions to Object
	/// </summary>
	public static class ObjectExtensions
	{
		#region Type Conversion
		/// <summary>
		/// Conversion helper
		/// </summary>
		/// <typeparam name="TEnumType">Enum type</typeparam>
		/// <param name="obj">Object to convert</param>
		/// <returns>Enum value</returns>
		// ReSharper disable once UnusedMember.Local
		private static TEnumType ConvertToEnum<TEnumType>(object obj)
		{
			if (Enum.IsDefined(typeof(TEnumType), obj))
			{
				return (TEnumType)obj;
			}
			throw new InvalidCastException();
		}

		/// <summary>
		/// Converts an object to another type if a converter exists
		/// </summary>
		/// <param name="sourceInstance">Object instance to convert</param>
		/// <param name="targetType">Target type for conversion</param>
		/// <param name="defaultValue">Default value to return if source instance is null</param>
		/// <param name="returnDefaultValueOnNoConversion">True to indicate that the default value should be returned if no conversion exists.
		/// If false, an exception is throws if the source instance is not null and could not be converted to target type</param>
		/// <returns>Converted object</returns>
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
		public static object ConvertType(this object sourceInstance, Type targetType, object defaultValue, bool returnDefaultValueOnNoConversion = false)
		{
			// Check target type
			if (targetType == null)
			{
				throw new ArgumentNullException(nameof(targetType));
			}

			// Return default is source is null
			if (sourceInstance == null)
			{
				return defaultValue;
			}
			else if (targetType == typeof(object))
			{
				return sourceInstance;
			}

			// Check source type
			TypeInfo targetTypeInfo = targetType.GetTypeInfo();
			Type sourceType = sourceInstance.GetType();
			TypeInfo sourceTypeInfo = sourceType.GetTypeInfo();

			// Return the same instance if same type or a derived type
			if ((sourceType == targetType) ||
				targetTypeInfo.IsAssignableFrom(sourceTypeInfo))
			{
				return sourceInstance;
			}

			// Check target type converter
			TypeConverter targetTypeConverter = TypeDescriptor.GetConverter(targetType);
			if (targetTypeConverter.CanConvertFrom(sourceType))
			{
				try
				{
					return targetTypeConverter.ConvertFrom(sourceInstance);
				}
				// ReSharper disable once EmptyGeneralCatchClause
				catch { }
			}

			// Check source type converter
			TypeConverter sourceTypeConverter = TypeDescriptor.GetConverter(sourceInstance.GetType());
			if (sourceTypeConverter.CanConvertTo(targetType))
			{
				try
				{
					return sourceTypeConverter.ConvertTo(sourceInstance, targetType);
				}
				// ReSharper disable once EmptyGeneralCatchClause
				catch { }
			}

			// Special case for enums
			if (sourceTypeInfo.IsEnum)
			{
				var enumBaseType = Enum.GetUnderlyingType(sourceType);
				if ((enumBaseType == typeof(sbyte)) || (enumBaseType == typeof(byte)))
				{
					var convertibleTypes = new[] { enumBaseType, typeof(short), typeof(ushort), typeof(int), typeof(uint), typeof(long), typeof(ulong) };
					if (convertibleTypes.Contains(targetType))
					{
						return ConvertType((enumBaseType == typeof(byte)) ? (object)(byte)sourceInstance : (sbyte)sourceInstance,
							targetType, defaultValue, returnDefaultValueOnNoConversion);
					}
				}
				else if ((enumBaseType == typeof(short)) || (enumBaseType == typeof(ushort)))
				{
					var convertibleTypes = new[] { enumBaseType, typeof(int), typeof(uint), typeof(long), typeof(ulong) };
					if (convertibleTypes.Contains(targetType))
					{
						return ConvertType((enumBaseType == typeof(short)) ? (object)(short)sourceInstance : (ushort)sourceInstance,
							targetType, defaultValue, returnDefaultValueOnNoConversion);
					}
				}
				else if ((enumBaseType == typeof(int)) || (enumBaseType == typeof(uint)))
				{
					var convertibleTypes = new[] { enumBaseType, typeof(long), typeof(ulong) };
					if (convertibleTypes.Contains(targetType))
					{
						return ConvertType((enumBaseType == typeof(int)) ? (object)(int)sourceInstance : (uint)sourceInstance,
							targetType, defaultValue, returnDefaultValueOnNoConversion);
					}
				}
				else if ((enumBaseType == typeof(long)) || (enumBaseType == typeof(ulong)))
				{
					var convertibleTypes = new[] { enumBaseType };
					if (convertibleTypes.Contains(targetType))
					{
						return ConvertType((enumBaseType == typeof(long)) ? (object)(long)sourceInstance : (ulong)sourceInstance,
							targetType, defaultValue, returnDefaultValueOnNoConversion);
					}
				}
			}
			else if (targetTypeInfo.IsEnum)
			{
				var enumBaseType = Enum.GetUnderlyingType(targetType);
				var methodInfo = typeof(ObjectExtensions).GetTypeInfo().GetDeclaredMethod("ConvertToEnum");
				if (enumBaseType == typeof(long))
				{
					var convertibleTypes = new[] { enumBaseType, typeof(sbyte), typeof(byte), typeof(short), typeof(ushort), typeof(int), typeof(uint) };
					if (convertibleTypes.Contains(sourceType))
					{
						var val = (long)sourceInstance;
						try { return methodInfo.MakeGenericMethod(targetType).Invoke(null, new object[] { val }); }
						// ReSharper disable once EmptyGeneralCatchClause
						catch { }
					}
				}
				else if (enumBaseType == typeof(ulong))
				{
					var convertibleTypes = new[] { enumBaseType, typeof(sbyte), typeof(byte), typeof(short), typeof(ushort), typeof(int), typeof(uint) };
					if (convertibleTypes.Contains(sourceType))
					{
						var val = (ulong)sourceInstance;
						try { return methodInfo.MakeGenericMethod(targetType).Invoke(null, new object[] { val }); }
						// ReSharper disable once EmptyGeneralCatchClause
						catch { }
					}
				}
				else if (enumBaseType == typeof(int))
				{
					var convertibleTypes = new[] { enumBaseType, typeof(sbyte), typeof(byte), typeof(short), typeof(ushort) };
					if (convertibleTypes.Contains(sourceType))
					{
						var val = (int)sourceInstance;
						try { return methodInfo.MakeGenericMethod(targetType).Invoke(null, new object[] { val }); }
						// ReSharper disable once EmptyGeneralCatchClause
						catch { }
					}
				}
				else if (enumBaseType == typeof(uint))
				{
					var convertibleTypes = new[] { enumBaseType, typeof(sbyte), typeof(byte), typeof(short), typeof(ushort) };
					if (convertibleTypes.Contains(sourceType))
					{
						var val = (uint)sourceInstance;
						try { return methodInfo.MakeGenericMethod(targetType).Invoke(null, new object[] { val }); }
						// ReSharper disable once EmptyGeneralCatchClause
						catch { }
					}
				}
				else if (enumBaseType == typeof(short))
				{
					var convertibleTypes = new[] { enumBaseType, typeof(sbyte), typeof(byte) };
					if (convertibleTypes.Contains(sourceType))
					{
						var val = (short)sourceInstance;
						try { return methodInfo.MakeGenericMethod(targetType).Invoke(null, new object[] { val }); }
						// ReSharper disable once EmptyGeneralCatchClause
						catch { }
					}
				}
				else if (enumBaseType == typeof(ushort))
				{
					var convertibleTypes = new[] { enumBaseType, typeof(sbyte), typeof(byte) };
					if (convertibleTypes.Contains(sourceType))
					{
						var val = (ushort)sourceInstance;
						try { return methodInfo.MakeGenericMethod(targetType).Invoke(null, new object[] { val }); }
						// ReSharper disable once EmptyGeneralCatchClause
						catch { }
					}
				}
				else if (enumBaseType == typeof(sbyte))
				{
					var convertibleTypes = new[] { enumBaseType };
					if (convertibleTypes.Contains(sourceType))
					{
						var val = (sbyte)sourceInstance;
						try { return methodInfo.MakeGenericMethod(targetType).Invoke(null, new object[] { val }); }
						// ReSharper disable once EmptyGeneralCatchClause
						catch { }
					}
				}
				else if (enumBaseType == typeof(byte))
				{
					var convertibleTypes = new[] { enumBaseType };
					if (convertibleTypes.Contains(sourceType))
					{
						var val = (byte)sourceInstance;
						try { return methodInfo.MakeGenericMethod(targetType).Invoke(null, new object[] { val }); }
						// ReSharper disable once EmptyGeneralCatchClause
						catch { }
					}
				}
			}

			// Return default value or throw
			if (returnDefaultValueOnNoConversion)
			{
				return defaultValue;
			}
			throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, CommonResources.S_NoTypeConversionExists_SourceType_TargetType, sourceType.AssemblyQualifiedName, targetType.AssemblyQualifiedName));
		}

		/// <summary>
		/// Converts an object to another type if a converter exists
		/// </summary>
		/// <typeparam name="TTargetType">Target type for conversion</typeparam>
		/// <param name="sourceInstance">Object instance to convert</param>
		/// <param name="defaultValue">Default value to be returned when the source instance is null</param>
		/// <param name="returnDefaultValueOnNoConversion">True to indicate that the default value should be returned if no conversion exists.
		/// If false, an exception is throws if the source instance is not null and could not be converted to target type</param>
		/// <returns>Converted object</returns>
		public static TTargetType ConvertType<TTargetType>(this object sourceInstance, TTargetType defaultValue = default(TTargetType), bool returnDefaultValueOnNoConversion = false)
		{
			return (TTargetType)ConvertType(sourceInstance, typeof(TTargetType), defaultValue, returnDefaultValueOnNoConversion);
		}
		#endregion

		#region Dictionary Conversion
		/// <summary>
		/// Converts a key value pair collection to dictionary
		/// </summary>
		/// <param name="sourceInstance">Object instance to convert</param>
		/// <param name="comparer">Comparer</param>
		/// <returns>Dictionary with property-value pairs</returns>
		[SuppressMessage("Microsoft.Design", "CA1006:DoNotNestGenericTypesInMemberSignatures")]
		public static IDictionary<TKeyType, TValueType> ToDictionary<TKeyType, TValueType>(
			this IEnumerable<KeyValuePair<TKeyType, TValueType>> sourceInstance, IEqualityComparer<TKeyType> comparer = null)
		{
			if (sourceInstance == null)
			{
				return null;
			}
			if (comparer == null)
			{
				var dictionary = new Dictionary<TKeyType, TValueType>();
				dictionary.MergeRange(sourceInstance);
				return dictionary;
			}
			else
			{
				var dictionary = new Dictionary<TKeyType, TValueType>(comparer);
				dictionary.MergeRange(sourceInstance);
				return dictionary;
			}
		}

		/// <summary>
		/// Converts an object to a string dictionary containing its property-value pairs as dictionary entries
		/// </summary>
		/// <param name="sourceInstance">Object instance to convert</param>
		/// <param name="caseInsensitive">True to return a case-insensitive dictionary</param>
		/// <returns>String-Object dictionary with property-value pairs</returns>
		public static IDictionary<string, object> ToDictionary(this object sourceInstance, bool caseInsensitive = false)
		{
			IDictionary<string, object> objectDictionary = sourceInstance as IDictionary<string, object>;
			if ((objectDictionary == null) && (sourceInstance != null))
			{
				IEnumerable enumerableInstance = sourceInstance as IEnumerable;

				// Create a new dictionary
				objectDictionary = new Dictionary<string, object>(caseInsensitive ? StringComparer.OrdinalIgnoreCase : StringComparer.Ordinal);

				// Check if the source instance is any kind of dictionary
				Type[] dictionaryGenericTypeParams = sourceInstance.GetType().GetGenericTypeParameters(typeof(IDictionary<,>));
				if ((dictionaryGenericTypeParams != null) && (dictionaryGenericTypeParams.Length == 2))
				{
					Type entryType = typeof(KeyValuePair<,>).MakeGenericType(dictionaryGenericTypeParams);
					// ReSharper disable once PossibleNullReferenceException
					foreach (object entry in enumerableInstance)
					{
						object key = entryType.GetRuntimeProperty("Key").GetValue(entry);
						object value = entryType.GetRuntimeProperty("Value").GetValue(entry);
						objectDictionary[key?.ToString()] = value;
					}
				}
				else
				{
					IEnumerable<KeyValuePair<string, object>> objectKeyValuePairs = sourceInstance as IEnumerable<KeyValuePair<string, object>>;
					if (objectKeyValuePairs != null)
					{
						objectDictionary.MergeRange(objectKeyValuePairs, true);
					}
					else
					{
						// Check if the source instance is any kind of dictionary
						IEnumerable<KeyValuePair<string, string>> tempCollection = new[] { new KeyValuePair<string, string>(string.Empty, string.Empty) };
						Type enumerableGenericType = null;
						// ReSharper disable once LoopCanBeConvertedToQuery
						foreach (Type ifType in tempCollection.GetType().GetTypeInfo().ImplementedInterfaces)
						{
							if (ifType.GetTypeInfo().IsGenericType && ifType.Name.StartsWith("IEnumerable", StringComparison.Ordinal))
							{
								enumerableGenericType = ifType;
								break;
							}
						}
						enumerableGenericType = enumerableGenericType?.GetGenericTypeDefinition();

						Type[] enumerableGenericTypeParams = sourceInstance.GetType().GetGenericTypeParameters(enumerableGenericType);
						dictionaryGenericTypeParams = ((enumerableGenericTypeParams != null) && (enumerableGenericTypeParams.Length == 1)) ? enumerableGenericTypeParams[0].GenericTypeArguments : null;

						if ((dictionaryGenericTypeParams != null) && (dictionaryGenericTypeParams.Length == 2))
						{
							Type entryType = typeof(KeyValuePair<,>).MakeGenericType(dictionaryGenericTypeParams);
							// ReSharper disable once PossibleNullReferenceException
							foreach (object entry in enumerableInstance)
							{
								object key = entryType.GetRuntimeProperty("Key").GetValue(entry);
								object value = entryType.GetRuntimeProperty("Value").GetValue(entry);
								objectDictionary[key?.ToString()] = value;
							}
						}
						else
						{
							// Populate using properties
							foreach (var propInfo in sourceInstance.GetType().GetTypeInfo().DeclaredProperties)
							{
								object propertyValue = propInfo.GetValue(sourceInstance);
								objectDictionary[propInfo.Name] = propertyValue;
							}
						}
					}
				}
			}
			return objectDictionary;
		}

		/// <summary>
		/// Converts an object to a string dictionary containing its property-value pairs as dictionary entries
		/// </summary>
		/// <param name="sourceInstance">Object instance to convert</param>
		/// <param name="comparison">String comparison for the dictionary</param>
		/// <returns>String-Object dictionary with property-value pairs</returns>
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		public static IDictionary<string, string> ToStringDictionary(this object sourceInstance, StringComparison comparison = StringComparison.OrdinalIgnoreCase)
		{
			IDictionary<string, string> stringDictionary = sourceInstance as IDictionary<string, string>;
			if ((stringDictionary == null) && (sourceInstance != null))
			{
				IEnumerable enumerableInstance = sourceInstance as IEnumerable;

				// Create a new dictionary
				stringDictionary = new Dictionary<string, string>(
						(comparison == StringComparison.CurrentCulture)
						? StringComparer.CurrentCulture
						: ((comparison == StringComparison.CurrentCultureIgnoreCase)
							? StringComparer.CurrentCultureIgnoreCase
							: ((comparison == StringComparison.Ordinal)
										? StringComparer.Ordinal
										: StringComparer.OrdinalIgnoreCase)));

				// Check if the source instance is any kind of dictionary
				Type[] dictionaryGenericTypeParams = sourceInstance.GetType().GetGenericTypeParameters(typeof(IDictionary<,>));
				if ((dictionaryGenericTypeParams != null) && (dictionaryGenericTypeParams.Length == 2))
				{
					Type entryType = typeof(KeyValuePair<,>).MakeGenericType(dictionaryGenericTypeParams);
					// ReSharper disable once PossibleNullReferenceException
					foreach (object entry in enumerableInstance)
					{
						object key = entryType.GetRuntimeProperty("Key").GetValue(entry);
						object value = entryType.GetRuntimeProperty("Value").GetValue(entry);
						stringDictionary[key?.ToString()] = value?.ToString();
					}
				}
				else
				{
					IEnumerable<KeyValuePair<string, string>> objectKeyValuePairs = sourceInstance as IEnumerable<KeyValuePair<string, string>>;
					if (objectKeyValuePairs != null)
					{
						stringDictionary.MergeRange(objectKeyValuePairs, true);
					}
					else
					{
						// Check if the source instance is any kind of dictionary
						IEnumerable<KeyValuePair<string, string>> tempCollection = new[] { new KeyValuePair<string, string>(string.Empty, string.Empty) };
						Type enumerableGenericType = null;
						// ReSharper disable once LoopCanBeConvertedToQuery
						foreach (Type ifType in tempCollection.GetType().GetTypeInfo().ImplementedInterfaces)
						{
							if (ifType.GetTypeInfo().IsGenericType && ifType.Name.StartsWith("IEnumerable", StringComparison.Ordinal))
							{
								enumerableGenericType = ifType;
								break;
							}
						}
						enumerableGenericType = enumerableGenericType?.GetGenericTypeDefinition();

						Type[] enumerableGenericTypeParams = sourceInstance.GetType().GetGenericTypeParameters(enumerableGenericType);
						dictionaryGenericTypeParams = ((enumerableGenericTypeParams != null) && (enumerableGenericTypeParams.Length == 1)) ? enumerableGenericTypeParams[0].GenericTypeArguments : null;

						if ((dictionaryGenericTypeParams != null) && (dictionaryGenericTypeParams.Length == 2))
						{
							Type entryType = typeof(KeyValuePair<,>).MakeGenericType(dictionaryGenericTypeParams);
							// ReSharper disable once PossibleNullReferenceException
							foreach (object entry in enumerableInstance)
							{
								object key = entryType.GetRuntimeProperty("Key").GetValue(entry);
								object value = entryType.GetRuntimeProperty("Value").GetValue(entry);
								stringDictionary[key?.ToString()] = value?.ToString();
							}
						}
						else
						{
							// Populate using properties
							foreach (var propInfo in sourceInstance.GetType().GetTypeInfo().DeclaredProperties)
							{
								object propertyValue = propInfo.GetValue(sourceInstance);
								stringDictionary[propInfo.Name] = propertyValue?.ToString();
							}
						}
					}
				}
			}
			return stringDictionary;
		}
		#endregion

		#region Enumerations
		/// <summary>
		/// Converts a source enum to a destination enum
		/// </summary>
		/// <typeparam name="TSourceType">Source enum type</typeparam>
		/// <typeparam name="TDestinationType">Destination enum type</typeparam>
		/// <param name="sourceInstance">Source enum value</param>
		/// <returns>Destination enum value</returns>
		public static TDestinationType ConvertEnumByName<TSourceType, TDestinationType>(this TSourceType sourceInstance)
		{
			return ConvertEnumByName<TSourceType, TDestinationType>(sourceInstance, true);
		}

		/// <summary>
		/// Converts a source enum to a destination enum
		/// </summary>
		/// <typeparam name="TSourceType">Source enum type</typeparam>
		/// <typeparam name="TDestinationType">Destination enum type</typeparam>
		/// <param name="sourceInstance">Source enum value</param>
		/// <param name="ignoreCase">Ignore case</param>
		/// <returns>Destination enum value</returns>
		public static TDestinationType ConvertEnumByName<TSourceType, TDestinationType>(this TSourceType sourceInstance, bool ignoreCase)
		{
			var srcType = typeof(TSourceType).GetTypeInfo();
			var dstType = typeof(TDestinationType).GetTypeInfo();

			if (!srcType.IsEnum)
			{
				throw new ArgumentException(string.Format(CultureInfo.CurrentCulture, CommonResources.S_TypeNotEnum_Type, srcType.FullName), nameof(sourceInstance));
			}
			if (!dstType.IsEnum)
			{
				throw new ArgumentException(string.Format(CultureInfo.CurrentCulture, CommonResources.S_TypeNotEnum_Type, dstType.FullName), nameof(sourceInstance));
			}

			return (TDestinationType)Enum.Parse(dstType.AsType(), sourceInstance.ToString(), ignoreCase);
		}

		/// <summary>
		/// Splits enum flags combination into individual items
		/// </summary>
		/// <typeparam name="TEnumType">Enum type</typeparam>
		/// <param name="enumObject">Enum value</param>
		/// <returns>Array of individual flags</returns>
		[SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "Flags")]
		public static TEnumType[] SplitEnumFlags<TEnumType>(this TEnumType enumObject)
		{
			// Check type
			var enumType = typeof(TEnumType).GetTypeInfo();
			if (!enumType.IsEnum)
			{
				throw new ArgumentException(string.Format(CultureInfo.CurrentCulture, CommonResources.S_TypeNotEnum_Type, enumType.FullName), nameof(enumObject));
			}

			// Enumerate
			var enumList = new List<Tuple<TEnumType, ulong>>();
			var givenValue = Convert.ToUInt64(enumObject, CultureInfo.InvariantCulture);
			foreach (TEnumType item in Enum.GetValues(typeof(TEnumType)))
			{
				var itemVal = Convert.ToUInt64(item, CultureInfo.InvariantCulture);

				// None or 0 value flag
				if (itemVal == 0)
				{
					if (givenValue == 0)
					{
						return new[] { item };
					}
					continue;
				}

				// Non-zero flags
				if ((itemVal & givenValue) == itemVal)
				{
					enumList.Add(new Tuple<TEnumType, ulong>(item, itemVal));
				}
			}

			// Sort
			enumList = enumList.OrderBy(p => p.Item2).ToList();

			// Remove redundant values
			for (int i = enumList.Count - 1; i >= 0; --i)
			{
				ulong combinedValueExclusive = 0;
				var itemVal = enumList[i].Item2;

				// ReSharper disable once LoopCanBeConvertedToQuery
				for (int j = 0; j < enumList.Count; ++j)
				{
					if (j != i)
					{
						combinedValueExclusive |= enumList[j].Item2;
					}
				}
				if (combinedValueExclusive == (combinedValueExclusive | itemVal))
				{
					enumList.RemoveAt(i);
				}
			}
			return enumList.Select(p => p.Item1).ToArray();
		}

		/// <summary>
		/// Converts enum flags into a name range string
		/// </summary>
		/// <typeparam name="TEnumType">Enumeration type</typeparam>
		/// <param name="enumObject">Enumeration value</param>
		/// <returns>Name representation of ranges for the enum</returns>
		[SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "Flag")]
		public static string GetFlagEnumNameRange<TEnumType>(this TEnumType enumObject)
		{
			if (enumObject == null)
			{
				throw new ArgumentNullException(nameof(enumObject));
			}

			var enumType = typeof(TEnumType).GetTypeInfo();
			if (!enumType.IsEnum)
			{
				throw new ArgumentException(string.Format(CultureInfo.CurrentCulture, CommonResources.S_TypeNotEnum_Type, enumType.FullName), nameof(enumObject));
			}

			var flagsAttribute = enumType.GetAttribute<FlagsAttribute>(false);
			if (flagsAttribute == null)
			{
				throw new ArgumentException(string.Format(CultureInfo.CurrentCulture, CommonResources.S_EnumNotFlags_Type, enumType.FullName), nameof(enumObject));
			}

			var enumObjectValues = new List<TEnumType>(SplitEnumFlags(enumObject));
			var allEnumValues = new List<TEnumType>(Enum.GetValues(enumType.AsType()).Cast<TEnumType>());
			allEnumValues.Sort();

			var sbBuffer = new StringBuilder();

			TEnumType sequenceBeginVal = default(TEnumType);
			TEnumType lastMatchingVal = default(TEnumType);
			bool inSequence = false;

			for (int iVal = 0, nVals = allEnumValues.Count; iVal < nVals; ++iVal)
			{
				TEnumType enumVal = allEnumValues[iVal];
				if (enumObjectValues.Contains(enumVal))
				{
					lastMatchingVal = enumVal;
					if (!inSequence)
					{
						if (sbBuffer.Length > 0)
						{
							sbBuffer.Append(", ");
						}
						sbBuffer.Append(enumVal.ToString().NameToDisplayName());

						inSequence = true;
						sequenceBeginVal = enumVal;
					}
				}
				else
				{
					if (inSequence)
					{
						// ReSharper disable once RedundantNameQualifier
						if (!object.Equals(sequenceBeginVal, lastMatchingVal))
						{
							sbBuffer.AppendFormat(CultureInfo.InvariantCulture, " - {0}", lastMatchingVal.ToString().NameToDisplayName());
						}
						inSequence = false;
					}
				}
			}
			if (inSequence)
			{
				// ReSharper disable once RedundantNameQualifier
				if (!object.Equals(sequenceBeginVal, lastMatchingVal))
				{
					sbBuffer.AppendFormat(CultureInfo.InvariantCulture, " - {0}", lastMatchingVal.ToString().NameToDisplayName());
				}
			}

			return sbBuffer.ToString();
		}

		/// <summary>
		/// Checks if the specified flags has the specified flag set
		/// </summary>
		/// <param name="flags">Flags</param>
		/// <param name="flag">Flag to check</param>
		/// <returns>True or False</returns>
		[SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "Flag")]
		[SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "flag")]
		[SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "flags")]
		[SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "Flags")]
		public static bool EnumFlagsHasFlag(this object flags, object flag)
		{
			// Null Checks
			if ((flags == null) || (flag == null))
			{
				return false;
			}

			// Type Check
			var enumType = flags.GetType().GetTypeInfo();
			if (!enumType.IsEnum || (enumType.GetCustomAttribute<FlagsAttribute>() == null))
			{
				throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, CommonResources.S_EnumNotFlags_Type, enumType.FullName));
			}
			if (flag.GetType() != enumType.AsType())
			{
				flag = flag.ConvertType(enumType);
			}

			// Check
			return (bool)typeof(ObjectExtensions).GetRuntimeMethods()
				.Single(p => string.Equals(p.Name, "EnumFlagsHasFlag", StringComparison.Ordinal)
							 && (p.IsGenericMethod || p.IsGenericMethodDefinition))
				.MakeGenericMethod(enumType.AsType())
				.Invoke(null, new[] { flags, flag });
		}

		/// <summary>
		/// Checks if the specified flags has the specified flag set
		/// </summary>
		/// <typeparam name="TEnumType">Enumeration type</typeparam>
		/// <param name="flags">Flags</param>
		/// <param name="flag">Flag to check</param>
		/// <returns>True or False</returns>
		[SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "Flag")]
		[SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "flags")]
		[SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "Flags")]
		[SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "flag")]
		public static bool EnumFlagsHasFlag<TEnumType>(this TEnumType flags, TEnumType flag)
		{
			// Type check
			var enumType = typeof(TEnumType).GetTypeInfo();
			if (!enumType.IsEnum || (enumType.GetCustomAttribute<FlagsAttribute>() == null))
			{
				throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, CommonResources.S_EnumNotFlags_Type, enumType.FullName));
			}

			// Check based on underlying system type
			var underlyingType = Enum.GetUnderlyingType(enumType.AsType());
			if (underlyingType == typeof(byte))
			{
				return (((byte)(object)flags) & ((byte)(object)flag)) != 0;
			}
			else if (underlyingType == typeof(sbyte))
			{
				return (((sbyte)(object)flags) & ((sbyte)(object)flag)) != 0;
			}
			else if (underlyingType == typeof(short))
			{
				return (((short)(object)flags) & ((short)(object)flag)) != 0;
			}
			else if (underlyingType == typeof(ushort))
			{
				return (((ushort)(object)flags) & ((ushort)(object)flag)) != 0;
			}
			else if (underlyingType == typeof(int))
			{
				return (((int)(object)flags) & ((int)(object)flag)) != 0;
			}
			else if (underlyingType == typeof(uint))
			{
				return (((uint)(object)flags) & ((uint)(object)flag)) != 0;
			}
			else if (underlyingType == typeof(long))
			{
				return (((long)(object)flags) & ((long)(object)flag)) != 0;
			}
			else if (underlyingType == typeof(ulong))
			{
				return (((ulong)(object)flags) & ((ulong)(object)flag)) != 0;
			}
			return false;
		}

		/// <summary>
		/// Checks if the specified flag has no bits set (0)
		/// </summary>
		/// <param name="flag">Flag to check</param>
		/// <returns>True or False</returns>
		[SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "Flag")]
		[SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "flag")]
		public static bool IsEnumFlagNone(this object flag)
		{
			// Null Checks
			if (flag == null)
			{
				return false;
			}

			// Type Check
			var enumType = flag.GetType().GetTypeInfo();
			if (!enumType.IsEnum || (enumType.GetCustomAttribute<FlagsAttribute>() == null))
			{
				throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, CommonResources.S_EnumNotFlags_Type, enumType.FullName));
			}

			// Check
			return (bool)typeof(ObjectExtensions).GetRuntimeMethods()
				.Single(p => string.Equals(p.Name, "IsEnumFlagNone", StringComparison.Ordinal)
							 && (p.IsGenericMethod || p.IsGenericMethodDefinition))
				.MakeGenericMethod(enumType.AsType())
				.Invoke(null, new[] { flag });
		}

		/// <summary>
		/// Checks if the specified flag has no bits set (0)
		/// </summary>
		/// <typeparam name="TEnumType">Enumeration type</typeparam>
		/// <param name="flag">Flag to check</param>
		/// <returns>True or False</returns>
		[SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "Flag")]
		[SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "flag")]
		public static bool IsEnumFlagNone<TEnumType>(this TEnumType flag)
		{
			// Type check
			var enumType = typeof(TEnumType).GetTypeInfo();
			if (!enumType.IsEnum || (enumType.GetCustomAttribute<FlagsAttribute>() == null))
			{
				throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, CommonResources.S_EnumNotFlags_Type, enumType.FullName));
			}

			// Check based on underlying system type
			var underlyingType = Enum.GetUnderlyingType(enumType.AsType());
			if (underlyingType == typeof(byte))
			{
				return ((byte)(object)flag) == 0;
			}
			else if (underlyingType == typeof(sbyte))
			{
				return ((sbyte)(object)flag) == 0;
			}
			else if (underlyingType == typeof(short))
			{
				return ((short)(object)flag) == 0;
			}
			else if (underlyingType == typeof(ushort))
			{
				return ((ushort)(object)flag) == 0;
			}
			else if (underlyingType == typeof(int))
			{
				return ((int)(object)flag) == 0;
			}
			else if (underlyingType == typeof(uint))
			{
				return ((uint)(object)flag) == 0;
			}
			else if (underlyingType == typeof(long))
			{
				return ((long)(object)flag) == 0;
			}
			else if (underlyingType == typeof(ulong))
			{
				return ((ulong)(object)flag) == 0;
			}
			return false;
		}

		/// <summary>
		/// Checks if the specified flag has multiple bits set
		/// </summary>
		/// <param name="flag">Flag to check</param>
		/// <returns>True or False</returns>
		[SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "Flag")]
		[SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "flag")]
		public static bool EnumFlagHasMultipleBits(this object flag)
		{
			// Null Checks
			if (flag == null)
			{
				return false;
			}

			// Type Check
			var enumType = flag.GetType().GetTypeInfo();
			if (!enumType.IsEnum || (enumType.GetCustomAttribute<FlagsAttribute>() == null))
			{
				throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, CommonResources.S_EnumNotFlags_Type, enumType.FullName));
			}

			// Check
			return (bool)typeof(ObjectExtensions).GetRuntimeMethods()
				.Single(p => string.Equals(p.Name, "EnumFlagHasMultipleBits", StringComparison.Ordinal)
							 && (p.IsGenericMethod || p.IsGenericMethodDefinition))
				.MakeGenericMethod(enumType.AsType())
				.Invoke(null, new[] { flag });
		}

		/// <summary>
		/// Checks if the specified flag has multiple bits set
		/// </summary>
		/// <typeparam name="TEnumType">Enumeration type</typeparam>
		/// <param name="flag">Flag to check</param>
		/// <returns>True or False</returns>
		[SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "flag")]
		[SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "Flag")]
		public static bool EnumFlagHasMultipleBits<TEnumType>(this TEnumType flag)
		{
			// Type check
			var enumType = typeof(TEnumType).GetTypeInfo();
			if (!enumType.IsEnum || (enumType.GetCustomAttribute<FlagsAttribute>() == null))
			{
				throw new InvalidOperationException(string.Format(CultureInfo.CurrentCulture, CommonResources.S_EnumNotFlags_Type, enumType.FullName));
			}

			// Check based on underlying system type
			BitArray bitArray;
			var underlyingType = Enum.GetUnderlyingType(enumType.AsType());
			if (underlyingType == typeof(byte))
			{
				bitArray = new BitArray(new[] { (byte)(object)flag });
			}
			else if (underlyingType == typeof(sbyte))
			{
				bitArray = new BitArray(BitConverter.GetBytes((sbyte)(object)flag));
			}
			else if (underlyingType == typeof(short))
			{
				bitArray = new BitArray(BitConverter.GetBytes((short)(object)flag));
			}
			else if (underlyingType == typeof(ushort))
			{
				bitArray = new BitArray(BitConverter.GetBytes((ushort)(object)flag));
			}
			else if (underlyingType == typeof(int))
			{
				bitArray = new BitArray(BitConverter.GetBytes((int)(object)flag));
			}
			else if (underlyingType == typeof(uint))
			{
				bitArray = new BitArray(BitConverter.GetBytes((uint)(object)flag));
			}
			else if (underlyingType == typeof(long))
			{
				bitArray = new BitArray(BitConverter.GetBytes((long)(object)flag));
			}
			else if (underlyingType == typeof(ulong))
			{
				bitArray = new BitArray(BitConverter.GetBytes((ulong)(object)flag));
			}
			else
			{
				return false;
			}

			// Count & Return
			return bitArray.Cast<bool>().Count(p => p) > 1;
		}
		#endregion

		#region Validation
		/// <summary>
		/// Validates the object within the scope of the given rule set names
		/// </summary>
		/// <param name="obj">Object instance</param>
		/// <param name="includeDefaultRules">Whether to include rules not in any rulesets</param>
		/// <param name="ruleSetNames">Names of the rule sets to validate. If not specified the complete object is validated</param>
		/// <returns>Validation result</returns>
		public static ValidationResult Validate<TType>(this TType obj, bool includeDefaultRules = true,
			params string[] ruleSetNames)
		{
			return Crosscuttings.ValidationManager.Validate(obj, includeDefaultRules, ruleSetNames);
		}

		/// <summary>
		/// Validates the object within the scope of the given rule set names and throws an exception if an error occurs
		/// </summary>
		/// <param name="obj">Object instance</param>
		/// <param name="includeDefaultRules">Whether to include rules not in any rulesets</param>
		/// <param name="ruleSetNames">Names of the rule sets to validate. If not specified the complete object is validated</param>
		public static void ThrowOnValidationError<TType>(this TType obj, bool includeDefaultRules = true, params string[] ruleSetNames)
		{
			Crosscuttings.ValidationManager.ThrowOnValidationError(obj, includeDefaultRules, ruleSetNames);
		}

		/// <summary>
		/// Validates the object within the scope of the given rule set names
		/// </summary>
		/// <param name="obj">Object instance</param>
		/// <param name="includeDefaultRules">Whether to include rules not in any rulesets</param>
		/// <param name="ruleSetNames">Names of the rule sets to validate. If not specified the complete object is validated</param>
		/// <returns>Validation result</returns>
		[SuppressMessage("Microsoft.Design", "CA1004:GenericMethodsShouldProvideTypeParameter")]
		public static ValidationResult Validate<TType, TValidatorType>(this TType obj, bool includeDefaultRules = true, params string[] ruleSetNames)
			where TValidatorType : IValidator<TType>, new()
		{
			return Crosscuttings.ValidationManager.Validate<TType, TValidatorType>(obj, includeDefaultRules, ruleSetNames);
		}

		/// <summary>
		/// Validates the object within the scope of the given rule set names and throws an exception if an error occurs
		/// </summary>
		/// <param name="obj">Object instance</param>
		/// <param name="includeDefaultRules">Whether to include rules not in any rulesets</param>
		/// <param name="ruleSetNames">Names of the rule sets to validate. If not specified the complete object is validated</param>
		[SuppressMessage("Microsoft.Design", "CA1004:GenericMethodsShouldProvideTypeParameter")]
		public static void ThrowOnValidationError<TType, TValidatorType>(this TType obj, bool includeDefaultRules = true, params string[] ruleSetNames)
			where TValidatorType : IValidator<TType>, new()
		{
			Crosscuttings.ValidationManager.ThrowOnValidationError<TType, TValidatorType>(obj, includeDefaultRules, ruleSetNames);
		}

		/// <summary>
		/// Validates the object within the scope of the given rule set names
		/// </summary>
		/// <param name="obj">Object instance</param>
		/// <param name="validator">Validator to be used</param>
		/// <param name="includeDefaultRules">Whether to include rules not in any rulesets</param>
		/// <param name="ruleSetNames">Names of the rule sets to validate. If not specified the complete object is validated</param>
		/// <returns>Validation result</returns>
		public static ValidationResult Validate<TType, TValidatorType>(this TType obj, TValidatorType validator, bool includeDefaultRules = true, params string[] ruleSetNames)
			where TValidatorType : IValidator<TType>
		{
			return Crosscuttings.ValidationManager.Validate(obj, validator, includeDefaultRules, ruleSetNames);
		}

		/// <summary>
		/// Validates the object within the scope of the given rule set names and throws an exception if an error occurs
		/// </summary>
		/// <param name="obj">Object instance</param>
		/// <param name="validator">Validator to be used</param>
		/// <param name="includeDefaultRules">Whether to include rules not in any rulesets</param>
		/// <param name="ruleSetNames">Names of the rule sets to validate. If not specified the complete object is validated</param>
		public static void ThrowOnValidationError<TType, TValidatorType>(this TType obj, TValidatorType validator, bool includeDefaultRules = true, params string[] ruleSetNames)
			where TValidatorType : IValidator<TType>
		{
			Crosscuttings.ValidationManager.ThrowOnValidationError(obj, validator, includeDefaultRules, ruleSetNames);
		}
		#endregion
	}
}
