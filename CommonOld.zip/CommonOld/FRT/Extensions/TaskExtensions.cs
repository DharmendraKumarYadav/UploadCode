﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;
using FRT.Properties;

namespace FRT
{
	/// <summary>
	/// Task utilities
	/// </summary>
	public static class TaskExtensions
	{
		/// <summary>
		/// Returns a task from the result
		/// </summary>
		/// <typeparam name="T">Result type</typeparam>
		/// <param name="result">Result</param>
		/// <returns>Completed task with the given result</returns>
		public static Task<T> FromResult<T>(T result)
		{
			var source = new TaskCompletionSource<T>();
			source.SetResult(result);
			return source.Task;
		}

		/// <summary>
		/// Returns an empty completed task
		/// </summary>
		/// <typeparam name="T">Result type</typeparam>
		/// <returns>Completed task with the given result type</returns>
		public static Task<T> Empty<T>()
		{
			var source = new TaskCompletionSource<T>();
			source.SetResult(default(T));
			return source.Task;
		}

		/// <summary>
		/// Returns an empty completed task
		/// </summary>
		/// <returns>Completed taskt</returns>
		public static Task Empty()
		{
			var source = new TaskCompletionSource<object>();
			source.SetResult(null);
			return source.Task;
		}

		/// <summary>
		/// Waits for a task to complete &amp; returns the result
		/// </summary>
		/// <typeparam name="TResultType">Result type</typeparam>
		/// <param name="task">Task</param>
		/// <param name="timeoutResult">Result to return on timeout</param>
		/// <returns>True if the task completed. False if not</returns>
		public static TResultType WaitAndGetResult<TResultType>(this Task<TResultType> task, TResultType timeoutResult = default(TResultType))
		{
			return WaitAndGetResult(task, Timeout.Infinite, CancellationToken.None, timeoutResult);
		}

		/// <summary>
		/// Waits for a task to complete &amp; returns the result
		/// </summary>
		/// <typeparam name="TResultType">Result type</typeparam>
		/// <param name="task">Task</param>
		/// <param name="result">Result type</param>
		/// <returns>True if the task completed. False if not</returns>
		[SuppressMessage("Microsoft.Design", "CA1021:AvoidOutParameters", MessageId = "1#")]
		public static bool WaitAndGetResult<TResultType>(this Task<TResultType> task, out TResultType result)
		{
			return WaitAndGetResult(task, out result, Timeout.Infinite, CancellationToken.None);
		}

		/// <summary>
		/// Waits for a task to complete &amp; returns the result
		/// </summary>
		/// <typeparam name="TResultType">Result type</typeparam>
		/// <param name="task">Task</param>
		/// <param name="timeoutMilliseconds">Timeout in milliseconds</param>
		/// <param name="cancellationToken">Cancellation token</param>
		/// <param name="timeoutResult">Result to return on timeout</param>
		/// <returns>True if the task completed. False if not</returns>
		[SuppressMessage("Microsoft.Usage", "CA2201:DoNotRaiseReservedExceptionTypes")]
		public static TResultType WaitAndGetResult<TResultType>(this Task<TResultType> task, int timeoutMilliseconds, CancellationToken cancellationToken, TResultType timeoutResult = default(TResultType))
		{
			if (task == null)
			{
				throw new ArgumentNullException(nameof(task));
			}

			if (!task.Wait(timeoutMilliseconds, cancellationToken))
			{
				return timeoutResult;
			}

			if (task.IsFaulted || (task.Exception != null))
			{
				var ex = task.Exception ?? new Exception(CommonResources.S_UnknownError);
				throw ex;
			}

			return task.Result;
		}

		/// <summary>
		/// Waits for a task to complete &amp; returns the result
		/// </summary>
		/// <typeparam name="TResultType">Result type</typeparam>
		/// <param name="task">Task</param>
		/// <param name="result">Result type</param>
		/// <param name="timeoutMilliseconds">Timeout in milliseconds</param>
		/// <param name="cancellationToken">Cancellation token</param>
		/// <returns>True if the task completed. False if not</returns>
		[SuppressMessage("Microsoft.Usage", "CA2201:DoNotRaiseReservedExceptionTypes")]
		[SuppressMessage("Microsoft.Design", "CA1021:AvoidOutParameters", MessageId = "1#")]
		public static bool WaitAndGetResult<TResultType>(this Task<TResultType> task, out TResultType result, int timeoutMilliseconds, CancellationToken cancellationToken)
		{
			if (task == null)
			{
				throw new ArgumentNullException(nameof(task));
			}

			result = default(TResultType);
			if (!task.Wait(timeoutMilliseconds, cancellationToken))
			{
				return false;
			}

			if (task.IsFaulted || (task.Exception != null))
			{
				var ex = task.Exception ?? new Exception(CommonResources.S_UnknownError);
				throw ex;
			}

			result = task.Result;
			return true;
		}

		/// <summary>
		/// Waits for a task to complete &amp; returns the result
		/// </summary>
		/// <typeparam name="TResultType">Result type</typeparam>
		/// <param name="task">Task</param>
		/// <param name="timeout">Timeout in milliseconds</param>
		/// <param name="cancellationToken">Cancellation token</param>
		/// <param name="timeoutResult">Result to return on timeout</param>
		/// <returns>True if the task completed. False if not</returns>
		public static TResultType WaitAndGetResult<TResultType>(this Task<TResultType> task, TimeSpan timeout, CancellationToken cancellationToken, TResultType timeoutResult = default(TResultType))
		{
			return WaitAndGetResult(task, (timeout == Timeout.InfiniteTimeSpan) ? Timeout.Infinite : (int)timeout.TotalMilliseconds, cancellationToken, timeoutResult);
		}

		/// <summary>
		/// Waits for a task to complete &amp; returns the result
		/// </summary>
		/// <typeparam name="TResultType">Result type</typeparam>
		/// <param name="task">Task</param>
		/// <param name="result">Result type</param>
		/// <param name="timeout">Timeout in milliseconds</param>
		/// <param name="cancellationToken">Cancellation token</param>
		/// <returns>True if the task completed. False if not</returns>
		[SuppressMessage("Microsoft.Design", "CA1021:AvoidOutParameters", MessageId = "1#")]
		public static bool WaitAndGetResult<TResultType>(this Task<TResultType> task, out TResultType result, TimeSpan timeout, CancellationToken cancellationToken)
		{
			return WaitAndGetResult(task, out result, (timeout == Timeout.InfiniteTimeSpan) ? Timeout.Infinite : (int)timeout.TotalMilliseconds, cancellationToken);
		}

		/// <summary>
		/// Waits for a task to complete &amp; returns the result
		/// </summary>
		/// <typeparam name="TResultType">Result type</typeparam>
		/// <param name="task">Task</param>
		/// <param name="timeoutMilliseconds">Timeout in milliseconds</param>
		/// <param name="timeoutResult">Result to return on timeout</param>
		/// <returns>True if the task completed. False if not</returns>
		public static TResultType WaitAndGetResult<TResultType>(this Task<TResultType> task, int timeoutMilliseconds, TResultType timeoutResult = default(TResultType))
		{
			return WaitAndGetResult(task, timeoutMilliseconds, CancellationToken.None, timeoutResult);
		}

		/// <summary>
		/// Waits for a task to complete &amp; returns the result
		/// </summary>
		/// <typeparam name="TResultType">Result type</typeparam>
		/// <param name="task">Task</param>
		/// <param name="result">Result type</param>
		/// <param name="timeoutMilliseconds">Timeout in milliseconds</param>
		/// <returns>True if the task completed. False if not</returns>
		[SuppressMessage("Microsoft.Design", "CA1021:AvoidOutParameters", MessageId = "1#")]
		public static bool WaitAndGetResult<TResultType>(this Task<TResultType> task, out TResultType result, int timeoutMilliseconds)
		{
			return WaitAndGetResult(task, out result, timeoutMilliseconds, CancellationToken.None);
		}

		/// <summary>
		/// Waits for a task to complete &amp; returns the result
		/// </summary>
		/// <typeparam name="TResultType">Result type</typeparam>
		/// <param name="task">Task</param>
		/// <param name="timeout">Timeout in milliseconds</param>
		/// <param name="timeoutResult">Result to return on timeout</param>
		/// <returns>True if the task completed. False if not</returns>
		public static TResultType WaitAndGetResult<TResultType>(this Task<TResultType> task, TimeSpan timeout, TResultType timeoutResult = default(TResultType))
		{
			return WaitAndGetResult(task, timeout, CancellationToken.None, timeoutResult);
		}

		/// <summary>
		/// Waits for a task to complete &amp; returns the result
		/// </summary>
		/// <typeparam name="TResultType">Result type</typeparam>
		/// <param name="task">Task</param>
		/// <param name="result">Result type</param>
		/// <param name="timeout">Timeout in milliseconds</param>
		/// <returns>True if the task completed. False if not</returns>
		[SuppressMessage("Microsoft.Design", "CA1021:AvoidOutParameters", MessageId = "1#")]
		public static bool WaitAndGetResult<TResultType>(this Task<TResultType> task, out TResultType result, TimeSpan timeout)
		{
			return WaitAndGetResult(task, out result, timeout, CancellationToken.None);
		}

		/// <summary>
		/// Waits for a task to complete &amp; returns the result
		/// </summary>
		/// <typeparam name="TResultType">Result type</typeparam>
		/// <param name="task">Task</param>
		/// <param name="cancellationToken">Cancellation token</param>
		/// <param name="timeoutResult">Result to return on timeout</param>
		/// <returns>True if the task completed. False if not</returns>
		public static TResultType WaitAndGetResult<TResultType>(this Task<TResultType> task, CancellationToken cancellationToken, TResultType timeoutResult = default(TResultType))
		{
			return WaitAndGetResult(task, Timeout.Infinite, cancellationToken, timeoutResult);
		}

		/// <summary>
		/// Waits for a task to complete &amp; returns the result
		/// </summary>
		/// <typeparam name="TResultType">Result type</typeparam>
		/// <param name="task">Task</param>
		/// <param name="result">Result type</param>
		/// <param name="cancellationToken">Cancellation token</param>
		/// <returns>True if the task completed. False if not</returns>
		[SuppressMessage("Microsoft.Design", "CA1021:AvoidOutParameters", MessageId = "1#")]
		public static bool WaitAndGetResult<TResultType>(this Task<TResultType> task, out TResultType result, CancellationToken cancellationToken)
		{
			return WaitAndGetResult(task, out result, Timeout.Infinite, cancellationToken);
		}
	}
}
