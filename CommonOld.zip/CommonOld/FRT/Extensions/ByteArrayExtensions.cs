﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text;

namespace FRT
{
	/// <summary>
	/// byte[] Extensions
	/// </summary>
	public static class ByteArrayExtensions
	{
		/// <summary>
		/// Converts the byte data to hex representation
		/// </summary>
		/// <param name="data">Binary data</param>
		/// <returns>Hex representation of the data</returns>
		public static string ToHexString (this byte[] data)
		{
			if (data == null)
			{
				return null;
			}

			var sbBuffer = new StringBuilder ();
			foreach (byte dataByte in data)
			{
				sbBuffer.AppendFormat(CultureInfo.InvariantCulture, "{0:X2}", dataByte);
			}
			return sbBuffer.ToString();
		}

		/// <summary>
		/// Converts the byte data to hex representation
		/// </summary>
		/// <param name="data">Binary data</param>
		/// <returns>Hex representation of the data</returns>
		public static string ToBase64(this byte[] data)
		{
			if (data == null)
			{
				return null;
			}
			else if (data.Length == 0)
			{
				return string.Empty;
			}
			return Convert.ToBase64String(data);
		}

		/// <summary>
		/// Converts an int ptr to an item array
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="ptr">Pointer</param>
		/// <param name="sizeInBytes">Data size</param>
		/// <returns>Item array</returns>
		[SuppressMessage("Microsoft.Naming", "CA1720:IdentifiersShouldNotContainTypeNames", MessageId = "ptr")]
		public static T[] ToArray<T>(this IntPtr ptr, int sizeInBytes)
			where T: struct
		{
			if (ptr == IntPtr.Zero)
			{
				return null;
			}
			else if (sizeInBytes <= 0)
			{
				return new T[0];
			}
			else
			{
				var tType = typeof(T);
				if (tType == typeof(byte))
				{
					var arrayItemCount = sizeInBytes/sizeof (byte);
					var arr = new byte[arrayItemCount];
					Marshal.Copy(ptr, arr, 0, arrayItemCount);
					return (T[]) (object)arr;
				}
				else if (tType == typeof(sbyte))
				{
					var arrayItemCount = sizeInBytes / sizeof(sbyte);
					var arr = new sbyte[arrayItemCount];
					// ReSharper disable once PossibleInvalidCastException
					Marshal.Copy(ptr, (byte[])(Array)arr, 0, arrayItemCount);
					return (T[])(object)arr;
				}
				else if (tType == typeof(char))
				{
					var arrayItemCount = sizeInBytes / sizeof(char);
					var arr = new char[arrayItemCount];
					Marshal.Copy(ptr, arr, 0, arrayItemCount);
					return (T[])(object)arr;
				}
				else if (tType == typeof(short))
				{
					var arrayItemCount = sizeInBytes / sizeof(short);
					var arr = new short[arrayItemCount];
					Marshal.Copy(ptr, arr, 0, arrayItemCount);
					return (T[])(object)arr;
				}
				else if (tType == typeof(ushort))
				{
					var arrayItemCount = sizeInBytes / sizeof(ushort);
					var arr = new ushort[arrayItemCount];
					// ReSharper disable once PossibleInvalidCastException
					Marshal.Copy(ptr, (short[])(Array)arr, 0, arrayItemCount);
					return (T[])(object)arr;
				}
				else if (tType == typeof(int))
				{
					var arrayItemCount = sizeInBytes / sizeof(int);
					var arr = new int[arrayItemCount];
					Marshal.Copy(ptr, arr, 0, arrayItemCount);
					return (T[])(object)arr;
				}
				else if (tType == typeof(uint))
				{
					var arrayItemCount = sizeInBytes / sizeof(uint);
					var arr = new uint[arrayItemCount];
					// ReSharper disable once PossibleInvalidCastException
					Marshal.Copy(ptr, (int[])(Array)arr, 0, arrayItemCount);
					return (T[])(object)arr;
				}
				else if (tType == typeof(long))
				{
					var arrayItemCount = sizeInBytes / sizeof(long);
					var arr = new long[arrayItemCount];
					Marshal.Copy(ptr, arr, 0, arrayItemCount);
					return (T[])(object)arr;
				}
				else if (tType == typeof(ulong))
				{
					var arrayItemCount = sizeInBytes / sizeof(ulong);
					var arr = new ulong[arrayItemCount];
					// ReSharper disable once PossibleInvalidCastException
					Marshal.Copy(ptr, (long[])(Array)arr, 0, arrayItemCount);
					return (T[])(object)arr;
				}
				else if (tType == typeof(float))
				{
					var arrayItemCount = sizeInBytes / sizeof(float);
					var arr = new float[arrayItemCount];
					Marshal.Copy(ptr, arr, 0, arrayItemCount);
					return (T[])(object)arr;
				}
				else if (tType == typeof(double))
				{
					var arrayItemCount = sizeInBytes / sizeof(double);
					var arr = new double[arrayItemCount];
					Marshal.Copy(ptr, arr, 0, arrayItemCount);
					return (T[])(object)arr;
				}
				return null;
			}
		}
	}
}
