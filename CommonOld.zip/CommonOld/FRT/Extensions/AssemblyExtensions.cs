﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reflection;

namespace FRT
{
	/// <summary>
	/// Sort mode for assemblies
	/// </summary>
	public enum AssemblyDependencySortMode
	{
		DependentsAfterDependencies,
		DependenciesAfterDependents
	}

	/// <summary>
	/// Assembly extensions
	/// </summary>
	public static class AssemblyExtensions
	{
		private static readonly object _asmDepsLock = new object();
		private static readonly Dictionary<string, List<string>> _asmDeps = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);

		/// <summary>
		/// Returns the loadable types from the assembly
		/// </summary>
		/// <param name="assembly">Assembly</param>
		/// <param name="exportedTypesOnly">Whether to return only exported/public types</param>
		public static TypeInfo[] GetLoadableTypes(this Assembly assembly, bool exportedTypesOnly = false)
		{
			List<Type> typeList = null;
			try
			{
				typeList = assembly.GetTypes()
					.Where(t => !exportedTypesOnly || t.IsVisible)
					.ToList();
			}
			catch(ReflectionTypeLoadException ex)
			{
				typeList.AddRange(ex.Types.Where(t => t != null));
			}
			catch
			{
				typeList = new List<Type>();
			}
			return typeList.Select(t => t.GetTypeInfo()).ToArray();
		}

		/// <summary>
		/// Gets the referenced assembly names for the specified assembly
		/// </summary>
		/// <param name="assembly">Assembly</param>
		/// <returns>Referenced assembly names</returns>
		public static AssemblyName[] GetReferencedAssemblies(this Assembly assembly)
		{
			return DI.Platform.GetReferencedAssemblies(assembly);
		}


		/// <summary>
		/// Loads the specified assembly safely. Returns nul. if load fails
		/// </summary>
		/// <param name="assemblyName">Assembly name to load</param>
		/// <returns></returns>
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
		[SuppressMessage("Microsoft.Security", "CA2104:DoNotDeclareReadOnlyMutableReferenceTypes")]
		public static Assembly SafeLoad(this AssemblyName assemblyName)
		{
			try
			{
				return Assembly.Load(assemblyName);
			}
			catch
			{
				return null;
			}
		}

		/// <summary>
		/// Gets a list of dependencies - flattened
		/// </summary>
		/// <param name="assembly">Assembly</param>
		/// <returns>List of dependencies</returns>
		public static ReadOnlyCollection<AssemblyName> GetFlattenedDependencies(this Assembly assembly)
		{
			if (assembly == null)
			{
				return null;
			}
			return GetFlattenedDependencies(assembly.GetName());
		}

		/// <summary>
		/// Gets a list of dependencies - flattened
		/// </summary>
		/// <param name="assemblyName">Assembly name</param>
		/// <returns>List of dependencies</returns>
		public static ReadOnlyCollection<AssemblyName> GetFlattenedDependencies(this AssemblyName assemblyName)
		{
			Dictionary<string, string> scannedAssemblies = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
			return GetFlattenedDependencies(assemblyName, scannedAssemblies);
		}

		/// <summary>
		/// Gets a list of dependencies - flattened
		/// </summary>
		/// <param name="assemblyName">Assembly name</param>
		/// <param name="scannedAssemblies">Scanned assembly names</param>
		/// <returns>List of dependencies</returns>
		private static ReadOnlyCollection<AssemblyName> GetFlattenedDependencies(this AssemblyName assemblyName, Dictionary<string, string> scannedAssemblies)
		{
			// Validate
			if (assemblyName == null)
			{
				return null;
			}

			// If already scanned or under scan
			var fullName = assemblyName.FullName;
			scannedAssemblies[fullName] = fullName;

			// Check if already detected
			List<string> depsList;
			lock (_asmDepsLock)
			{
				if (_asmDeps.TryGetValue(fullName, out depsList))
				{
					return new ReadOnlyCollection<AssemblyName>(depsList.Select(a => new AssemblyName(a)).ToList());
				}
			}

			// Load assembly
			var assembly = assemblyName.SafeLoad();
			if (assembly == null)
			{
				return null;
			}

			// Detect now
			depsList = new List<string>();
			foreach (var depAsmName in DI.Platform.GetReferencedAssemblies(assembly))
			{
				// Skip if already above in the chain
				if (scannedAssemblies.ContainsKey(depAsmName.FullName))
				{
					continue;
				}

				// Add this assembly
				depsList.Add(depAsmName.FullName);

				// Add Child dependencies
				var childList = GetFlattenedDependencies(depAsmName, scannedAssemblies);
				if (childList != null)
				{
					depsList.AddRange(childList.Select(a => a.FullName));
				}
			}

			// Save this in the resolved dictionary & return
			lock (_asmDepsLock)
			{
				_asmDeps[fullName] = depsList;
			}
			return new ReadOnlyCollection<AssemblyName>(depsList.Select(a => new AssemblyName(a)).ToList());
		}

		/// <summary>
		/// Checks if the first assembly depends on the other assembly
		/// </summary>
		/// <param name="assembly"></param>
		/// <param name="otherAssemblyName"></param>
		/// <returns></returns>
		public static bool HasDependencyOn(this Assembly assembly, AssemblyName otherAssemblyName)
		{
			if ((assembly == null) || (otherAssemblyName == null))
			{
				return false;
			}
			return GetFlattenedDependencies(assembly)
					.Select(a => a.FullName)
					.Contains(otherAssemblyName.FullName, StringComparer.Ordinal);
		}

		/// <summary>
		/// Sorts the assemblies in the order of dependency
		/// </summary>
		/// <param name="assemblies">List of assemblies to sort</param>
		/// <param name="sortMode">Sorting mode</param>
		/// <returns>Sorted list of assemblies</returns>
		public static IEnumerable<AssemblyName> SortAssembliesOnDependency(this IEnumerable<AssemblyName> assemblies, AssemblyDependencySortMode sortMode = AssemblyDependencySortMode.DependentsAfterDependencies)
		{
			// Validate
			assemblies = assemblies?.Where(p => p != null) ?? throw new ArgumentNullException(nameof(assemblies));

			List<Assembly> loadedAssemblies = new List<Assembly>();
			// ReSharper disable once LoopCanBeConvertedToQuery
			foreach (AssemblyName assemblyName in assemblies)
			{
				Assembly assembly = assemblyName.SafeLoad();
				if (assembly != null)
				{
					loadedAssemblies.Add(assembly);
				}
			}

			List<AssemblyName> assemblyNames = new List<AssemblyName>();
			// ReSharper disable once LoopCanBeConvertedToQuery
			foreach (Assembly assembly in SortAssembliesOnDependency(loadedAssemblies, sortMode))
			{
				assemblyNames.Add(assembly.GetName());
			}
			return assemblyNames;
		}

		/// <summary>
		/// Sorts the assemblies in the order of dependency
		/// </summary>
		/// <param name="assemblies">List of assemblies to sort</param>
		/// <param name="sortMode">Sorting mode</param>
		/// <returns>Sorted list of assemblies</returns>
		public static IEnumerable<Assembly> SortAssembliesOnDependency(this IEnumerable<Assembly> assemblies, AssemblyDependencySortMode sortMode = AssemblyDependencySortMode.DependentsAfterDependencies)
		{
			if (assemblies == null)
			{
				throw new ArgumentNullException(nameof(assemblies));
			}
			List<Assembly> assemblyList = new List<Assembly>(assemblies);
			assemblyList.Sort((x, y) =>
			{
				int multFactor = (sortMode == AssemblyDependencySortMode.DependentsAfterDependencies) ? 1 : -1;
				if (HasDependencyOn(x, y.GetName()))
				{
					return 1 * multFactor;
				}
				else if (HasDependencyOn(y, x.GetName()))
				{
					return -1 * multFactor;
				}
				return 0;
			});
			return assemblyList;
		}

		/// <summary>
		/// Retrieves a list of all dependencies
		/// </summary>
		/// <param name="assembly"></param>
		/// <returns></returns>
		public static IEnumerable<Assembly> GetAllDependencies(this Assembly assembly)
		{
			List<Assembly> assemblies = new List<Assembly>();
			GetAllDependencies(assembly, assemblies);
			return assemblies;
		}

		/// <summary>
		/// Retrieves a list of all dependencies
		/// </summary>
		/// <param name="assembly"></param>
		/// <param name="assemblies"></param>
		private static void GetAllDependencies(this Assembly assembly, List<Assembly> assemblies)
		{
			if (assembly != null)
			{
				// Add referenced assemblies
				foreach (AssemblyName referenceAssemblyName in DI.Platform.GetReferencedAssemblies(assembly))
				{
					Assembly referenceAssembly = referenceAssemblyName.SafeLoad();
					if (referenceAssembly != null)
					{
						bool assemblyExists = false;
						// ReSharper disable once LoopCanBeConvertedToQuery
						foreach (Assembly assemblyItem in assemblies)
						{
							if (string.Equals(assemblyItem.FullName, referenceAssemblyName.FullName, StringComparison.OrdinalIgnoreCase))
							{
								assemblyExists = true;
								break;
							}
						}
						if (!assemblyExists)
						{
							assemblies.Add(referenceAssembly);
							GetAllDependencies(referenceAssembly, assemblies);
						}
					}
				}
			}
		}

		/// <summary>
		/// Returns the file path of the assembly
		/// </summary>
		/// <param name="assembly">Assembly</param>
		/// <returns>Assembly file path</returns>
		public static string GetFilePath(this Assembly assembly)
		{
			return DI.Platform.GetAssemblyFilePath(assembly);
		}

		/// <summary>
		/// Registers all interfaces, if their implementation types are found
		/// </summary>
		/// <param name="implementationAssembly">Assembly defining implementations</param>
		/// <param name="interfaceAssembly">Assembly defining interfaces</param>
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		public static Dictionary<TypeInfo, TypeInfo> ScanImplementationsByCommonConvention(this Assembly implementationAssembly, Assembly interfaceAssembly = null)
		{
			if (implementationAssembly == null)
			{
				throw new ArgumentNullException(nameof(implementationAssembly));
			}
			interfaceAssembly = interfaceAssembly ?? implementationAssembly;

			// Enumerate Interfaces
			var returnValue = new Dictionary<TypeInfo, TypeInfo>();
			TypeInfo[] allImplTypes = implementationAssembly.GetLoadableTypes()
									.Where(t => t.IsClass && !t.IsAbstract && !t.IsEnum && !t.IsGenericType && !t.IsGenericTypeDefinition
											&& !t.IsArray && !t.IsImport && !t.IsInterface && !t.IsNested && !t.IsPrimitive && !t.IsValueType)
									.ToArray();
			interfaceAssembly.GetLoadableTypes().Where(t => t.IsInterface && !t.IsNested)
				.ForEach(ifType =>
				{
					string implName = ifType.Name.Substring(1);
					TypeInfo[] implTypes = allImplTypes.Where(t => string.Equals(t.Name, implName, StringComparison.Ordinal)).ToArray();
					if (implTypes.Length == 1)
					{
						returnValue[ifType] = implTypes[0];
					}
				});

			// Return
			return returnValue;
		}
	}
}
