﻿using System;
using System.IO;
using FRT.Properties;

namespace FRT
{
	/// <summary>
	/// Stream extensions
	/// </summary>
	public static class StreamExtensions
	{
		/// <summary>
		/// Reads all bytes from the stream
		/// </summary>
		/// <param name="stream">Stream to read</param>
		/// <param name="seekToBegin">Whether to seek to the beginning of the stream before reading</param>
		/// <returns>Data from the stream</returns>
		public static byte[] ReadAllBytes(this Stream stream, bool seekToBegin = false)
		{
			if (stream == null)
			{
				return null;
			}

			if (seekToBegin)
			{
				if (stream.Position > 0)
				{
					if (!stream.CanSeek)
					{
						throw new InvalidOperationException(CommonResources.S_StreamNotSeekable);
					}
					else
					{
						stream.Seek(0, SeekOrigin.Begin);
					}
				}
			}

			int bufferLength = 65536;
			byte[] dataBuffer = new byte[bufferLength];

			using (MemoryStream memStream = new MemoryStream())
			{
				while (true)
				{
					var readBytes = stream.Read(dataBuffer, 0, bufferLength);
					if (readBytes == 0)
					{
						break;
					}
					memStream.Write(dataBuffer, 0, readBytes);
				}

				return memStream.ToArray();
			}
		}

		/// <summary>
		/// Copies data from one stream to the other
		/// </summary>
		/// <param name="sourceStream">Source stream</param>
		/// <param name="targetStream">Target stream</param>
		/// <param name="seekToBegin">Whether to seek to the beginning of the stream before reading</param>
		/// <param name="chunkSize">Chunk size for copying</param>
		public static void CopyTo(this Stream sourceStream, Stream targetStream, bool seekToBegin = true, int chunkSize = 4096)
		{
			if (sourceStream == null)
			{
				throw new ArgumentNullException(nameof(sourceStream));
			}
			if (targetStream == null)
			{
				throw new ArgumentNullException(nameof(targetStream));
			}

			if (seekToBegin)
			{
				if (sourceStream.Position > 0)
				{
					if (!sourceStream.CanSeek)
					{
						throw new InvalidOperationException(CommonResources.S_StreamNotSeekable);
					}
					else
					{
						sourceStream.Seek(0, SeekOrigin.Begin);
					}
				}
			}

			byte[] dataBuffer = new byte[chunkSize = Math.Max(chunkSize, 4096)];
			while (true)
			{
				int bytesRead = sourceStream.Read(dataBuffer, 0, chunkSize);
				if (bytesRead == 0)
				{
					break;
				}
				else
				{
					targetStream.Write(dataBuffer, 0, bytesRead);
				}
			}
		}
	}
}
