﻿using System;
using System.Globalization;

namespace FRT
{
	/// <summary>
	/// Miscellaneous utilities
	/// </summary>
	public static class NumberExtensions
	{
		/// <summary>
		/// Formats the given number as a byte size
		/// </summary>
		/// <param name="bytes">Byte count</param>
		/// <returns>Byte value &amp; units</returns>
		public static Tuple<double, string> FormatAsBytes(this long bytes)
		{
			var units = new[] {"B", "KB", "MB", "GB", "TB", "PB", "EB"};
			double value = bytes;
			string unit = units[0];

			// Start with bytes
			for(int i = 1; i < units.Length; ++i)
			{
				const int mult = 1024;
				if (value >= mult)
				{
					value = value / mult;
					unit = units[i];
				}
				else
				{
					break;
				}
			}

			// Return
			return new Tuple<double, string>(value, unit);
		}

		/// <summary>
		/// Formats the given number as a byte size
		/// </summary>
		/// <param name="bytes">Byte count</param>
		/// <param name="valueFormat">Format of the value</param>
		/// <param name="valueFormatCulture">Culture of the value format</param>
		/// <returns>Human readable byte display string</returns>
		public static string FormatAsBytesString(this long bytes, string valueFormat = null, IFormatProvider valueFormatCulture = null)
		{
			var val = FormatAsBytes(bytes);
			// ReSharper disable once CompareOfFloatsByEqualityOperator
			var isWholeNumber = val.Item1 == Math.Ceiling(val.Item1);
			valueFormat = valueFormat ?? (isWholeNumber ? "N0" : "N");
			valueFormatCulture = valueFormatCulture ?? CultureInfo.CurrentCulture;
			return val.Item1.ToString(valueFormat, valueFormatCulture) + " " + val.Item2;
		}
	}
}
