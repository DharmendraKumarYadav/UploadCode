﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;

namespace FRT
{
	/// <summary>
	/// Type Extensions
	/// </summary>
	public static class TypeExtensions
	{
		private static readonly Regex _invalidTypeNameCharsRegexRegex = DI.Platform.CreateRegex(@"[^a-z0-9_']", RegexOptions.Singleline | RegexOptions.IgnoreCase, true);

		#region Hierarchy
		/// <summary>
		/// Checks whether a type is an ancestor of another type
		/// </summary>
		/// <param name="ancestorType">Type</param>
		/// <param name="descendantType">Type</param>
		/// <returns>True if ancestorType is an ancestor of the descendantType</returns>
		public static bool IsAncestorOf(this Type ancestorType, Type descendantType)
		{
			if ((ancestorType == null) ||
				(descendantType == null) ||
				(descendantType == typeof(object)) ||
				(ancestorType == descendantType))
			{
				return false;
			}
			else if (IsDirectBaseOf(ancestorType, descendantType))
			{
				return true;
			}
			else
			{
				return IsAncestorOf(ancestorType, descendantType.GetTypeInfo().BaseType);
			}
		}

		/// <summary>
		/// Checks is a type is a direct base of another type
		/// </summary>
		/// <param name="baseType">Type</param>
		/// <param name="derivedType">Type</param>
		/// <returns>True if baseType is direct base type of derivedType</returns>
		public static bool IsDirectBaseOf(this Type baseType, Type derivedType)
		{
			if ((baseType == null) ||
				(derivedType == null) ||
				(derivedType == typeof(object)))
			{
				return false;
			}

			return (baseType == derivedType.GetTypeInfo().BaseType);
		}

		/// <summary>
		/// Checks if a type is descendant of another type
		/// </summary>
		/// <param name="descendantType">Type</param>
		/// <param name="ancestorType">Type</param>
		/// <returns>True if descendantType is a descendant of ancestorType</returns>
		public static bool IsDescendantOf(this Type descendantType, Type ancestorType)
		{
			if ((descendantType == null) ||
				(ancestorType == null) ||
				(descendantType == typeof(object)) ||
				(descendantType == ancestorType))
			{
				return false;
			}
			else if (IsDirectSubclassOf(descendantType, ancestorType))
			{
				return true;
			}
			else
			{
				return IsDescendantOf(descendantType.GetTypeInfo().BaseType, ancestorType);
			}
		}

		/// <summary>
		/// Checks whether a type is a direct sub-class of another type
		/// </summary>
		/// <param name="derivedType">Type</param>
		/// <param name="baseType">Type</param>
		/// <returns>True if derivedType is a direct sub-class of baseType</returns>
		public static bool IsDirectSubclassOf(this Type derivedType, Type baseType)
		{
			if ((derivedType == null) ||
				(baseType == null) ||
				(derivedType == typeof(object)))
			{
				return false;
			}

			return (derivedType.GetTypeInfo().BaseType == baseType);
		}

		/// <summary>
		/// Checks whether a type implements an interface
		/// </summary>
		/// <param name="type">Type</param>
		/// <param name="interfaceType">Interface type</param>
		/// <param name="checkDerivedInterfaces">True to indicate that derived interface implementation is considered</param>
		/// <returns>True if type implements interfaceType or any of its derived interfaces</returns>
		public static bool DoesImplementInterface(this Type type, Type interfaceType, bool checkDerivedInterfaces = false)
		{
			if ((type == null) ||
				(interfaceType == null) ||
				!interfaceType.GetTypeInfo().IsInterface)
			{
				return false;
			}

			// ReSharper disable once LoopCanBeConvertedToQuery
			foreach (Type ifType in type.GetTypeInfo().ImplementedInterfaces)
			{
				if ((ifType == interfaceType) || (checkDerivedInterfaces && IsAncestorOf(interfaceType, ifType)))
				{
					return true;
				}
			}
			return false;
		}

		/// <summary>
		/// Checks if the implementation type is an instantiable type
		/// </summary>
		/// <param name="implementationType">Implementation type</param>
		/// <param name="baseType">Base type</param>
		/// <returns>True if implementation type is an instantiable implementation of the base type</returns>
		public static bool IsInstantiableImplementationOf(this Type implementationType, Type baseType)
		{
			if ((implementationType == null) || (baseType == null))
			{
				return false;
			}
			else if (!baseType.GetTypeInfo().IsAssignableFrom(implementationType.GetTypeInfo()))
			{
				return false;
			}

			// Check instantiability
			var implementationTypeInfo = implementationType.GetTypeInfo();
			return implementationTypeInfo.IsClass &&
					!implementationTypeInfo.IsInterface &&
					!implementationTypeInfo.IsAbstract &&
					!implementationTypeInfo.IsGenericType &&
					!implementationTypeInfo.IsGenericTypeDefinition &&
					!implementationTypeInfo.IsImport;
		}
		#endregion

		#region Attributes
		/// <summary>
		/// Gets attributes of a specified type
		/// </summary>
		/// <typeparam name="TAttributeType">Type of attribute</typeparam>
		/// <param name="memberInfo">MemberInfo object on which the attributes are checked</param>
		/// <param name="includeInheritedAttributes">True to include inherited attributes</param>
		/// <returns>List of matching attributes</returns>
		public static IEnumerable<TAttributeType> GetAttributes<TAttributeType>(this MemberInfo memberInfo, bool includeInheritedAttributes = true) where TAttributeType : Attribute
		{
			if (memberInfo == null)
			{
				throw new ArgumentNullException(nameof(memberInfo));
			}

			List<TAttributeType> attributeList = new List<TAttributeType>();
			// ReSharper disable once LoopCanBeConvertedToQuery
			// ReSharper disable once PossibleInvalidCastExceptionInForeachLoop
			foreach (TAttributeType attr in memberInfo.GetCustomAttributes(typeof(TAttributeType), includeInheritedAttributes))
			{
				attributeList.Add(attr);
			}
			return attributeList;
		}

		/// <summary>
		/// Gets the first attribute of a specified type
		/// </summary>
		/// <typeparam name="TAttributeType">Type of attribute</typeparam>
		/// <param name="memberInfo">MemberInfo object on which the attributes are checked</param>
		/// <param name="includeInheritedAttributes">True to include inherited attributes</param>
		/// <returns>First matching attribute</returns>
		public static TAttributeType GetAttribute<TAttributeType>(this MemberInfo memberInfo, bool includeInheritedAttributes = true) where TAttributeType : Attribute
		{
			// ReSharper disable once LoopCanBeConvertedToQuery
			foreach (TAttributeType attr in GetAttributes<TAttributeType>(memberInfo, includeInheritedAttributes) ?? new TAttributeType[0])
			{
				if (attr != null)
				{
					return attr;
				}
			}
			return null;
		}

		/// <summary>
		/// Determines default value of a type from its DefaultValueAttribute and/or type name
		/// </summary>
		/// <param name="memberInfo">Member info</param>
		/// <param name="defaultDefaultValue">Value to return if default value could not be determined</param>
		/// <returns>Default value of the type</returns>
		public static object GetDefaultValue(this MemberInfo memberInfo, object defaultDefaultValue = null)
		{
			DefaultValueAttribute defaultValueAttribute = GetAttribute<DefaultValueAttribute>(memberInfo);
			if (defaultValueAttribute != null)
			{
				return defaultValueAttribute.Value;
			}
			return defaultDefaultValue;
		}
		#endregion

		#region Generics
		/// <summary>
		/// Gets a generic method using reflection
		/// </summary>
		/// <param name="type">Type</param>
		/// <param name="methodName">Name of the method</param>
		/// <param name="genericArgumentTypes">Type arguments</param>
		/// <param name="methodArgumentTypes">Method argument types</param>
		/// <returns>Generic Method</returns>
		[SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "Flags")]
		public static MethodInfo GetGenericMethod(this Type type, string methodName, Type[] genericArgumentTypes, Type[] methodArgumentTypes)
		{
			if (type == null)
			{
				throw new ArgumentNullException(nameof(type));
			}

			methodName = (methodName ?? string.Empty).Trim();
			if (methodName.Length == 0)
			{
				throw new ArgumentNullException(nameof(methodName));
			}

			if ((genericArgumentTypes == null) || (genericArgumentTypes.Length == 0))
			{
				throw new ArgumentNullException(nameof(genericArgumentTypes));
			}

			if (methodArgumentTypes == null)
			{
				throw new ArgumentNullException(nameof(methodArgumentTypes));
			}

			MethodInfo methodInfo = null;
			foreach (MethodInfo miItem in type.GetRuntimeMethods())
			{
				if ((miItem.Name == methodName) &&
					(miItem.GetGenericArguments().Length == genericArgumentTypes.Length))
				{
					MethodInfo miGenericMethod = miItem.MakeGenericMethod(genericArgumentTypes);
					ParameterInfo[] piGenericMethodParams = miGenericMethod.GetParameters();
					bool paramTypesEqual = piGenericMethodParams.Length == methodArgumentTypes.Length;
					if (paramTypesEqual)
					{
						// ReSharper disable once LoopCanBeConvertedToQuery
						for (int i = 0; i < methodArgumentTypes.Length; ++i)
						{
							if (piGenericMethodParams[i].ParameterType != methodArgumentTypes[i])
							{
								paramTypesEqual = false;
								break;
							}
						}
					}
					if (paramTypesEqual)
					{
						methodInfo = miGenericMethod;
						break;
					}
				}
			}
			return methodInfo;
		}

		/// <summary>
		/// Retrieves type arguments of the specified genericType as implemented by the concrete type
		/// </summary>
		/// <param name="type">Concrete type</param>
		/// <param name="genericType">Generic type</param>
		/// <returns>Type arguments</returns>
		public static Type[] GetGenericTypeParameters(this Type type, Type genericType)
		{
			if ((type == null) || (type == typeof(object)))
			{
				throw new ArgumentNullException(nameof(type));
			}
			if (genericType == null)
			{
				throw new ArgumentNullException(nameof(genericType));
			}

			if (genericType.GetTypeInfo().IsInterface)
			{
				Type concreteType = null;
				// ReSharper disable once LoopCanBeConvertedToQuery
				foreach (Type ifType in type.GetTypeInfo().ImplementedInterfaces)
				{
					if (ifType.GetTypeInfo().IsGenericType && (ifType.GetGenericTypeDefinition() == genericType))
					{
						concreteType = ifType;
						break;
					}
				}
				return concreteType?.GenericTypeArguments;
			}
			else
			{
				if (type.GetTypeInfo().IsGenericType && (type.GetGenericTypeDefinition() == genericType))
				{
					return type.GenericTypeArguments;
				}
				if ((type.GetTypeInfo().BaseType != null) && (type.GetTypeInfo().BaseType != typeof(object)))
				{
					return GetGenericTypeParameters(type.GetTypeInfo().BaseType, genericType);
				}
				else
				{
					return null;
				}
			}
		}
		#endregion

		#region Miscellaneous
		/// <summary>
		/// Returns element type of a collection
		/// </summary>
		/// <param name="type">Collection type</param>
		/// <returns>Element type</returns>
		public static Type GetCollectionElementType(this Type type)
		{
			if ((type == null) || (type == typeof(string)))
			{
				return null;
			}
			if (type.IsArray)
			{
				return type.GetElementType();
			}
			Type[] argTypes = type.GetGenericTypeParameters(typeof(IEnumerable<>));
			if ((argTypes != null) && (argTypes.Length == 1))
			{
				return argTypes[0];
			}
			return null;
		}

		/// <summary>
		/// Trims the given namespace name
		/// </summary>
		/// <param name="namespaceName">Namespace</param>
		/// <returns>Trimmed namespace</returns>
		public static string TrimNamespace(string namespaceName)
		{
			namespaceName = string.Join(".",
				(namespaceName ?? string.Empty).Split('.').Select(s => s.Trim()).Where(s => s.Length > 0));
			return (namespaceName.Length > 0) ? namespaceName : null;
		}

		/// <summary>
		/// Removes invalid characters from the type name
		/// </summary>
		/// <param name="typeName">Type name</param>
		/// <returns>Valid type name</returns>
		public static string ToValidTypeName(string typeName)
		{
			if (string.IsNullOrWhiteSpace(typeName))
			{
				throw new ArgumentNullException(nameof(typeName));
			}
			return _invalidTypeNameCharsRegexRegex.Replace(typeName, "_");
		}

		/// <summary>
		/// Removes invalid characters from the type name
		/// </summary>
		/// <param name="typeName">Type name</param>
		/// <returns>Valid type name</returns>
		public static string ToValidFullTypeName(string typeName)
		{
			if (string.IsNullOrWhiteSpace(typeName)
				|| ((typeName = TrimNamespace(typeName)) == null))
			{
				throw new ArgumentNullException(nameof(typeName));
			}
			return string.Join(".", typeName.Split('.').Select(s => _invalidTypeNameCharsRegexRegex.Replace(s, "_")));
		}

		/// <summary>
		/// Checks if the specified type is a flags enum
		/// </summary>
		/// <param name="enumType"></param>
		/// <returns></returns>
		[SuppressMessage("Microsoft.Naming", "CA1726:UsePreferredTerms", MessageId = "Flags")]
		public static bool IsFlagsEnum(this Type enumType)
		{
			if ((enumType != null) && enumType.GetTypeInfo().IsEnum)
			{
				var flagsAttr = enumType.GetTypeInfo().GetCustomAttribute<FlagsAttribute>(true);
				return flagsAttr != null;
			}
			return false;
		}
		#endregion

		#region Sorting
		/// <summary>
		/// Sorts the types in the order of dependency of their assemblies
		/// </summary>
		/// <param name="types">List of types to sort</param>
		/// <param name="sortMode">Sorting mode</param>
		/// <returns>Sorted list of assemblies</returns>
		public static IEnumerable<Type> SortTypesOnDependency(this IEnumerable<Type> types,
			AssemblyDependencySortMode sortMode = AssemblyDependencySortMode.DependentsAfterDependencies)
		{
			if (types == null)
			{
				throw new ArgumentNullException(nameof(types));
			}
			List<Type> typeList = new List<Type>(types);
			typeList.Sort((x, y) =>
			{
				int multFactor = (sortMode == AssemblyDependencySortMode.DependentsAfterDependencies) ? 1 : -1;
				if ((x != null) && (y != null))
				{
					if (x.GetTypeInfo().Assembly.HasDependencyOn(y.GetTypeInfo().Assembly.GetName()))
					{
						return 1 * multFactor;
					}
					else if (y.GetTypeInfo().Assembly.HasDependencyOn(x.GetTypeInfo().Assembly.GetName()))
					{
						return -1 * multFactor;
					}
				}
				return 0;
			});
			return typeList;
		}

		#endregion

		#region Activator
		/// <summary>
		/// Creates an instance of the specified type
		/// </summary>
		/// <typeparam name="TType">Type of the object</typeparam>
		/// <param name="includeNonpublic">Include non-public classes</param>
		/// <param name="constructorParameters">Constructor parameters</param>
		/// <returns>Created instance</returns>
		public static TType CreateInstance<TType>(bool includeNonpublic = false, object[] constructorParameters = null)
		{
			return (TType)CreateInstance(typeof(TType), includeNonpublic, constructorParameters);
		}

		/// <summary>
		/// Creates an instance of the specified type
		/// </summary>
		/// <param name="type">Type to create</param>
		/// <param name="includePublicMembersOnly">Include public members only in the search</param>
		/// <param name="constructorParameters">Constructor parameters</param>
		/// <returns>Created instance</returns>
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
		public static object CreateInstance(this Type type, bool includePublicMembersOnly = false, params object[] constructorParameters)
		{
			if (type == null)
			{
				throw new ArgumentNullException(nameof(type));
			}
			try
			{
				return Activator.CreateInstance(type, constructorParameters);
			}
			// ReSharper disable once EmptyGeneralCatchClause
			catch { }
			return null;
		}
		#endregion
	}
}
