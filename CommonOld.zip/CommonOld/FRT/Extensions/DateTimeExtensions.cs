﻿using System;
using System.Linq;
using System.Xml;

namespace FRT
{
	/// <summary>
	/// Date time utilities
	/// </summary>
	public static class DateTimeExtensions
	{
		#region TimeSpan
		/// <summary>
		/// Converts timespan to xml string
		/// </summary>
		/// <param name="timeSpan"></param>
		/// <returns></returns>
		public static string ToXmlString(this TimeSpan timeSpan)
		{
			return XmlConvert.ToString(timeSpan);
		}

		/// <summary>
		/// Converts an xml string to timespan
		/// </summary>
		/// <param name="timeSpan"></param>
		/// <returns></returns>
		public static TimeSpan ToTimeSpan(this string timeSpan)
		{
			return string.IsNullOrWhiteSpace(timeSpan) ? TimeSpan.Zero : XmlConvert.ToTimeSpan(timeSpan);
		}

		/// <summary>
		/// Converts a time span into descriptive text
		/// for e.g. 3 days, 4 hours and 1 minute
		/// </summary>
		/// <param name="timeSpan">Timespan to format</param>
		/// <param name="shortText">Whether to return short text</param>
		/// <returns></returns>
		public static string ToDescriptiveText(this TimeSpan timeSpan, bool shortText = false)
		{
			var dayParts = new[] { GetDaysText(timeSpan, shortText), GetHoursText(timeSpan, shortText), GetMinutesText(timeSpan, shortText) }
									.Where(s => !string.IsNullOrWhiteSpace(s))
									.ToArray();
			var numberOfParts = dayParts.Length;

			string result;
			if (numberOfParts < 2)
			{
				result = dayParts.FirstOrDefault() ?? string.Empty;
			}
			else
			{
				result = string.Join(", ", dayParts, 0, numberOfParts - 1) + (shortText ? " " : " and ") + dayParts[numberOfParts - 1];
			}
			return result;
		}

		private static string GetMinutesText(TimeSpan timeSpan, bool shortText = false)
		{
			if (timeSpan.Minutes == 0) return string.Empty;
			if (timeSpan.Minutes == 1) return timeSpan.Minutes + (shortText ? " min." : " minute");
			return timeSpan.Minutes + (shortText ? " mins." : " minutes");
		}

		private static string GetHoursText(TimeSpan timeSpan, bool shortText = false)
		{
			if (timeSpan.Hours == 0) return string.Empty;
			if (timeSpan.Hours == 1) return timeSpan.Hours + (shortText ? " hr." : " hour");
			return timeSpan.Hours + (shortText ? " hrs." : " hours");
		}

		private static string GetDaysText(TimeSpan timeSpan, bool shortText = false)
		{
			if (timeSpan.Days == 0) return string.Empty;
			if (timeSpan.Days == 1) return timeSpan.Days + (shortText ? " d." : " day");
			return timeSpan.Days + (shortText ? " d." : " days");
		}
		#endregion

		#region Miscellaneous
		/// <summary>
		/// Converts a date time to Unix date time
		/// </summary>
		/// <param name="dateTime">DateTime object to convert</param>
		/// <returns>Unix ticks</returns>
		public static double UnixTicks(this DateTime dateTime)
		{
			var d1 = new DateTime(1970, 1, 1);
			var d2 = dateTime.ToUniversalTime();
			var ts = new TimeSpan(d2.Ticks - d1.Ticks);
			return ts.TotalMilliseconds;
		}

		/// <summary>
		/// Converts a date time to Unix date time
		/// </summary>
		/// <param name="dateTime">DateTime object to convert</param>
		/// <returns>Unix ticks</returns>
		public static double UnixTicks(this DateTimeOffset dateTime)
		{
			var d1 = new DateTime(1970, 1, 1);
			var d2 = dateTime.ToUniversalTime();
			var ts = new TimeSpan(d2.Ticks - d1.Ticks);
			return ts.TotalMilliseconds;
		}
		#endregion
	}
}
