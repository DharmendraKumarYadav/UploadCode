﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;

namespace FRT
{
	/// <summary>
	/// String extensions
	/// </summary>
	public static class StringExtensions
	{
		#region DisplayName
		/// <summary>
		/// Converts a name to display name separating it at the word separators
		/// </summary>
		/// <param name="name">Name</param>
		/// <param name="wordSeparator">String to be used as word separator</param>
		/// <param name="titleCase">Flag indicating whether words are converted to title case</param>
		/// <param name="nonSplittableTokens">Non-splittable tokens</param>
		/// <returns>Display name</returns>
		[SuppressMessage("Microsoft.Globalization", "CA1308:NormalizeStringsToUppercase")]
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		public static string NameToDisplayName(this string name, string wordSeparator = null, bool titleCase = false, IEnumerable<string> nonSplittableTokens = null)
		{
			// Check name
			if (string.IsNullOrWhiteSpace(name))
			{
				return name;
			}
			name = name.Trim();

			// Adjust word separator
			wordSeparator = wordSeparator ?? " ";

			// Non splittable token indices
			List<Tuple<int, int>> nonSplittableTokenIndices = new List<Tuple<int, int>>();
			if (nonSplittableTokens != null)
			{
				List<string> distinctNonSplittableTokens = new List<string>();
				foreach (string nonSplittableToken in nonSplittableTokens)
				{
					if (distinctNonSplittableTokens.Find(
						str => string.Equals(str, nonSplittableToken, StringComparison.OrdinalIgnoreCase)) == null)
					{
						distinctNonSplittableTokens.Add(nonSplittableToken);
					}
				}
				// ReSharper disable once LoopCanBeConvertedToQuery
				foreach (string nonSplittableToken in distinctNonSplittableTokens)
				{
					int index = name.IndexOf(nonSplittableToken, StringComparison.OrdinalIgnoreCase);
					if (index >= 0)
					{
						nonSplittableTokenIndices.Add(new Tuple<int, int>(index, index + nonSplittableToken.Length - 1));
					}
				}
			}
			// ReSharper disable once ConvertToLocalFunction
			Func<int, bool> checkSplittable = delegate (int i)
			{
				bool prvCharInRange = false;
				// ReSharper disable once LoopCanBeConvertedToQuery
				foreach (Tuple<int, int> item in nonSplittableTokenIndices)
				{
					if ((item.Item1 <= (i - 1)) && ((i - 1) <= item.Item2))
					{
						prvCharInRange = true;
						break;
					}
				}

				bool thisCharInRange = false;
				// ReSharper disable once LoopCanBeConvertedToQuery
				foreach (Tuple<int, int> item in nonSplittableTokenIndices)
				{
					if ((item.Item1 <= i) && (i <= item.Item2))
					{
						thisCharInRange = true;
						break;
					}
				}

				return !(prvCharInRange && thisCharInRange);
			};

			StringBuilder sbBuffer = new StringBuilder();
			int prvCharClass = 0; // 0 => whitespace, 1 => lowercase, 2 => uppercase, 3 => others
			bool isFirstChar = true;
			char[] charArray = name.ToCharArray();

			for (int iChar = 0, nChars = charArray.Length; iChar < nChars; ++iChar)
			{
				char ch = charArray[iChar];

				// Determine character class
				int curCharClass;
				if (char.IsWhiteSpace(ch))
				{
					curCharClass = 0;
				}
				else if (char.IsLetter(ch))
				{
					curCharClass = char.IsLower(ch) ? 1 : 2;
				}
				else
				{
					curCharClass = 3;
				}

				if (isFirstChar)
				{
					if (titleCase)
					{
						ch = char.ToUpperInvariant(ch);
					}
					sbBuffer.Append(ch);
					isFirstChar = false;
				}
				else
				{
					// Whitespace
					if (curCharClass == 0)
					{
						// Append only if prv is not whitespace
						if ((prvCharClass != 0) && checkSplittable(iChar))
						{
							sbBuffer.Append(wordSeparator);
						}
					}
					// Lowercase
					else if (curCharClass == 1)
					{
						// Append separator if previous char is other
						if ((prvCharClass == 3) && checkSplittable(iChar))
						{
							sbBuffer.Append(wordSeparator);

							// Convert to upper case if required
							if (titleCase)
							{
								ch = char.ToUpperInvariant(ch);
							}
						}
						sbBuffer.Append(ch);
					}
					// Uppercase
					else if (curCharClass == 2)
					{
						// Append separator if previous char is lowercase or other
						if ((prvCharClass == 1) || (prvCharClass == 3))
						{
							if (checkSplittable(iChar))
							{
								sbBuffer.Append(wordSeparator);
							}
						}
						// Append separator if this character is starting of a word
						else if (prvCharClass == 2)
						{
							// Check the next character
							if ((iChar < (nChars - 1))
								&& char.IsLower(charArray[iChar + 1])
								&& checkSplittable(iChar))
							{
								sbBuffer.Append(wordSeparator);
							}
						}
						sbBuffer.Append(ch);
					}
					// Other
					else if (curCharClass == 3)
					{
						// Append separator if previous char is anything other than other and whitespace
						if ((prvCharClass != 0) && (prvCharClass != 3) && checkSplittable(iChar))
						{
							sbBuffer.Append(wordSeparator);
						}
						sbBuffer.Append(ch);
					}
				}
				prvCharClass = curCharClass;
			}

			var resultText = sbBuffer.ToString();
			if (!titleCase)
			{
				return (resultText.Length > 1) ? (resultText.Substring(0, 1) + resultText.Substring(1).ToLowerInvariant()) : resultText;
			}
			return resultText;
		}

		/// <summary>
		/// Converts a display name to name by combining the words
		/// </summary>
		/// <param name="displayName">Display name</param>
		/// <param name="wordSeparator">Word separator</param>
		/// <param name="makeTitleCase">Appends the words by making them as title case</param>
		/// <param name="nonSplittableTokens">Non-splittable tokens</param>
		/// <returns>Name</returns>
		public static string DisplayNameToName(this string displayName, string wordSeparator = null, bool makeTitleCase = true, IEnumerable<string> nonSplittableTokens = null)
		{
			// Check name
			if (string.IsNullOrWhiteSpace(displayName))
			{
				return displayName;
			}
			displayName = displayName.Trim();

			// Word separator
			wordSeparator = wordSeparator ?? " ";

			// Non splittable token indices
			List<Tuple<int, int>> nonSplittableTokenIndices = new List<Tuple<int, int>>();
			if (nonSplittableTokens != null)
			{
				List<string> distinctNonSplittableTokens = new List<string>();
				foreach (string nonSplittableToken in nonSplittableTokens)
				{
					if (distinctNonSplittableTokens.Find(
						str => string.Equals(str, nonSplittableToken, StringComparison.OrdinalIgnoreCase)) == null)
					{
						distinctNonSplittableTokens.Add(nonSplittableToken);
					}
				}
				// ReSharper disable once LoopCanBeConvertedToQuery
				foreach (string nonSplittableToken in distinctNonSplittableTokens)
				{
					int index = displayName.IndexOf(nonSplittableToken, StringComparison.OrdinalIgnoreCase);
					if (index >= 0)
					{
						nonSplittableTokenIndices.Add(new Tuple<int, int>(index, index + nonSplittableToken.Length - 1));
					}
				}
			}
			Func<int, bool> checkCombinable = delegate (int i)
			{
				bool combinable = true;
				foreach (Tuple<int, int> item in nonSplittableTokenIndices)
				{
					if ((item.Item1 <= i) && (i <= item.Item2))
					{
						combinable = false;
					}
				}
				return combinable;
			};

			StringBuilder sbBuffer = new StringBuilder();
			int wordSeparatorLength = wordSeparator.Length;
			bool firstSeriesChar = true;

			for (int iChar = 0, nChars = displayName.Length; iChar < nChars; ++iChar)
			{
				if (displayName.IndexOf(wordSeparator, iChar, StringComparison.OrdinalIgnoreCase) == iChar)
				{
					if (!checkCombinable(iChar))
					{
						sbBuffer.Append(displayName.Substring(iChar, wordSeparatorLength));
					}

					iChar += wordSeparatorLength - 1;
					firstSeriesChar = true;
				}
				else
				{
					if (firstSeriesChar && makeTitleCase && char.IsLetter(displayName[iChar]))
					{
						sbBuffer.Append(displayName[iChar].ToString().ToUpperInvariant());
					}
					else
					{
						sbBuffer.Append(displayName[iChar]);
					}
					firstSeriesChar = false;
				}
			}
			return sbBuffer.ToString();
		}
		#endregion

		#region Hex String to Bytes
		/// <summary>
		/// Converts a hex representation of data to byte array
		/// </summary>
		/// <param name="hexText">Hex representation of data</param>
		/// <returns>Byte array</returns>
		public static byte[] HexStringToByteArray(string hexText)
		{
			if (hexText == null)
			{
				return null;
			}

			byte[] returnBytes = new byte[hexText.Length / 2];
			for (int i = 0; i < returnBytes.Length; i++)
			{
				returnBytes[i] = Convert.ToByte(hexText.Substring(i * 2, 2), 16);
			}
			return returnBytes;
		}
		#endregion

		#region Split & Join
		/// <summary>
		/// Splits a given string to parts with the specified separators
		/// </summary>
		/// <param name="text">Text to split</param>
		/// <param name="separators">Separators</param>
		/// <param name="count">Split options</param>
		/// <param name="comparisonType">Comparison type</param>
		/// <returns>Tuple containing the string parts and the separators</returns>
		public static string[] Split(this string text, string[] separators, int count = int.MaxValue, StringComparison comparisonType = StringComparison.Ordinal)
		{
			if (text == null)
			{
				throw new ArgumentNullException(nameof(text));
			}
			if (separators == null)
			{
				throw new ArgumentNullException(nameof(separators));
			}

			List<string> nonNullSeparators = new List<string>();
			// ReSharper disable once LoopCanBeConvertedToQuery
			foreach (string str in separators)
			{
				if (str != null)
				{
					nonNullSeparators.Add(str);
				}
			}
			separators = nonNullSeparators.ToArray();
			if (separators.Length == 0)
			{
				throw new ArgumentNullException(nameof(separators));
			}

			// Locate separators
			List<Tuple<int, int>> positionSeparatorIndexList = new List<Tuple<int, int>>();
			for (int iChar = 0, nChars = text.Length; iChar < nChars; ++iChar)
			{
				for (int iSep = 0, nSeps = separators.Length; iSep < nSeps; ++iSep)
				{
					if (text.IndexOf(separators[iSep], iChar, comparisonType) == iChar)
					{
						positionSeparatorIndexList.Add(new Tuple<int, int>(iChar, iSep));
						iChar += separators[iSep].Length;
						break;
					}
				}
			}

			// Extract Tokens
			List<string> partList = new List<string>();
			if (positionSeparatorIndexList.Count == 0)
			{
				partList.Add(text);
			}
			else
			{
				int nextIndex = 0;
				foreach (Tuple<int, int> positionSeparatorIndex in positionSeparatorIndexList)
				{
					string separator = separators[positionSeparatorIndex.Item2];

					// Add the part and separator
					partList.Add(text.Substring(nextIndex, positionSeparatorIndex.Item1 - nextIndex));
					partList.Add(separator);

					// Advance to next index
					nextIndex = positionSeparatorIndex.Item1 + separator.Length;
				}

				// Last part
				partList.Add(nextIndex < text.Length ? text.Substring(nextIndex) : string.Empty);
			}

			List<string> returnList = new List<string>();
			count = Math.Min(count, partList.Count);
			for (int i = 0; i < count; ++i)
			{
				returnList.Add(partList[i]);
			}
			return returnList.ToArray();
		}
		#endregion

		#region Miscellaneous

		/// <summary>
		/// Converts the given text to camel case
		/// </summary>
		/// <param name="text"></param>
		/// <returns></returns>
		[SuppressMessage("Microsoft.Globalization", "CA1308:NormalizeStringsToUppercase")]
		public static string ToCamelCase(this string text)
		{
			if (string.IsNullOrWhiteSpace(text))
			{
				return text;
			}
			text = text.Trim();
			if (text.Length <= 0)
			{
				return text.ToLowerInvariant();
			}
			return text.Substring(0, 1).ToLowerInvariant() + text.Substring(1);
		}

		/// <summary>
		/// Converts this string into a byte array
		/// </summary>
		[SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "str")]
		public static byte[] FromBase64(this string str)
		{
			return (str == null) ? null
				: (string.IsNullOrWhiteSpace(str) ? new byte[0]
				: Convert.FromBase64String(str.Trim()));
		}

		/// <summary>
		/// Shortcut
		/// </summary>
		/// <param name="text">Text</param>
		/// <returns>True if text is null or whitespace</returns>
		public static bool IsNullOrWhiteSpace(this string text)
		{
			return string.IsNullOrWhiteSpace(text);
		}

		/// <summary>
		/// Returns a non-empty text or null if empty
		/// </summary>
		/// <param name="text">Text</param>
		/// <returns>Non-empty text or null if empty</returns>
		public static string NonemptyOrNullTrimmed(this string text)
		{
			return string.IsNullOrWhiteSpace(text) ? null : text.Trim();
		}

		/// <summary>
		/// Returns a non-empty text or null if empty
		/// </summary>
		/// <param name="text">Text</param>
		/// <returns>Non-empty text or null if empty</returns>
		public static string NonemptyOrNull(this string text)
		{
			return string.IsNullOrWhiteSpace(text) ? null : text;
		}

		/// <summary>
		/// Compares two strings including null vaues
		/// </summary>
		/// <param name="text1">Text 1</param>
		/// <param name="text2">Text 2</param>
		/// <param name="comparison">Comparison</param>
		/// <returns>Comparison result</returns>
		public static bool NullableEquals(this string text1, string text2, StringComparison comparison = StringComparison.Ordinal)
		{
			return ((text1 == null) && (text2 == null))
				   || ((text1 != null) && (text2 != null) && string.Equals(text1, text2, comparison));
		}

		/// <summary>
		/// Replaces a given text
		/// </summary>
		/// <param name="text">Text to replace in</param>
		/// <param name="searchPhrase">Text to replace</param>
		/// <param name="replacePhrase">Text to replace with</param>
		/// <param name="comparison">String comparison</param>
		/// <returns>Replated text</returns>
		public static string Replace(this string text, string searchPhrase, string replacePhrase, StringComparison comparison)
		{
			// Validate
			if (text == null)
			{
				throw new ArgumentNullException(nameof(text));
			}
			if (string.IsNullOrWhiteSpace(searchPhrase))
			{
				throw new ArgumentNullException(nameof(searchPhrase));
			}
			if (replacePhrase == null)
			{
				throw new ArgumentNullException(nameof(replacePhrase));
			}

			int searchLength = searchPhrase.Length;
			int index = text.IndexOf(searchPhrase, comparison);
			while (index >= 0)
			{
				text = text.Substring(0, index) + replacePhrase + text.Substring(index + searchLength);
				if (index < text.Length - 1)
				{
					index = text.IndexOf(searchPhrase, index + 1, comparison);
				}
				else
				{
					break;
				}
			}
			return text;
		}

		/// <summary>
		/// Indents the given string
		/// </summary>
		/// <param name="text"></param>
		/// <param name="indentCount">Number of indent strings to prefix</param>
		/// <param name="indentString">Indent string</param>
		/// <returns>Indented text</returns>
		[SuppressMessage("Microsoft.Naming", "CA1720:IdentifiersShouldNotContainTypeNames", MessageId = "string")]
		public static string Indent(this string text, int indentCount = 1, string indentString = "\t")
		{
			if (text == null)
			{
				return null;
			}
			else if ((indentCount == 0) || string.IsNullOrEmpty(indentString))
			{
				return text;
			}

			// Indent text
			string indentText = "";
			for (int i = 0; i < Math.Abs(indentCount); ++i)
			{
				indentText += indentString;
			}

			// Build
			List<string> lines = new List<string>();
			List<string> endOfLines = new List<string>();
			StringBuilder sbLine = new StringBuilder();
			for (int iChar = 0; iChar < text.Length; ++iChar)
			{
				if ((iChar < (text.Length - 1)) && (text[iChar] == '\r') && (text[iChar + 1] == '\n'))
				{
					lines.Add(sbLine.ToString());
					endOfLines.Add("\r\n");
					sbLine.Clear();
				}
				else if ((text[iChar] == '\n') || (text[iChar] == '\r'))
				{
					lines.Add(sbLine.ToString());
					endOfLines.Add(text[iChar].ToString());
					sbLine.Clear();
				}
				else
				{
					sbLine.Append(text[iChar]);
				}
			}
			if (sbLine.Length > 0)
			{
				lines.Add(sbLine.ToString());
			}

			// Increase/Decrease Indent
			lines = (indentCount > 0)
				? lines.Select(l => indentText + l).ToList()
				: lines.Select(l => l.StartsWith(indentText, StringComparison.Ordinal) ? l.Substring(indentText.Length) : l).ToList();

			// Combine & Return
			sbLine.Clear();
			for (int iLine = 0; iLine < lines.Count; ++iLine)
			{
				sbLine.Append(lines[iLine]);
				if (endOfLines.Count > iLine)
				{
					sbLine.Append(endOfLines[iLine]);
				}
			}
			return sbLine.ToString();
		}

		/// <summary>
		/// Replaces regex escape sequences in the text
		/// </summary>
		/// <param name="text"></param>
		/// <returns></returns>
		public static string EscapeRegexPattern(string text)
		{
			if (string.IsNullOrWhiteSpace(text))
			{
				return text;
			}

			// https://msdn.microsoft.com/en-us/library/4edbef7e(v=vs.110).aspx
			return text.Replace(".", "\\.")
				.Replace("$", "\\$")
				.Replace("^", "\\^")
				.Replace("{", "\\{")
				.Replace("[", "\\[")
				.Replace("(", "\\(")
				.Replace("}", "\\}")
				.Replace("]", "\\]")
				.Replace(")", "\\)")
				.Replace("|", "\\|")
				.Replace("*", "\\*")
				.Replace("+", "\\+")
				.Replace("?", "\\?")
				.Replace("\\", "\\\\");
		}

		/// <summary>
		/// Adds css class names to the given class string
		/// </summary>
		/// <param name="cssClassName">Original class value</param>
		/// <param name="newClassNames">New class names</param>
		/// <returns>Appended Css class value</returns>
		public static string AddCssClassNames(this string cssClassName, params string[] newClassNames)
		{
			cssClassName = (cssClassName ?? string.Empty).Trim();
			newClassNames = (newClassNames ?? new string[0])
				.Where(c => !string.IsNullOrWhiteSpace(c))
				.SelectMany(c => c.Split(' '))
				.Where(c => !string.IsNullOrWhiteSpace(c))
				.Select(c => c.Trim())
				.Distinct(StringComparer.Ordinal)
				.ToArray();
			var names = cssClassName.Split(' ').Where(c => !string.IsNullOrWhiteSpace(c)).Select(c => c.Trim()).Distinct(StringComparer.Ordinal).ToList();
			return string.Join(" ", names.Concat(newClassNames.Except(names, StringComparer.Ordinal)));
		}
		#endregion
	}
}

