﻿using IdentityServer4.AspNetIdentity;
using Microsoft.AspNetCore.Identity;

namespace Microsoft.Extensions.DependencyInjection
{
    public static class IdentityServerAspNetIdentityServiceCollectionExtensions
    {
        public static IServiceCollection AddIdentityServerUserClaimsPrincipalFactory<TUser, TRole>(this IServiceCollection services)
            where TUser : class
            where TRole : class
        {
            return services.AddTransient<IUserClaimsPrincipalFactory<TUser>, UserClaimsFactory<TUser, TRole>>();
        }
    }
}
