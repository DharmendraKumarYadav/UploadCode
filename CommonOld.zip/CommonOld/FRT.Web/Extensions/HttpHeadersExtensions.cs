﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;

namespace FRT.Web
{
	/// <summary>
	/// HttpHeaders Extensions
	/// </summary>
	public static class HttpHeadersExtensions
	{
		/// <summary>
		/// Tries to get the value of a header if present
		/// </summary>
		/// <param name="httpHeaders">Headers</param>
		/// <param name="headerName">Header name</param>
		/// <param name="valueSelector">Value selector</param>
		/// <returns></returns>
		public static string TryGetValue(this HttpHeaders httpHeaders, string headerName, Func<IEnumerable<string>, string> valueSelector)
		{
			if (httpHeaders == null)
			{
				throw new ArgumentNullException(nameof(httpHeaders));
			}
			if (string.IsNullOrWhiteSpace(headerName))
			{
				throw new ArgumentNullException(nameof(headerName));
			}
			if (valueSelector == null)
			{
				throw new ArgumentNullException(nameof(valueSelector));
			}

			var values = httpHeaders.Contains(headerName = headerName.Trim()) ? httpHeaders.GetValues(headerName) : null;
			if (values != null)
			{
				return valueSelector(values);
			}
			return null;
		}

		/// <summary>
		/// Tries to get the values of a header if present
		/// </summary>
		/// <param name="httpHeaders">Headers</param>
		/// <param name="headerName">Header name</param>
		/// <returns></returns>
		public static IEnumerable<string> TryGetValues(this HttpHeaders httpHeaders, string headerName)
		{
			if (httpHeaders == null)
			{
				throw new ArgumentNullException(nameof(httpHeaders));
			}
			if (string.IsNullOrWhiteSpace(headerName))
			{
				throw new ArgumentNullException(nameof(headerName));
			}
			return httpHeaders.Contains(headerName = headerName.Trim()) ? httpHeaders.GetValues(headerName) : null;
		}

		/// <summary>
		/// Sets the values of the header, replacing any already set values
		/// </summary>
		/// <param name="httpHeaders">Headers</param>
		/// <param name="headerName">Header name</param>
		/// <param name="values">Values</param>
		public static void SetValues(this HttpHeaders httpHeaders, string headerName, params string[] values)
		{
			if (httpHeaders == null)
			{
				throw new ArgumentNullException(nameof(httpHeaders));
			}
			if (string.IsNullOrWhiteSpace(headerName))
			{
				throw new ArgumentNullException(nameof(headerName));
			}
			values = (values ?? new string[0]).Where(v => v != null).ToArray();
			if (values.Length == 0)
			{
				throw new ArgumentNullException(nameof(values));
			}

			httpHeaders.Remove(headerName = headerName.Trim());
			httpHeaders.Add(headerName, values);
		}

		/// <summary>
		/// Appends the values of the header, keeping any already set values
		/// </summary>
		/// <param name="httpHeaders">Headers</param>
		/// <param name="headerName">Header name</param>
		/// <param name="values">Values</param>
		public static void AppendValues(this HttpHeaders httpHeaders, string headerName, params string[] values)
		{
			if (httpHeaders == null)
			{
				throw new ArgumentNullException(nameof(httpHeaders));
			}
			if (string.IsNullOrWhiteSpace(headerName))
			{
				throw new ArgumentNullException(nameof(headerName));
			}
			values = (values ?? new string[0]).Where(v => v != null).ToArray();
			if (values.Length == 0)
			{
				throw new ArgumentNullException(nameof(values));
			}

			httpHeaders.Add(headerName, values);
		}
	}
}