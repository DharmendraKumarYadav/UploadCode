﻿using System;
using System.Linq;
using System.Reflection;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace FRT.Web
{
	/// <summary>
	/// Mvc extensions
	/// </summary>
	public static class MvcExtensions
	{
		#region Binding Metadata

		/// <summary>
		/// Retrieves the attributes of specified type
		/// </summary>
		/// <typeparam name="TAttribute">Attribute type</typeparam>
		/// <param name="bindingContext">Binding context</param>
		/// <returns>Attributes</returns>
		public static TAttribute[] GetAttributes<TAttribute>(this ModelBindingContext bindingContext)
			where TAttribute : Attribute
		{
			if (bindingContext == null)
			{
				return null;
			}
			return GetAttributes<TAttribute>(bindingContext.ModelMetadata);
		}

		/// <summary>
		/// Retrieves the attributes of specified type
		/// </summary>
		/// <typeparam name="TAttribute">Attribute type</typeparam>
		/// <param name="modelMetadata">Model metadata</param>
		/// <returns>Attributes</returns>
		public static TAttribute[] GetAttributes<TAttribute>(this ModelMetadata modelMetadata)
			where TAttribute : Attribute
		{
			// Validate
			if (modelMetadata == null)
			{
				return null;
			}

			// Get the AttributeUsage attribute

			var holderType = modelMetadata.ContainerType;
			if (holderType != null)
			{
				// Check the attributes on the property
				var propertyInfo = holderType.GetProperty(modelMetadata.PropertyName);
				return propertyInfo.GetCustomAttributes(typeof(TAttribute), true).Cast<TAttribute>().ToArray();
			}
			else
			{
				return modelMetadata.UnderlyingOrModelType.GetTypeInfo().GetCustomAttributes(typeof(TAttribute), true).Cast<TAttribute>().ToArray();
			}
		}

		#endregion

		#region Model State

		/// <summary>
		/// Retrieves all model errors from the model state
		/// </summary>
		/// <param name="modelState">Model state</param>
		public static string[] GetErrors(this ModelStateDictionary modelState)
		{
			if (modelState == null)
			{
				throw new ArgumentNullException(nameof(modelState));
			}

			return modelState.Values.SelectMany(v => v.Errors)
				.Select(e => e.ErrorMessage).ToArray();
		}

		#endregion
	}
}
