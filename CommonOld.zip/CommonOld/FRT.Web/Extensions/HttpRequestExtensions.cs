﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.Encodings.Web;
using FRT.Web.Localization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.Extensions.Primitives;

namespace FRT.Web
{
	/// <summary>
	/// HttpRequest Extensions
	/// </summary>
	public static class HttpRequestExtensions
	{
		/// <summary>
		/// Returns the value from QueryString/Form/Cookies/Headers
		/// </summary>
		/// <param name="httpRequest"></param>
		/// <param name="name"></param>
		/// <returns></returns>
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
		public static StringValues GetItem(this HttpRequest httpRequest, string name)
		{
			if (httpRequest == null)
			{
				throw new ArgumentNullException(nameof(httpRequest));
			}
			if (string.IsNullOrWhiteSpace(name))
			{
				throw new ArgumentNullException(nameof(name));
			}
			name = name.Trim();

			// Check Query String
			try
			{
				if (httpRequest.Query.ContainsKey(name))
				{
					return httpRequest.Query[name];
				}
			}
			// ReSharper disable once EmptyGeneralCatchClause
			catch { }

			// Check Form
			try
			{
				if (httpRequest.Form.ContainsKey(name))
				{
					return httpRequest.Form[name];
				}
			}
			// ReSharper disable once EmptyGeneralCatchClause
			catch { }

			// Check Cookies
			try
			{
				if (httpRequest.Cookies.ContainsKey(name))
				{
					return httpRequest.Cookies[name];
				}
			}
			// ReSharper disable once EmptyGeneralCatchClause
			catch { }

			// Server variables
			try
			{
				if (httpRequest.Headers.ContainsKey(name))
				{
					return httpRequest.Headers[name];
				}
			}
			// ReSharper disable once EmptyGeneralCatchClause
			catch { }

			// Not found
			return StringValues.Empty;
		}

		/// <summary>
		/// Request Uri
		/// </summary>
		/// <param name="httpRequest">Http Request</param>
		/// <returns>Request Uri</returns>
		public static Uri GetUri(this HttpRequest httpRequest)
		{
			return (httpRequest != null) ? new Uri(httpRequest.GetEncodedUrl(), UriKind.Absolute) : null;
		}

		/// <summary>
		/// Gets the user languages for the current request
		/// </summary>
		/// <param name="httpRequest">Http request</param>
		/// <returns>User languages</returns>
		public static BrowserLanguageInfo[] GetUserLanguages(this HttpRequest httpRequest)
		{
			// Validate
			if (httpRequest == null)
			{
				return null;
			}

			// If we already have it, return
			const string contextKey = "FRT.Web.HttpRequestExtensions.UserLanguages";
			var langList = httpRequest.HttpContext.Items[contextKey] as BrowserLanguageInfo[];
			if (langList != null)
			{
				return langList;
			}

			// Parse
			var parsedStrs = ParseMultiValueHeader(httpRequest.Headers["Accept-Language"]) ?? new string[0];
			langList = parsedStrs.Select(s =>
			{
				var semiColonIndex = s.IndexOf(";", StringComparison.Ordinal);
				if (semiColonIndex < 0)
				{
					return new BrowserLanguageInfo(s.Trim(), 1.0);
				}
				else
				{
					var langStr = s.Substring(0, semiColonIndex).Trim();
					var qStr = s.Substring(semiColonIndex + 1).Replace(" ", string.Empty);
					if (qStr.StartsWith("q=", StringComparison.OrdinalIgnoreCase))
					{
						return new BrowserLanguageInfo(langStr, double.Parse(qStr.Substring(2), CultureInfo.InvariantCulture));
					}
					return new BrowserLanguageInfo(langStr, 1.0);
				}
			}).OrderByDescending(l => l.Weightage).ToArray();

			// Save & Return
			httpRequest.HttpContext.Items[contextKey] = langList;
			return langList;
		}

		/// <summary>
		/// Parses a multi value header
		/// </summary>
		/// <param name="header">Header value</param>
		/// <returns>Items</returns>
		[SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "Multi")]
		public static string[] ParseMultiValueHeader(string header)
		{
			if (string.IsNullOrWhiteSpace(header))
			{
				return null;
			}

			var list = new List<string>();
			var num = header.Length;
			var startIndex = 0;
			while (startIndex < num)
			{
				var index = header.IndexOf(',', startIndex);
				if (index < 0)
				{
					index = num;
				}

				list.Add(header.Substring(startIndex, index - startIndex));
				startIndex = index + 1;
				if ((startIndex < num) && (header[startIndex] == ' '))
				{
					startIndex++;
				}
			}
			return (list.Count == 0) ? null : list.ToArray();
		}

		/// <summary>
		/// Formats the request details as html
		/// </summary>
		public static string GetFormattedHtml(this HttpRequest request)
		{
			// Validate
			if (request == null)
			{
				throw new ArgumentNullException(nameof(request));
			}

			// Builder
			var contentBuilder = new StringBuilder();

			// Table start
			contentBuilder.AppendLine("<table class=\"table table-bordered table-striped data-table\">");

			contentBuilder.AppendFormat(CultureInfo.InvariantCulture, "<tr><td><strong>Scheme</strong></td><td>{0}</td></tr>" + Environment.NewLine, request.Scheme);
			contentBuilder.AppendFormat(CultureInfo.InvariantCulture, "<tr><td><strong>Protocol</strong></td><td>{0}</td></tr>" + Environment.NewLine, request.Protocol);
			contentBuilder.AppendFormat(CultureInfo.InvariantCulture, "<tr><td><strong>Secure</strong></td><td>{0}</td></tr>" + Environment.NewLine, request.IsHttps ? "Yes" : "No");
			if (request.Host.HasValue)
			{
				contentBuilder.AppendFormat(CultureInfo.InvariantCulture, "<tr><td><strong>Host</strong></td><td>{0}</td></tr>" + Environment.NewLine, HtmlEncoder.Default.Encode(request.Host.ToString()));
			}
			if (request.PathBase.HasValue)
			{
				contentBuilder.AppendFormat(CultureInfo.InvariantCulture, "<tr><td><strong>Path base</strong></td><td>{0}</td></tr>" + Environment.NewLine, HtmlEncoder.Default.Encode(request.PathBase.ToString()));
			}
			if (request.Path.HasValue)
			{
				contentBuilder.AppendFormat(CultureInfo.InvariantCulture, "<tr><td><strong>Path</strong></td><td>{0}</td></tr>" + Environment.NewLine, HtmlEncoder.Default.Encode(request.Path));
			}
			contentBuilder.AppendFormat(CultureInfo.InvariantCulture, "<tr><td><strong>Method</strong></td><td>{0}</td></tr>" + Environment.NewLine, request.Method);
			contentBuilder.AppendFormat(CultureInfo.InvariantCulture, "<tr><td><strong>Content length</strong></td><td>{0}</td></tr>" + Environment.NewLine, request.ContentLength?.ToString(CultureInfo.InvariantCulture) ?? "Not set");
			contentBuilder.AppendFormat(CultureInfo.InvariantCulture, "<tr><td><strong>Content type</strong></td><td>{0}</td></tr>" + Environment.NewLine, request.ContentType ?? "Not set");
			if (request.QueryString.HasValue)
			{
				contentBuilder.AppendFormat(CultureInfo.InvariantCulture, "<tr><td><strong>Query string</strong></td><td>{0}</td></tr>" + Environment.NewLine, HtmlEncoder.Default.Encode(request.QueryString.ToString()));
			}
			if (request.HasFormContentType && (request.Form.Count > 0))
			{
				contentBuilder.AppendFormat(CultureInfo.InvariantCulture, "<tr><td><strong>Form data</strong></td><td>{0}</td></tr>" + Environment.NewLine,
					string.Join("; ", request.Form.Select(kv => string.Format(CultureInfo.InvariantCulture, "{0} = {1}", HtmlEncoder.Default.Encode(kv.Key), HtmlEncoder.Default.Encode(kv.Value)))));
			}
			contentBuilder.AppendFormat(CultureInfo.InvariantCulture, "<tr><td><strong>Headers</strong></td><td>{0}</td></tr>" + Environment.NewLine,
				string.Join("; ", request.Headers.Select(kv => string.Format(CultureInfo.InvariantCulture, "{0} = {1}", HtmlEncoder.Default.Encode(kv.Key), HtmlEncoder.Default.Encode(kv.Value)))));
			contentBuilder.AppendFormat(CultureInfo.InvariantCulture, "<tr><td><strong>Cookies</strong></td><td>{0}</td></tr>" + Environment.NewLine,
				string.Join("; ", request.Cookies.Select(kv => string.Format(CultureInfo.InvariantCulture, "{0} = {1}", HtmlEncoder.Default.Encode(kv.Key), HtmlEncoder.Default.Encode(kv.Value)))));

			// Table end
			contentBuilder.AppendLine("</table>");
			return contentBuilder.ToString();
		}
	}
}