﻿using System;
using Microsoft.Extensions.DependencyInjection;

namespace FRT.Web
{
	/// <summary>
	/// Date time utilities
	/// </summary>
	public static class WebDateTimeExtensions
	{
		#region Time Zone

		/// <summary>
		/// Converts the given date time to server local time
		/// </summary>
		public static DateTimeOffset ToServerTime(this DateTimeOffset dateAndTime)
		{
			var timeZoneManager = DI.Container.GetService<IWebTimeZoneManager>();
			var serverTimeZone = timeZoneManager?.ServerTimeZone ?? TimeZoneInfo.Local;
			return TimeZoneInfo.ConvertTime(dateAndTime, serverTimeZone);
		}

		/// <summary>
		/// Converts the given date time to server local time
		/// </summary>
		public static DateTimeOffset? ToServerTime(this DateTimeOffset? dateAndTime)
		{
			if (!dateAndTime.HasValue)
			{
				return null;
			}
			return ToServerTime(dateAndTime.Value);
		}

		/// <summary>
		/// Converts the given date time to client local time
		/// </summary>
		public static DateTimeOffset ToClientTime(this DateTimeOffset dateAndTime)
		{
			var timeZoneManager = DI.Container.GetService<IWebTimeZoneManager>();
			var clientTimeZone = timeZoneManager?.ClientEffectiveTimeZone ?? TimeZoneInfo.Local;
			return TimeZoneInfo.ConvertTime(dateAndTime, clientTimeZone);
		}

		/// <summary>
		/// Converts the given date time to server local time
		/// </summary>
		public static DateTimeOffset? ToClientTime(this DateTimeOffset? dateAndTime)
		{
			if (!dateAndTime.HasValue)
			{
				return null;
			}
			return ToClientTime(dateAndTime.Value);
		}

		/// <summary>
		/// Converts the given date time to server local time
		/// </summary>
		public static DateTime ToServerTime(this DateTime dateAndTime)
		{
			var timeZoneManager = DI.Container.GetService<IWebTimeZoneManager>();
			var serverTimeZone = timeZoneManager?.ServerTimeZone ?? TimeZoneInfo.Local;
			return TimeZoneInfo.ConvertTime(dateAndTime, serverTimeZone);
		}

		/// <summary>
		/// Converts the given date time to server local time
		/// </summary>
		public static DateTime? ToServerTime(this DateTime? dateAndTime)
		{
			if (!dateAndTime.HasValue)
			{
				return null;
			}
			return ToServerTime(dateAndTime.Value);
		}

		/// <summary>
		/// Converts the given date time to client local time
		/// </summary>
		public static DateTime ToClientTime(this DateTime dateAndTime)
		{
			var timeZoneManager = DI.Container.GetService<IWebTimeZoneManager>();
			var clientTimeZone = timeZoneManager?.ClientEffectiveTimeZone ?? TimeZoneInfo.Local;
			return TimeZoneInfo.ConvertTime(dateAndTime, clientTimeZone);
		}

		/// <summary>
		/// Converts the given date time to server local time
		/// </summary>
		public static DateTime? ToClientTime(this DateTime? dateAndTime)
		{
			if (!dateAndTime.HasValue)
			{
				return null;
			}
			return ToClientTime(dateAndTime.Value);
		}

		#endregion
	}
}
