﻿using System;
using System.Diagnostics.CodeAnalysis;
using Microsoft.Extensions.DependencyInjection;
using AutoMapper;
using CacheManager.Core;
using FRT.Caching;
using FRT.Cryptography;
using FRT.Messaging;
using FRT.Validation;
using FRT.Web;
using FRT.Web.Localization;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Localization;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace FRT
{
	/// <summary>
	/// Global access to cross-cutting services
	/// </summary>
	public static class WebCrosscuttings
	{
		#region Configurations

		/// <summary>
		/// Configuration
		/// </summary>
		public static IOptions<WebLocalizationConfig> WebLocalizationConfigOptions
			=> DI.Container.GetService<IOptions<WebLocalizationConfig>>();

		/// <summary>
		/// Configuration
		/// </summary>
		public static IOptions<RemoteProxyConfig> RemoteProxyConfigOptions
			=> DI.Container.GetService<IOptions<RemoteProxyConfig>>();

		/// <summary>
		/// Configuration
		/// </summary>
		public static IOptions<WebSecurityConfig> WebSecurityConfigOptions
			=> DI.Container.GetService<IOptions<WebSecurityConfig>>();

		/// <summary>
		/// Configuration
		/// </summary>
		public static IOptions<WebTimeZoneConfig> WebTimeZoneConfigOptions
			=> DI.Container.GetService<IOptions<WebTimeZoneConfig>>();

		#endregion

		#region Services

		/// <summary>
		/// Web app url accessor
		/// </summary>
		public static IWebAppUrlAccessor WebAppUrlAccessor => DI.Container.GetService<IWebAppUrlAccessor>();

		/// <summary>
		/// Request languages provider
		/// </summary>
		public static IHttpRequestLanguagesProvider HttpRequestLanguagesProvider => DI.Container
			.GetService<IHttpRequestLanguagesProvider>();

		/// <summary>
		/// Http Context accessor
		/// </summary>
		public static IHttpContextAccessor HttpContextAccessor => DI.Container.GetService<IHttpContextAccessor>();

		/// <summary>
		/// Http context
		/// </summary>
		public static HttpContext HttpContext => HttpContextAccessor?.HttpContext;

		/// <summary>
		/// Web timezone manager
		/// </summary>
		public static IWebTimeZoneManager WebTimeZoneManager => DI.Container.GetService<IWebTimeZoneManager>();

		#endregion

		#region Registration

		/// <summary>
		/// Registers the services implemented in this assembly
		/// </summary>
		[SuppressMessage("Microsoft.Maintainability", "CA1506:AvoidExcessiveClassCoupling")]
		public static void Register(PlatformType platformType, Type appMapperType)
		{
			// Platform
			DI.Platform = new NetCorePlatform(platformType);
			DI.Registrar.AddSingleton(DI.Platform);

			// Logging
			DI.Registrar.AddSingleton(typeof(ILogger<>), typeof(Logger<>));

			// Mapper
			DI.Registrar.AddSingleton(typeof(IAppMapper), appMapperType);
			DI.Registrar.AddSingleton<IMapper, ObjectMapper>();

			// Web App
			if ((platformType == PlatformType.Web) || (platformType == PlatformType.Azure))
			{
				DI.Registrar.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
				DI.Registrar.AddScoped(s => HttpContextAccessor?.HttpContext);
				DI.Registrar.AddSingleton<IWebAppUrlAccessor>(new NetCoreUrlAccessor());
			}

			// Cryptography
			DI.Registrar.AddSingleton<ICryptoFactory, CryptoFactory>();
			DI.Registrar.AddSingleton(c => Crosscuttings.CryptoFactory.CreateSymmetricCryptographer());
			DI.Registrar.AddSingleton(c => Crosscuttings.CryptoFactory.CreateAsymmetricCryptographer());
			DI.Registrar.AddSingleton(c => Crosscuttings.CryptoFactory.CreateHasher());
			DI.Registrar.AddSingleton<IDataProtectionProvider, CryptoDataProtectionProvider>();

			// Timezone
			if ((platformType == PlatformType.Web) || (platformType == PlatformType.Azure))
			{
				DI.Registrar.AddScoped<WebTimeZoneManager>();
				DI.Registrar.AddScoped<ITimeZoneManager>(sp => DI.Container.GetService<WebTimeZoneManager>());
				DI.Registrar.AddScoped<IWebTimeZoneManager>(sp => DI.Container.GetService<WebTimeZoneManager>());
			}
			else
			{
				DI.Registrar.AddScoped<TimeZoneManager>();
				DI.Registrar.AddScoped<ITimeZoneManager>(sp => DI.Container.GetService<TimeZoneManager>());
			}

			// Localization
			if ((platformType == PlatformType.Web) || (platformType == PlatformType.Azure))
			{
				DI.Registrar.AddScoped<HttpRequestLanguagesProvider>();
				DI.Registrar.AddScoped<IRequestCultureProvider>(sp => DI.Container.GetService<HttpRequestLanguagesProvider>());
				DI.Registrar.AddScoped<IHttpRequestLanguagesProvider>(sp => DI.Container.GetService<HttpRequestLanguagesProvider>());
			}

			// Caching
			DI.Registrar.AddSingleton<ICacheFactory, CacheFactoryBuilder>();
			DI.Registrar.AddSingleton<ICacheManager<object>>(sp => DI.Container.GetService<ICacheFactory>().Create());

			// Validation
			DI.Registrar.AddSingleton<IDefaultValidatorAccessor, FluentDefaultValidatorAccessor>();
			DI.Registrar.AddSingleton<IValidationManager, ValidationManager>();

			// Miscellaneous
			DI.Registrar.AddScoped<IEmailService, SmtpEmailService>();
			DI.Registrar.AddScoped<ISmsService, TwilioSmsService>();
		}

		#endregion
	}
}
