﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

namespace FRT.Web
{
	/// <summary>
	/// Preference storage method
	/// </summary>
	public enum WebTimeZoneExtractionPreferenceMethod
	{
		RequestHeader,
		Cookie,
		QueryString
	}

	/// <summary>
	/// Localization Configuration
	/// </summary>
	public sealed class WebTimeZoneConfig : IInjectableConfig
	{
		private string _serverTimeZone;
		/// <summary>
		/// Name of the language to use for a request if nothing specified is supported
		/// </summary>
		public string ServerTimeZone
		{
			get => _serverTimeZone;
			set => _serverTimeZone = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private string _detectedTimeZoneCookieName = ".DTIMEZONE";
		/// <summary>
		/// Name of the cookie in which user's detected timezone is stored
		/// </summary>
		public string DetectedTimeZoneCookieName
		{
			get => _detectedTimeZoneCookieName;
			set => _detectedTimeZoneCookieName = string.IsNullOrWhiteSpace(value) ? ".DTIMEZONE" : value.Trim();
		}

		private string _detectedTimeZoneRequestHeaderName = "DTIMEZONE";
		/// <summary>
		/// Name of the request header in which user's detected timezone is stored
		/// </summary>
		public string DetectedTimeZoneRequestHeaderName
		{
			get => _detectedTimeZoneRequestHeaderName;
			set => _detectedTimeZoneRequestHeaderName = string.IsNullOrWhiteSpace(value) ? "DTIMEZONE" : value.Trim();
		}

		private string _detectedTimeZoneQueryStringParameterName = "dtz";
		/// <summary>
		/// Name of the query string parameter in which user's detected timezone is stored
		/// </summary>
		public string DetectedTimeZoneQueryStringParameterName
		{
			get => _detectedTimeZoneQueryStringParameterName;
			set => _detectedTimeZoneQueryStringParameterName = string.IsNullOrWhiteSpace(value) ? "dtz" : value.Trim();
		}

		private string _userSelectedTimeZoneCookieName = ".STIMEZONE";
		/// <summary>
		/// Name of the cookie in which user's user selected timezone is stored
		/// </summary>
		public string UserSelectedTimeZoneCookieName
		{
			get => _userSelectedTimeZoneCookieName;
			set => _userSelectedTimeZoneCookieName = string.IsNullOrWhiteSpace(value) ? ".STIMEZONE" : value.Trim();
		}

		private string _userSelectedTimeZoneRequestHeaderName = "STIMEZONE";
		/// <summary>
		/// Name of the request header in which user's user selected timezone is stored
		/// </summary>
		public string UserSelectedTimeZoneRequestHeaderName
		{
			get => _userSelectedTimeZoneRequestHeaderName;
			set => _userSelectedTimeZoneRequestHeaderName = string.IsNullOrWhiteSpace(value) ? "STIMEZONE" : value.Trim();
		}

		private string _userSelectedTimeZoneQueryStringParameterName = "stz";
		/// <summary>
		/// Name of the query string parameter in which user's user selected timezone is stored
		/// </summary>
		public string UserSelectedTimeZoneQueryStringParameterName
		{
			get => _userSelectedTimeZoneQueryStringParameterName;
			set => _userSelectedTimeZoneQueryStringParameterName = string.IsNullOrWhiteSpace(value) ? "stz" : value.Trim();
		}

		private List<WebTimeZoneExtractionPreferenceMethod> _timeZoneExtractionPreference = new List<WebTimeZoneExtractionPreferenceMethod>(new[]
		{
			WebTimeZoneExtractionPreferenceMethod.QueryString, WebTimeZoneExtractionPreferenceMethod.RequestHeader,
			WebTimeZoneExtractionPreferenceMethod.Cookie
		});
		/// <summary>
		/// Methods in which to retrieve the user language preference
		/// </summary>
		[SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		public IList<WebTimeZoneExtractionPreferenceMethod> TimeZoneExtractionPreference
		{
			get => _timeZoneExtractionPreference;
			set
			{
				if (!ReferenceEquals(_timeZoneExtractionPreference, value))
				{
					_timeZoneExtractionPreference = (value ?? new List<WebTimeZoneExtractionPreferenceMethod>(new[]
					{
						WebTimeZoneExtractionPreferenceMethod.QueryString,
						WebTimeZoneExtractionPreferenceMethod.RequestHeader,
						WebTimeZoneExtractionPreferenceMethod.Cookie
					})).ToList();
				}
			}
		}
	}
}
