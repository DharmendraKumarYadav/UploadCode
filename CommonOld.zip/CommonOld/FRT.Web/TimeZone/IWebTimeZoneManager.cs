﻿using System;

namespace FRT.Web
{
	/// <summary>
	/// TimeZone utilities
	/// </summary>
	public interface IWebTimeZoneManager : ITimeZoneManager
	{
		/// <summary>
		/// Retrieves the server's timezone
		/// </summary>
		TimeZoneInfo ServerTimeZone { get; }

		/// <summary>
		/// Retrieves the client's detected timezone
		/// </summary>
		TimeZoneInfo ClientDetectedTimeZone { get; }

		/// <summary>
		/// Retrieves the client's selected timezone
		/// </summary>
		TimeZoneInfo ClientSelectedTimeZone { get; }

		/// <summary>
		/// Effective timezone of the client
		/// </summary>
		TimeZoneInfo ClientEffectiveTimeZone { get; }
	}
}
