﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;

namespace FRT.Web
{
	/// <summary>
	/// TimeZone manager implementation
	/// </summary>
	public class WebTimeZoneManager : TimeZoneManager, IWebTimeZoneManager
	{
		private readonly HttpContext _httpContext;
		private readonly IOptions<WebTimeZoneConfig> _config;
		private readonly Lazy<TimeZoneInfo> _serverTimeZone;
		private readonly Lazy<TimeZoneInfo> _clientDetectedTimeZone;
		private readonly Lazy<TimeZoneInfo> _clientSelectedTimeZone;
		private readonly Lazy<TimeZoneInfo> _clientEffectiveTimeZone;

		/// <summary>
		/// Constructor
		/// </summary>
		public WebTimeZoneManager(HttpContext httpContext, IOptions<WebTimeZoneConfig> config)
		{
			_httpContext = httpContext;
			_config = config;

			_serverTimeZone = new Lazy<TimeZoneInfo>(() => TimeZoneFromIANAId(_config.Value.ServerTimeZone));
			_clientDetectedTimeZone = new Lazy<TimeZoneInfo>(() => GetTimeZoneInfo(_config.Value.DetectedTimeZoneCookieName, _config.Value.DetectedTimeZoneRequestHeaderName, _config.Value.DetectedTimeZoneQueryStringParameterName));
			_clientSelectedTimeZone = new Lazy<TimeZoneInfo>(() => GetTimeZoneInfo(_config.Value.UserSelectedTimeZoneCookieName, _config.Value.UserSelectedTimeZoneRequestHeaderName, _config.Value.UserSelectedTimeZoneQueryStringParameterName));
			_clientEffectiveTimeZone = new Lazy<TimeZoneInfo>(() => ClientSelectedTimeZone ?? ClientDetectedTimeZone ?? ServerTimeZone ?? TimeZoneInfo.Local);
		}

		/// <summary>
		/// Retrieves the server's timezone
		/// </summary>
		public TimeZoneInfo ServerTimeZone => _serverTimeZone.Value;

		/// <summary>
		/// Retrieves the client's detected timezone
		/// </summary>
		public TimeZoneInfo ClientDetectedTimeZone => _clientDetectedTimeZone.Value;

		/// <summary>
		/// Retrieves the client's selected timezone
		/// </summary>
		public TimeZoneInfo ClientSelectedTimeZone => _clientSelectedTimeZone.Value;

		/// <summary>
		/// Effective timezone of the client
		/// </summary>
		public TimeZoneInfo ClientEffectiveTimeZone => _clientEffectiveTimeZone.Value;

		/// <summary>
		/// Gets the time zone for the given IANA timezone id
		/// </summary>
		/// <param name="ianaId">TimeZone Id</param>
		/// <returns>TimeZone</returns>
		public override TimeZoneInfo TimeZoneFromIANAId(string ianaId)
		{
			ianaId = (ianaId ?? string.Empty).Trim();
			if (ianaId.Length == 0)
			{
				return null;
			}

			var tzdbSource = NodaTime.TimeZones.TzdbDateTimeZoneSource.Default;
			var mappings = tzdbSource.WindowsMapping.MapZones;
			var item = mappings.FirstOrDefault(x => x.TzdbIds.Contains(ianaId, StringComparer.OrdinalIgnoreCase));
			string windowsId = null;
			if (item == null)
			{
				// Try other variations
				if (string.Equals(ianaId, "Asia/Kolkata", StringComparison.OrdinalIgnoreCase))
				{
					return TimeZoneFromIANAId("Asia/Calcutta");
				}
				if (string.Equals(ianaId, "Etc/UTC", StringComparison.OrdinalIgnoreCase))
				{
					windowsId = "UTC";
				}
				if (string.Equals(ianaId, "Etc/UCT", StringComparison.OrdinalIgnoreCase))
				{
					windowsId = "UTC";
				}
			}
			else
			{
				windowsId = item.WindowsId;
			}
			if (windowsId == null)
			{
				return null;
			}
			return TimeZoneInfo.FindSystemTimeZoneById(windowsId);
		}

		/// <summary>
		/// Gets IANA timezone id from the given timezone
		/// </summary>
		/// <param name="timeZoneInfo">TimeZone</param>
		/// <returns>IANA Id</returns>
		public override string IANAIdFromTimeZone(TimeZoneInfo timeZoneInfo)
		{
			if (timeZoneInfo == null)
			{
				return null;
			}

			var windowsId = timeZoneInfo.Id;
			if (string.Equals(windowsId, "UTC", StringComparison.OrdinalIgnoreCase))
			{
				return "Etc/UTC";
			}
			var tzdbSource = NodaTime.TimeZones.TzdbDateTimeZoneSource.Default;
			var mappings = tzdbSource.WindowsMapping.MapZones;
			var item = mappings.FirstOrDefault(x => string.Equals(x.WindowsId, windowsId, StringComparison.OrdinalIgnoreCase));
			if (item == null)
			{
				// Try other variations
				if (string.Equals(windowsId, "Asia/Calcutta", StringComparison.OrdinalIgnoreCase))
				{
					return IANAIdFromTimeZone(TimeZoneInfo.FindSystemTimeZoneById("Asia/Kolkata"));
				}
				return null;
			}
			return item.TzdbIds.FirstOrDefault();
		}

		/// <summary>
		/// Gets the timezone info grom the given specifics
		/// </summary>
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
		private TimeZoneInfo GetTimeZoneInfo(string cookieName, string requestHeaderName, string queryStringParameterName)
		{
			cookieName = (cookieName ?? string.Empty).Trim();
			requestHeaderName = (requestHeaderName ?? string.Empty).Trim();
			queryStringParameterName = (queryStringParameterName ?? string.Empty).Trim();

			string timeZoneName = null;
			var httpRequest = _httpContext.Request;
			var detected = _config.Value.TimeZoneExtractionPreference.Any(p =>
			{
				try
				{
					// Dont detect if already detected
					if (timeZoneName != null)
					{
						return false;
					}

					// Detect
					if ((p == WebTimeZoneExtractionPreferenceMethod.Cookie)
						&& (cookieName.Length > 0))
					{
						timeZoneName = httpRequest.Cookies?[cookieName];
					}
					if ((p == WebTimeZoneExtractionPreferenceMethod.QueryString)
						&& (requestHeaderName.Length > 0))
					{
						timeZoneName = httpRequest.Query?[requestHeaderName];
					}
					if ((p == WebTimeZoneExtractionPreferenceMethod.RequestHeader)
						&& (queryStringParameterName.Length > 0))
					{
						timeZoneName = httpRequest.Headers?[queryStringParameterName];
					}

					// Trim
					timeZoneName = !string.IsNullOrWhiteSpace(timeZoneName) ? timeZoneName.Trim() : null;
					return timeZoneName != null;
				}
				// ReSharper disable once EmptyGeneralCatchClause
				catch { }
				return false;
			});

			// Convert
			TimeZoneInfo timeZoneInfo = null;
			if (detected)
			{
				timeZoneInfo = TimeZoneFromIANAId(timeZoneName);
			}
			return timeZoneInfo;
		}
	}
}
