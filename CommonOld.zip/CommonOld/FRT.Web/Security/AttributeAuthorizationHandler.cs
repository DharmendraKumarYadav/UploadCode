﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;

namespace FRT.Web
{
	/// <summary>
	/// Attribute based authorization handler
	/// </summary>
	/// <typeparam name="TRequirement"></typeparam>
	/// <typeparam name="TAttribute"></typeparam>
	public abstract class AttributeAuthorizationHandler<TRequirement, TAttribute> : AuthorizationHandler<TRequirement>
		where TRequirement : IAuthorizationRequirement where TAttribute : Attribute
	{
		/// <summary>
		/// Handle authorization
		/// </summary>
		/// <param name="context">Authorization context</param>
		/// <param name="requirement">Authorize requirement</param>
		protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, TRequirement requirement)
		{
			if (context == null)
			{
				throw new ArgumentNullException(nameof(context));
			}

			var attributes = new List<TAttribute>();
			var action = (context.Resource as AuthorizationFilterContext)?.ActionDescriptor as ControllerActionDescriptor;
			if (action != null)
			{
				attributes.AddRange(GetAttributes(action.ControllerTypeInfo.UnderlyingSystemType));
				attributes.AddRange(GetAttributes(action.MethodInfo));
			}

			return HandleRequirementAsync(context, requirement, attributes);
		}

		/// <summary>
		/// Handle with attributes
		/// </summary>
		/// <param name="context">Authorization context</param>
		/// <param name="requirement">Authorize requirement</param>
		/// <param name="attributes">Attributes</param>
		protected abstract Task HandleRequirementAsync(AuthorizationHandlerContext context, TRequirement requirement, IEnumerable<TAttribute> attributes);

		/// <summary>
		/// Gets attributes
		/// </summary>
		/// <param name="memberInfo">Member info</param>
		/// <returns>Attribute list</returns>
		private static IEnumerable<TAttribute> GetAttributes(MemberInfo memberInfo)
		{
			return memberInfo.GetCustomAttributes(typeof(TAttribute), false).Cast<TAttribute>();
		}

		/// <summary>
		/// Gets attributes
		/// </summary>
		/// <param name="type">Member info</param>
		/// <returns>Attribute list</returns>
		private static IEnumerable<TAttribute> GetAttributes(Type type)
		{
			return type.GetTypeInfo().GetCustomAttributes(typeof(TAttribute), false).Cast<TAttribute>();
		}
	}
}
