﻿namespace FRT
{
	/// <summary>
	/// External Identity Provider name
	/// </summary>
	public enum ExternalIdentityProviderName
	{
		Unknown,
		Google,
		Facebook,
		Microsoft,
		Twitter,
		LinkedIn,
		Yahoo
	}
}
