﻿using System;
using Microsoft.AspNetCore.Authorization;

namespace FRT.Web
{
	/// <summary>
	/// Permission authorize attribute
	/// </summary>
	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
	public sealed class PermissionAttribute : AuthorizeAttribute
	{
		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="permission">Permission</param>
		public PermissionAttribute(string permission)
		{
			Permission = string.IsNullOrWhiteSpace(permission) ? null : permission.Trim();
		}

		/// <summary>
		/// Permission
		/// </summary>
		public string Permission { get; }
	}
}
