﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

namespace FRT
{
	/// <summary>
	/// Security configuration
	/// </summary>
	public sealed class WebSecurityConfig : IInjectableConfig
	{
		private CookiesConfig _cookies = new CookiesConfig();
		/// <summary>
		/// Cookies configuration
		/// </summary>
		public CookiesConfig Cookies
		{
			get => _cookies;
			set => _cookies = value ?? new CookiesConfig();
		}

		private RecaptchaConfig _recaptcha = new RecaptchaConfig();
		/// <summary>
		/// Recaptcha configuration
		/// </summary>
		public RecaptchaConfig Recaptcha
		{
			get => _recaptcha;
			set => _recaptcha = value ?? new RecaptchaConfig();
		}

		private ExternalIdentityProvidersConfig _externalIdentityProviders = new ExternalIdentityProvidersConfig();
		/// <summary>
		/// External Identity Providers
		/// </summary>
		public ExternalIdentityProvidersConfig ExternalIdentityProviders
		{
			get => _externalIdentityProviders;
			set => _externalIdentityProviders = value ?? new ExternalIdentityProvidersConfig();
		}

		private int _securityStampRevalidationPeriodSeconds = (int) TimeSpan.FromMinutes(15.0).TotalSeconds;
		/// <summary>
		/// Period at which the security timestamps are re-validated
		/// </summary>
		public int SecurityStampRevalidationPeriodSeconds
		{
			get => _securityStampRevalidationPeriodSeconds;
			set => _securityStampRevalidationPeriodSeconds = (value <= 0) ? (int)TimeSpan.FromMinutes(15.0).TotalSeconds : value;
		}
	}

	/// <summary>
	/// Cookies configuration
	/// </summary>
	public sealed class CookiesConfig : IInjectableConfig
	{
		private string _applicationCookieName;
		/// <summary>
		/// Name of the application cookie
		/// </summary>
		public string ApplicationCookieName
		{
			get => _applicationCookieName;
			set => _applicationCookieName = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private string _externalCookieName;
		/// <summary>
		/// Name of the external cookie
		/// </summary>
		public string ExternalCookieName
		{
			get => _externalCookieName;
			set => _externalCookieName = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private int _expiryDuration;
		/// <summary>
		/// Expiry duration for the cookie
		/// </summary>
		public int ExpiryDuration
		{
			get => _expiryDuration;
			set => _expiryDuration = Math.Max(1, value);
		}
	}

	/// <summary>
	/// Recaptcha
	/// </summary>
	public sealed class RecaptchaConfig : IInjectableConfig
	{
		private string _siteKey;
		/// <summary>
		/// Site key
		/// </summary>
		public string SiteKey
		{
			get => _siteKey;
			set => _siteKey = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private string _secretKey;
		/// <summary>
		/// Secret key
		/// </summary>
		public string SecretKey
		{
			get => _secretKey;
			set => _secretKey = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private List<string> _disabledContexts = new List<string>();
		/// <summary>
		/// Whether to disable recaptcha for sign-in page
		/// </summary>
		[SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		public ICollection<string> DisabledContexts
		{
			get => _disabledContexts;
			set => _disabledContexts = (value ?? new List<string>()).Where(r => !string.IsNullOrWhiteSpace(r)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
		}

		/// <summary>
		/// Whether a specified context is enabled
		/// </summary>
		/// <param name="context">Context name</param>
		public bool IsContextEnabled(string context)
		{
			context = string.IsNullOrWhiteSpace(context) ? null : context.Trim();
			return !DisabledContexts.Contains("*", StringComparer.Ordinal)
				&& ((context == null) || !DisabledContexts.Contains(context, StringComparer.OrdinalIgnoreCase));
		}
	}

	/// <summary>
	/// ExternalIdentityProviderConfig
	/// </summary>
	public sealed class ExternalIdentityProvidersConfig : IInjectableConfig
	{
		/// <summary>
		/// Whether to disable external authentication providers
		/// </summary>
		public bool Disable
		{
			get;
			set;
		}

		private ExternalIdentityProviderConfig _google = new ExternalIdentityProviderConfig() { ProviderName = ExternalIdentityProviderName.Google };
		/// <summary>
		/// Google
		/// </summary>
		public ExternalIdentityProviderConfig Google
		{
			get => _google;
			set
			{
				_google = (value ?? new ExternalIdentityProviderConfig());
				_google.ProviderName = ExternalIdentityProviderName.Google;
			}
		}

		private ExternalIdentityProviderConfig _facebook = new ExternalIdentityProviderConfig() { ProviderName = ExternalIdentityProviderName.Facebook };
		/// <summary>
		/// Facebook
		/// </summary>
		public ExternalIdentityProviderConfig Facebook
		{
			get => _facebook;
			set
			{
				_facebook = (value ?? new ExternalIdentityProviderConfig());
				_facebook.ProviderName = ExternalIdentityProviderName.Facebook;
			}
		}

		/// <summary>
		/// All providers
		/// </summary>
		[SuppressMessage("Microsoft.Performance", "CA1819:PropertiesShouldNotReturnArrays")]
		public ExternalIdentityProviderConfig[] All => new[] { Google, Facebook };
	}

	/// <summary>
	/// External Identity Provider
	/// </summary>
	public sealed class ExternalIdentityProviderConfig
	{
		/// <summary>
		/// Whether to disable external authentication providers
		/// </summary>
		public bool Disable
		{
			get;
			set;
		}

		/// <summary>
		/// Whether this provider config is valid
		/// </summary>
		public bool IsValid => !string.IsNullOrWhiteSpace(ClientId) && !string.IsNullOrWhiteSpace(ClientSecret);

		/// <summary>
		/// Provider name
		/// </summary>
		public ExternalIdentityProviderName ProviderName
		{
			get;
			set;
		}

		/// <summary>
		/// Name
		/// </summary>
		public string Name => ProviderName.ToString();

		private string _clientId;
		/// <summary>
		/// Client Id
		/// </summary>
		public string ClientId
		{
			get => _clientId;
			set => _clientId = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private string _clientSecret;
		/// <summary>
		/// Client Secret
		/// </summary>
		public string ClientSecret
		{
			get => _clientSecret;
			set => _clientSecret = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}
	}
}
