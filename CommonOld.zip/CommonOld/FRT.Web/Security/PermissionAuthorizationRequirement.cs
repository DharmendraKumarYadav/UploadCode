﻿using Microsoft.AspNetCore.Authorization;

namespace FRT.Web
{
	/// <summary>
	/// Permission authorization
	/// </summary>
	public sealed class PermissionAuthorizationRequirement : IAuthorizationRequirement
	{
	}
}
