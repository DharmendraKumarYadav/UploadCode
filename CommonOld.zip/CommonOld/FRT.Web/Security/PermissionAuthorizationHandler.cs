﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.DependencyInjection;

namespace FRT.Web
{
	/// <summary>
	/// Authorization handler
	/// </summary>
	public sealed class PermissionAuthorizationHandler : AttributeAuthorizationHandler<PermissionAuthorizationRequirement, PermissionAttribute>
	{
		public const string PermissionClaimType = "appPermission";

		/// <summary>
		/// Handle with attributes
		/// </summary>
		/// <param name="context">Authorization context</param>
		/// <param name="requirement">Authorize requirement</param>
		/// <param name="attributes">Attributes</param>
		protected override async Task HandleRequirementAsync(AuthorizationHandlerContext context, PermissionAuthorizationRequirement requirement,
			IEnumerable<PermissionAttribute> attributes)
		{
			if (context == null)
			{
				throw new ArgumentNullException(nameof(context));
			}
			if (requirement == null)
			{
				throw new ArgumentNullException(nameof(requirement));
			}
			attributes = (attributes ?? new PermissionAttribute[0]).Where(p => p != null).ToArray();

			// Check all permissions
			foreach (var att in attributes)
			{
				if (!await AuthorizeAsync(context.User, att))
				{
					return;
				}
			}

			// Success
			context.Succeed(requirement);
		}

		/// <summary>
		/// Authorize
		/// </summary>
		private async Task<bool> AuthorizeAsync(ClaimsPrincipal user, PermissionAttribute permission)
		{
			return await DI.Container.GetRequiredService<ISuperAdminUserChecker>().IsSuperAdminAsync(user) || user.HasClaim(PermissionClaimType, permission.Permission);
		}
	}
}
