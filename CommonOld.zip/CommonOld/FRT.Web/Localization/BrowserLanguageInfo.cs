﻿using System;
using System.Globalization;
using FRT.Localization;

namespace FRT.Web.Localization
{
	/// <summary>
	/// Language information
	/// </summary>
	public sealed class BrowserLanguageInfo : LanguageInfo
	{
		/// <summary>
		/// Creates an instance of this type
		/// </summary>
		/// <param name="code">Two letter ISO code of the language</param>
		/// <param name="weightage">Weghtage</param>
		/// <param name="name">Display name of the language in English</param>
		public BrowserLanguageInfo(string code, double weightage, string name = null)
			: base(code, name)
		{
			Weightage = weightage;
		}

		/// <summary>
		/// Neutral language
		/// </summary>
		public new BrowserLanguageInfo NeutralLanguage
		{
			get
			{
				if (RegionCode != null)
				{
					return new BrowserLanguageInfo(NeutralCode, Weightage);
				}
				return this;
			}
		}

		private double _weightage;
		/// <summary>
		/// Weightage
		/// </summary>
		public double Weightage
		{
			get => _weightage; private set => _weightage = Math.Max(0.0, Math.Min(value, 1.0));
		}

		#region Overrides of Object
		/// <summary>
		/// Determines whether the specified object is equal to the current object.
		/// </summary>
		/// <returns>
		/// true if the specified object  is equal to the current object; otherwise, false.
		/// </returns>
		/// <param name="obj">The object to compare with the current object. </param>
		public override bool Equals(object obj)
		{
			var lang = obj as BrowserLanguageInfo;
			if (lang == null)
			{
				return false;
			}
			return base.Equals(obj) && (Math.Abs(Weightage - lang.Weightage) < 0.01);
		}

		/// <summary>
		/// Returns a string that represents the current object.
		/// </summary>
		/// <returns>
		/// A string that represents the current object.
		/// </returns>
		public override string ToString()
		{
			return string.Format(CultureInfo.InvariantCulture, "{0};q={1}", base.ToString(), Weightage);
		}

		/// <summary>
		/// Serves as the default hash function.
		/// </summary>
		/// <returns>
		/// A hash code for the current object.
		/// </returns>
		public override int GetHashCode()
		{
			return ToString().GetHashCode();
		}
		#endregion
	}
}
