﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using FRT.Localization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Localization;
using Microsoft.Extensions.Options;

namespace FRT.Web.Localization
{
	/// <summary>
	/// IRequestLanguageProvider implementation
	/// </summary>
	public sealed class HttpRequestLanguagesProvider : IHttpRequestLanguagesProvider, IRequestCultureProvider
	{
		private const string _specifiedLanguagesContextKey = "FRT.Localization.HttpRequestLanguagesProvider.SpecifiedLanguages";
		private static readonly HashSet<string> _knownCultureNames = CultureInfoList.KnownCultureNames;
		private static readonly Regex _languageCodeRegex = new Regex(@"^[a-z]{2}(\-[a-z]{2,4})?$", RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.Singleline);
		private readonly IOptions<WebLocalizationConfig> _config;

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="config">Configuration</param>
		public HttpRequestLanguagesProvider(IOptions<WebLocalizationConfig> config)
		{
			_config = config;
		}

		/// <summary>
		/// Current request's browser languages
		/// </summary>
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
		public BrowserLanguageInfo[] SpecifiedLanguages
		{
			get
			{
				// Get context
				var httpContext = WebCrosscuttings.HttpContext;
				if (httpContext != null)
				{
					var savedData = httpContext.Items[_specifiedLanguagesContextKey] as BrowserLanguageInfo[];
					if (savedData != null)
					{
						return savedData;
					}
				}
				else
				{
					return null;
				}

				// Request
				var httpRequest = httpContext.Request;
				if (httpRequest == null)
				{
					return null;
				}

				// Check user preference
				var allLanguages = new List<BrowserLanguageInfo>();
				_config.Value.UserLanguageExtractionPreference.ForEach(p =>
				{
					BrowserLanguageInfo lang = null;
					try
					{
						if ((p == WebUserLocalizationPreferenceMethod.Cookie)
							&& (_config.Value.UserLanguageCookieName != null))
						{
							lang = GetBrowserLanguage(httpRequest.Cookies?[_config.Value.UserLanguageCookieName]);
						}
						if ((p == WebUserLocalizationPreferenceMethod.QueryString)
							&& (_config.Value.UserLanguageQueryParameterName != null))
						{
							lang = GetBrowserLanguage(httpRequest.Query?[_config.Value.UserLanguageQueryParameterName]);
						}
						if ((p == WebUserLocalizationPreferenceMethod.RequestHeader)
							&& (_config.Value.UserLanguageRequestHeaderName != null))
						{
							lang = GetBrowserLanguage(httpRequest.Headers?[_config.Value.UserLanguageRequestHeaderName]);
						}
					}
					// ReSharper disable once EmptyGeneralCatchClause
					catch { }
					if (lang != null)
					{
						// ReSharper disable once AccessToModifiedClosure
						allLanguages.Add(lang);
					}
				});

				// Add default browser acceptable languages
				allLanguages.AddRange(httpRequest.GetUserLanguages());

				// Could not decide
				var allLangArr = allLanguages.ToArray();
				httpContext.Items[_specifiedLanguagesContextKey] = allLangArr;
				return allLangArr;
			}
		}

		#region Implementation of IRequestCultureProvider
		/// <summary>
		/// Implements the provider to determine the culture of the given request.
		/// </summary>
		/// <param name="httpContext">The <see cref="T:Microsoft.AspNet.Http.HttpContext" /> for the request.</param>
		/// <returns>
		/// The determined <see cref="T:Microsoft.AspNet.Localization.ProviderCultureResult" />.
		/// Returns <c>null</c> if the provider couldn't determine a <see cref="T:Microsoft.AspNet.Localization.ProviderCultureResult" />.
		/// </returns>
		public Task<ProviderCultureResult> DetermineProviderCultureResult(HttpContext httpContext)
		{
			return Task.Factory.StartNew(() =>
			{
				var httpRequest = httpContext?.Request;
				if (httpRequest == null)
				{
					return null;
				}

				// Check user preference
				var supportedCultures = _config.Value.SupportedLanguages
					.Where(l => _knownCultureNames.Contains(l))
					.Select(l => new CultureInfo(l))
					.ToArray();
				var allLanguages = SpecifiedLanguages;

				// Support checker
				// ReSharper disable once ConvertToLocalFunction
				Func<BrowserLanguageInfo, bool> isSupported = b =>
				{
					if (supportedCultures.Any(c => string.Equals(c.Name, b.Code, StringComparison.OrdinalIgnoreCase)))
					{
						return true;
					}
					return false;
				};

				// Check if we can decide on the preferred languages
				BrowserLanguageInfo selectedLanguage = allLanguages.FirstOrDefault(l => isSupported(l));
				if (selectedLanguage != null)
				{
					return new ProviderCultureResult(new CultureInfo(selectedLanguage.Code).Name);
				}

				// Could not decide
				return new ProviderCultureResult(new CultureInfo(_config.Value.DefaultLanguage).Name);
			});
		}
		#endregion

		#region Helpers
		/// <summary>
		/// Gets a browser language instance from the specified code
		/// </summary>
		/// <param name="langCode"></param>
		/// <returns></returns>
		private static BrowserLanguageInfo GetBrowserLanguage(string langCode)
		{
			if (string.IsNullOrWhiteSpace(langCode))
			{
				return null;
			}
			langCode = langCode.Trim();

			// Check
			if (_languageCodeRegex.IsMatch(langCode)
				&& _knownCultureNames.Contains(langCode, StringComparer.OrdinalIgnoreCase))
			{
				var cultureInfo = new CultureInfo(langCode);
				return new BrowserLanguageInfo(cultureInfo.Name, 1.0D, cultureInfo.DisplayName);
			}
			return null;
		}
		#endregion
	}
}