﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

namespace FRT.Web.Localization
{
	/// <summary>
	/// Preference storage method
	/// </summary>
	public enum WebUserLocalizationPreferenceMethod
	{
		RequestHeader,
		Cookie,
		QueryString
	}

	/// <summary>
	/// Localization Configuration
	/// </summary>
	public sealed class WebLocalizationConfig : IInjectableConfig
	{
		private string _defaultLanguage;
		/// <summary>
		/// Name of the language to use for a request if nothing specified is supported
		/// </summary>
		public string DefaultLanguage
		{
			get => _defaultLanguage;
			set => _defaultLanguage = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private List<string> _supportedLanguages = new List<string>();
		/// <summary>
		/// The language codes to be supported.
		/// If not specified, all languages present in the resources path will be supported
		/// </summary>
		[SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		public IList<string> SupportedLanguages
		{
			get => _supportedLanguages;
			set
			{
				if (!ReferenceEquals(_supportedLanguages, value))
				{
					_supportedLanguages = (value ?? new List<string>()).ToList();
				}
			}
		}

		private string _userLanguageCookieName = ".USERLANG";
		/// <summary>
		/// Name of the cookie in which user's language preference is stored
		/// </summary>
		public string UserLanguageCookieName
		{
			get => _userLanguageCookieName;
			set => _userLanguageCookieName = string.IsNullOrWhiteSpace(value) ? ".USERLANG" : value.Trim();
		}

		private string _userLanguageQueryParameterName = "lang";
		/// <summary>
		/// Name of the query parameter in which user's language preference is stored
		/// </summary>
		public string UserLanguageQueryParameterName
		{
			get => _userLanguageQueryParameterName;
			set => _userLanguageQueryParameterName = string.IsNullOrWhiteSpace(value) ? "lang" : value.Trim();
		}

		private string _userLanguageRequestHeaderName = "USERLANGUAGE";
		/// <summary>
		/// Name of the request header in which user's language preference is stored
		/// </summary>
		public string UserLanguageRequestHeaderName
		{
			get => _userLanguageRequestHeaderName;
			set => _userLanguageRequestHeaderName = string.IsNullOrWhiteSpace(value) ? "USERLANGUAGE" : value.Trim();
		}

		private List<WebUserLocalizationPreferenceMethod> _userLanguageExtractionPreference = new List<WebUserLocalizationPreferenceMethod>(new[]
		{
			WebUserLocalizationPreferenceMethod.QueryString,
			WebUserLocalizationPreferenceMethod.RequestHeader,
			WebUserLocalizationPreferenceMethod.Cookie
		});
		/// <summary>
		/// Methods in which to retrieve the user language preference
		/// </summary>
		[SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		public IList<WebUserLocalizationPreferenceMethod> UserLanguageExtractionPreference
		{
			get => _userLanguageExtractionPreference;
			set
			{
				if (!ReferenceEquals(_userLanguageExtractionPreference, value))
				{
					_userLanguageExtractionPreference = (value ?? new List<WebUserLocalizationPreferenceMethod>(new[]
					{
						WebUserLocalizationPreferenceMethod.QueryString,
						WebUserLocalizationPreferenceMethod.RequestHeader,
						WebUserLocalizationPreferenceMethod.Cookie
					})).ToList();
				}
			}
		}
	}
}
