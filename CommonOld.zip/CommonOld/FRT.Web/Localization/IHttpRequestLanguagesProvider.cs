﻿using System.Diagnostics.CodeAnalysis;

namespace FRT.Web.Localization
{
	/// <summary>
	/// Reports the user's browser language
	/// </summary>
	public interface IHttpRequestLanguagesProvider
	{
		/// <summary>
		/// Current request's browser's specified languages
		/// </summary>
		[SuppressMessage("Microsoft.Performance", "CA1819:PropertiesShouldNotReturnArrays")]
		BrowserLanguageInfo[] SpecifiedLanguages { get; }
	}
}
