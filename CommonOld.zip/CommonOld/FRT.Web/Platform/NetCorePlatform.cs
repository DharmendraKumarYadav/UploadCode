﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;

namespace FRT
{
	/// <summary>
	/// IPlatform implementation
	/// </summary>
	internal sealed class NetCorePlatform : IPlatform
	{
		/// <summary>
		/// Constructor
		/// </summary>
		public NetCorePlatform(PlatformType platformType)
		{
			Type = platformType;
		}

		/// <inheritdoc />
		public PlatformType Type { get; }

		/// <summary>
		/// Returns the names of all assemblies in the application folder
		/// </summary>
		public Assembly[] GetAllAssemblies()
		{
			return AppDomainUtil.GetAssemblies();
		}

		/// <summary>
		/// Gets the referenced assembly names for the specified assembly
		/// </summary>
		/// <param name="assembly">Assembly</param>
		/// <returns>Referenced assembly names</returns>
		public AssemblyName[] GetReferencedAssemblies(Assembly assembly)
		{
			return assembly?.GetReferencedAssemblies();
		}

		/// <summary>
		/// Returns the file path of the assembly
		/// </summary>
		/// <param name="assembly">Assembly</param>
		/// <returns>Assembly file path</returns>
		public string GetAssemblyFilePath(Assembly assembly)
		{
			if (assembly == null)
			{
				return null;
			}

			string assemblyCodeBase = assembly.CodeBase;
			if (assemblyCodeBase.StartsWith("file:", StringComparison.OrdinalIgnoreCase))
			{
				assemblyCodeBase = assemblyCodeBase.Substring(5).Trim('/', '\\');
			}
			return assemblyCodeBase.Replace('/', '\\');
		}

		/// <inheritdoc />
		public Regex CreateRegex(string pattern)
		{
			return new Regex(pattern);
		}

		/// <inheritdoc />
		public Regex CreateRegex(string pattern, RegexOptions options, bool compiled = false)
		{
			return new Regex(pattern, options | (compiled ? RegexOptions.Compiled : RegexOptions.None));
		}

		/// <inheritdoc />
		public Regex CreateRegex(string pattern, RegexOptions options, bool compiled, TimeSpan matchTimeout)
		{
			return new Regex(pattern, options | (compiled ? RegexOptions.Compiled : RegexOptions.None), matchTimeout);
		}

		/// <inheritdoc />
		public StackFrameModel[] GetStackFramesFromException(Exception exception)
		{
			if (exception != null)
			{
				// ReSharper disable once AssignNullToNotNullAttribute
				return new StackTrace(exception, true).GetFrames().Select(f => new StackFrameModel()
				{
					Method = f.GetMethod(),
					Offset = f.GetILOffset(),
					File = f.GetFileName(),
					Line = f.GetFileLineNumber(),
					Column = f.GetFileColumnNumber()
				}).ToArray();
			}
			return null;
		}
	}
}
