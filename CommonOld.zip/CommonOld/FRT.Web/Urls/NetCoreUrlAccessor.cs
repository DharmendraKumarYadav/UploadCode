﻿using System;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;

namespace FRT.Web
{
	/// <summary>
	/// IUrlResolutionBaseUrlProvider implementation
	/// </summary>
	internal sealed class NetCoreUrlAccessor : IWebAppUrlAccessor
	{
		private readonly Uri _applicationBaseUri;

		/// <summary>
		/// Constructor
		/// </summary>
		public NetCoreUrlAccessor()
		{
			var hostUrl = (Environment.GetEnvironmentVariable("ASPNETCORE_URLS") ?? string.Empty).Trim();
			_applicationBaseUri =(hostUrl.Length > 0) ? new Uri(hostUrl, UriKind.Absolute) : null;
		}

		/// <summary>
		/// Base Uri of the application root
		/// </summary>
		public Uri ApplicationBaseUri => _applicationBaseUri;

		/// <summary>
		/// Request Uri
		/// </summary>
		public Uri RequestUri
		{
			get
			{
				var url = DI.Container.GetService<IHttpContextAccessor>()?.HttpContext.Request.GetEncodedUrl();
				if (url != null)
				{
					return new Uri(url, UriKind.Absolute);
				}
				return null;
			}
		}
	}
}
