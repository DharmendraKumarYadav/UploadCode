﻿using System;
using System.Linq;
using System.Text;
using FRT.Properties;
using Microsoft.AspNetCore.DataProtection;
using FRT.Web.Properties;

namespace FRT.Cryptography
{
	/// <summary>
	/// Data protector based on crypto provider
	/// </summary>
	internal sealed class CryptoDataProtectionProvider : IDataProtectionProvider
	{
		private const string _defaultPurpose = "FRT.Cryptography.CryptoDataProtectionProvider.DefaultPurpose";

		#region Inner Types
		/// <summary>
		/// Protector
		/// </summary>
		private sealed class CryptoDataProtector : IDataProtector
		{
			private readonly CryptoDataProtectionProvider _provider;
			private readonly byte[] _purpose;

			#region Construction
			/// <summary>
			/// Constructor
			/// </summary>
			/// <param name="provider">Provider</param>
			/// <param name="purpose">Purpose</param>
			public CryptoDataProtector(CryptoDataProtectionProvider provider, string purpose = null)
			{
				_provider = provider;
				_purpose = Encoding.UTF8.GetBytes(purpose ?? _defaultPurpose);
			}
			#endregion

			#region Implementation of IDataProtectionProvider
			/// <summary>
			/// Creates an <see cref="T:Microsoft.AspNet.DataProtection.IDataProtector"/> given a purpose.
			/// </summary>
			/// <param name="purpose">The purpose to be assigned to the newly-created <see cref="T:Microsoft.AspNet.DataProtection.IDataProtector"/>.
			///             </param>
			/// <returns>
			/// An IDataProtector tied to the provided purpose.
			/// </returns>
			/// <remarks>
			/// The <paramref name="purpose"/> parameter must be unique for the intended use case; two
			///             different <see cref="T:Microsoft.AspNet.DataProtection.IDataProtector"/> instances created with two different <paramref name="purpose"/>
			///             values will not be able to decipher each other's payloads. The <paramref name="purpose"/> parameter
			///             value is not intended to be kept secret.
			/// </remarks>
			public IDataProtector CreateProtector(string purpose)
			{
				return _provider.CreateProtector(purpose);
			}
			#endregion

			#region Implementation of IDataProtector
			/// <summary>
			/// Cryptographically protects a piece of plaintext data.
			/// </summary>
			/// <param name="plainText">The plaintext data to protect.</param>
			/// <returns>
			/// The protected form of the plaintext data.
			/// </returns>
			public byte[] Protect(byte[] plainText)
			{
				if (plainText == null)
				{
					throw new ArgumentNullException(nameof(plainText));
				}

				// Create a combined buffer
				var combinedBuffer = new byte[_purpose.Length + plainText.Length];
				Array.Copy(_purpose, 0, combinedBuffer, 0, _purpose.Length);
				Array.Copy(plainText, 0, combinedBuffer, _purpose.Length, plainText.Length);

				// Encrypt
				return Crosscuttings.SymmetricCryptographer.EncryptData(combinedBuffer);
			}

			/// <summary>
			/// Cryptographically unprotects a piece of protected data.
			/// </summary>
			/// <param name="protectedData">The protected data to unprotect.</param>
			/// <returns>
			/// The plaintext form of the protected data.
			/// </returns>
			/// <exception cref="T:System.Security.Cryptography.CryptographicException">Thrown if the protected data is invalid or malformed.
			///             </exception>
			public byte[] Unprotect(byte[] protectedData)
			{
				if (protectedData == null)
				{
					throw new ArgumentNullException(nameof(protectedData));
				}

				// Decrypt
				var combinedBuffer = Crosscuttings.SymmetricCryptographer.DecryptData(protectedData);
				if (combinedBuffer.Length >= _purpose.Length)
				{
					var purposeBuffer = new byte[_purpose.Length];
					Array.Copy(combinedBuffer, 0, purposeBuffer, 0, purposeBuffer.Length);
					if (purposeBuffer.SequenceEqual(_purpose))
					{
						var dataBuffer = new byte[combinedBuffer.Length - _purpose.Length];
						Array.Copy(combinedBuffer, _purpose.Length, dataBuffer, 0, dataBuffer.Length);
						return dataBuffer;
					}
				}

				// Throw
				throw new ArgumentException(LocalResources.S_DecryptionFailed, nameof(protectedData));
			}
			#endregion
		}
		#endregion

		#region Implementation of IDataProtectionProvider
		/// <summary>
		/// Creates an <see cref="T:Microsoft.AspNet.DataProtection.IDataProtector"/> given a purpose.
		/// </summary>
		/// <param name="purpose">The purpose to be assigned to the newly-created <see cref="T:Microsoft.AspNet.DataProtection.IDataProtector"/>.
		///             </param>
		/// <returns>
		/// An IDataProtector tied to the provided purpose.
		/// </returns>
		/// <remarks>
		/// The <paramref name="purpose"/> parameter must be unique for the intended use case; two
		///             different <see cref="T:Microsoft.AspNet.DataProtection.IDataProtector"/> instances created with two different <paramref name="purpose"/>
		///             values will not be able to decipher each other's payloads. The <paramref name="purpose"/> parameter
		///             value is not intended to be kept secret.
		/// </remarks>
		public IDataProtector CreateProtector(string purpose)
		{
			return new CryptoDataProtector(this, purpose);
		}
		#endregion
	}
}
