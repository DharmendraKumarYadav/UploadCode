﻿using System;
using System.Globalization;
using System.Text;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Razor.TagHelpers;

namespace FRT.Web.TagHelpers
{
	/// <summary>
	/// Recaptcha enabled submit
	/// </summary>
	[HtmlTargetElement("form", TagStructure = TagStructure.NormalOrSelfClosing)]
	public class RecaptchaTagHelper : TagHelper
	{
		private const string RenderApiScriptContextKey = "RecaptchaTagHelperApiScript";
		private const string ApiScriptUrl = "https://www.google.com/recaptcha/api.js";

		/// <summary>
		/// jQuery selector for the form to be submitted
		/// </summary>
		[HtmlAttributeName("recaptcha-enable")]
		public bool RecaptchaEnable
		{
			get;
			set;
		}

		private string _recaptchaOnSuccess;
		/// <summary>
		/// Javascript to be executed on success
		/// </summary>
		[HtmlAttributeName("recaptcha-on-success")]
		public string RecaptchaOnSuccess
		{
			get => _recaptchaOnSuccess;
			set => _recaptchaOnSuccess = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		/// <summary>
		/// Minimum value in order to run first of all
		/// </summary>
		public override int Order => int.MinValue;

		/// <inheritdoc />
		public override void Process(TagHelperContext context, TagHelperOutput output)
		{
			// Check if not enabled
			if (!RecaptchaEnable)
			{
				return;
			}
			if (output == null)
			{
				throw new ArgumentNullException(nameof(output));
			}

			// Config
			var recaptchaConfig = DI.Container.GetService<RecaptchaConfig>();
			var captchaId = "recaptcha_" + Guid.NewGuid().ToString("N");
			var divId = "div_" + captchaId;
			var callbackFnName = captchaId + "_Callback";

			// Id
			var formId = output.Attributes["id"]?.Value?.ToString();
			formId = string.IsNullOrWhiteSpace(formId) ? ("form_" + captchaId) : formId.Trim();
			output.Attributes.SetAttribute("id", formId);

			// Pre-Content - Insert an invisible div
			// ReSharper disable once MustUseReturnValue
			output.PreContent.SetHtmlContent(GetRecaptchaDiv(recaptchaConfig, divId, callbackFnName));

			// Post-Element - Form Submit Hook
			var sbPostElementBuffer = new StringBuilder();
			sbPostElementBuffer.AppendFormat(CultureInfo.InvariantCulture, "<script type=\"text/javascript\">{0}", Environment.NewLine);
			sbPostElementBuffer.AppendFormat(CultureInfo.InvariantCulture, "$(function() {{ $('#{0}').submit(function(e) {{{1}", formId, Environment.NewLine);
			sbPostElementBuffer.AppendFormat(CultureInfo.InvariantCulture, "if(!$('#{0}').data('g-recaptcha-submit')) {{ e.preventDefault(); grecaptcha.execute($('.g-recaptcha').index($('#{1}'))); return false; }} {2}", formId, divId, Environment.NewLine);
			sbPostElementBuffer.AppendFormat(CultureInfo.InvariantCulture, "else {{ $('#{0}').data('g-recaptcha-submit', false); }}{1}", formId, Environment.NewLine);
			sbPostElementBuffer.AppendFormat(CultureInfo.InvariantCulture, "}}); }});{0}", Environment.NewLine);
			sbPostElementBuffer.AppendFormat(CultureInfo.InvariantCulture, "</script>{0}", Environment.NewLine);

			// Post-Element - Callback
			sbPostElementBuffer.AppendFormat(CultureInfo.InvariantCulture, "<script type=\"text/javascript\">{0}", Environment.NewLine);
			sbPostElementBuffer.AppendFormat(CultureInfo.InvariantCulture, "function {0}() {{{1}", callbackFnName, Environment.NewLine);
			if (_recaptchaOnSuccess != null)
			{
				sbPostElementBuffer.AppendFormat(CultureInfo.InvariantCulture, "if(eval('{0}') === false) {{ return; }}", _recaptchaOnSuccess.Replace("'", "\\'"), Environment.NewLine);
			}
			sbPostElementBuffer.AppendFormat(CultureInfo.InvariantCulture, "$('#{0}').data('g-recaptcha-submit', true);{1}", formId, Environment.NewLine);
			sbPostElementBuffer.AppendFormat(CultureInfo.InvariantCulture, "$('#{0}').submit();{1}", formId, Environment.NewLine);
			sbPostElementBuffer.AppendFormat(CultureInfo.InvariantCulture, "}}{0}", Environment.NewLine);
			sbPostElementBuffer.AppendFormat(CultureInfo.InvariantCulture, "</script>{0}", Environment.NewLine);

			// Post-Element - Api Js files
			var httpContext = WebCrosscuttings.HttpContext;
			httpContext.Items[RenderApiScriptContextKey] = true;

			// Set Post Content
			// ReSharper disable once MustUseReturnValue
			output.PostElement.SetHtmlContent(sbPostElementBuffer.ToString());
		}

		private static string GetRecaptchaDiv(RecaptchaConfig config, string divId, string callbackFnName)
		{
			return ((FormattableString)$"<div id=\"{divId}\" class=\"g-recaptcha\" data-sitekey=\"{config.SiteKey}\" data-callback=\"{callbackFnName}\" data-size=\"invisible\"></div>")
				.ToString(CultureInfo.InvariantCulture);
		}

		/// <summary>
		/// Renders recaptcha api script if required
		/// </summary>
		/// <param name="htmlHelper"></param>
		/// <returns></returns>
		public static HtmlString RenderApiScript(IHtmlHelper htmlHelper)
		{
			if (htmlHelper == null)
			{
				throw new ArgumentNullException(nameof(htmlHelper));
			}
			var scriptFlag = htmlHelper.ViewContext?.HttpContext?.Items?[RenderApiScriptContextKey];
			if ((scriptFlag != null) && (bool)scriptFlag)
			{
				htmlHelper.ViewContext.HttpContext.Items[RenderApiScriptContextKey] = false;
				return new HtmlString(string.Format(CultureInfo.InvariantCulture, "<script type=\"text/javascript\" src=\"{0}\" async defer></script>{1}", ApiScriptUrl, Environment.NewLine));
			}
			return HtmlString.Empty;
		}
	}
}
