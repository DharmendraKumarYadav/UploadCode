﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using FRT.Properties;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using FRT.Web.Properties;

namespace FRT.Web
{
	/// <summary>
	/// Validation filter
	/// </summary>
	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
	public sealed class RecaptchaAttribute : ActionFilterAttribute
	{
		private const string _responseVerifyUrl = "https://www.google.com/recaptcha/api/siteverify";
		private readonly Lazy<ILogger<RecaptchaAttribute>> _logger;
		private readonly Lazy<RecaptchaConfig> _config;
		private readonly string _context;

		#region Inner Type

		// ReSharper disable once ClassNeverInstantiated.Local
		[SuppressMessage("Microsoft.Performance", "CA1812:AvoidUninstantiatedInternalClasses")]
		private class VerifyResponse
		{
			// ReSharper disable once UnusedMember.Local
			// ReSharper disable once AutoPropertyCanBeMadeGetOnly.Local
			public bool Success { get; set; } = false;
		}

		#endregion

		#region Constructor
		/// <summary>
		/// Constructor
		/// </summary>
		public RecaptchaAttribute(string context = null)
		{
			_logger = new Lazy<ILogger<RecaptchaAttribute>>(Crosscuttings.GetTypedLogger<RecaptchaAttribute>);
			_config = new Lazy<RecaptchaConfig>(DI.Container.GetService<RecaptchaConfig>);
			_context = string.IsNullOrWhiteSpace(context) ? null : context.Trim();
		}
		#endregion

		#region Properties

		/// <summary>
		/// Context
		/// </summary>
		public string Context => _context;

		#endregion

		#region IActionFilter Implementation
		public async Task OnActionExecutingAsync(ActionExecutingContext context)
		{
			try
			{
				// No validation if not enabled
				if (!_config.Value.IsContextEnabled(_context))
				{
					return;
				}

				// Get the response
				var response = context?.HttpContext?.Request?.GetItem("g-recaptcha-response").ToString();
				if (string.IsNullOrWhiteSpace(response))
				{
					context?.ModelState.TryAddModelError(string.Empty, string.Format(CultureInfo.CurrentCulture,
						CommonResources.S_NullOrEmptyValue_Name, "captcha response"));
				}
				else
				{
					// Validate
					using (var httpClient = new HttpClient())
					{
						// Data to be posted
						var postParams = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
							{
								["secret"] = _config.Value.SecretKey,
								["response"] = response
							};
						var clientIp = context.HttpContext.GetRemoteAddress();
						if (clientIp != null)
						{
							postParams["remoteip"] = clientIp.ToString();
						}

						// Send
						using (var postData = new FormUrlEncodedContent(postParams))
						{
							// Verify
							var verifyResponse = await httpClient.PostAsync(_responseVerifyUrl, postData);

							// Get object
							var responseStr = await verifyResponse.Content.ReadAsStringAsync();
							var responseJson = JsonConvert.DeserializeObject<VerifyResponse>(responseStr);

							// Dispose
							verifyResponse.Dispose();

							// Check
							if (!responseJson.Success)
							{
								// ReSharper disable once ConstantConditionalAccessQualifier
								context?.ModelState.TryAddModelError(string.Empty, string.Format(CultureInfo.CurrentCulture,
									CommonResources.S_InvalidValue_Name, "captcha response"));
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				_logger.Value.LogError(ex);
				context?.ModelState.TryAddModelError(string.Empty, LocalResources.S_CaptchaValidationFailed);
			}
		}

		public override void OnActionExecuting(ActionExecutingContext context)
		{
			OnActionExecutingAsync(context).Wait();
		}
		#endregion
	}

	/// <summary>
	/// Provider to decide whether the recaptcha has to be enabled
	/// </summary>
	public interface IRecaptchaEnablementProvider
	{
		/// <summary>
		/// Whether the recaptcha has to be enabled
		/// </summary>
		bool IsEnabled { get; }
	}
}
