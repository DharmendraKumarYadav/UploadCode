﻿using System;
using System.Diagnostics.CodeAnalysis;
using Microsoft.AspNetCore.Mvc.ApplicationModels;

namespace FRT.Web
{
	/// <summary>
	/// Action Model Convention
	/// </summary>
	public class SeoActionModelConvention : IActionModelConvention
	{
		#region Implementation of IActionModelConvention
		/// <summary>
		/// Called to apply the convention to the <see cref="T:Microsoft.AspNet.Mvc.ApplicationModels.ActionModel"/>.
		/// </summary>
		/// <param name="action">The <see cref="T:Microsoft.AspNet.Mvc.ApplicationModels.ActionModel"/>.</param>
		[SuppressMessage("Microsoft.Globalization", "CA1308:NormalizeStringsToUppercase")]
		public void Apply(ActionModel action)
		{
			if (action == null)
			{
				throw new ArgumentNullException(nameof(action));
			}

			// Controller Name
			action.ActionName = action.ActionName.NameToDisplayName("-").ToLowerInvariant();
		}
		#endregion
	}
}
