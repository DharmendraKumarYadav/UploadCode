﻿using Microsoft.AspNetCore.Mvc.ApplicationModels;

namespace FRT.Web
{
	/// <summary>
	/// Application Model Convention
	/// </summary>
	public class SeoApplicationModelConvention : IApplicationModelConvention
	{
		#region Implementation of IApplicationModelConvention
		/// <summary>
		/// Called to apply the convention to the <see cref="T:Microsoft.AspNet.Mvc.ApplicationModels.ApplicationModel"/>.
		/// </summary>
		/// <param name="application">The <see cref="T:Microsoft.AspNet.Mvc.ApplicationModels.ApplicationModel"/>.</param>
		public void Apply(ApplicationModel application)
		{
		}
		#endregion
	}
}
