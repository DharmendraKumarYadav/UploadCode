﻿using System;
using System.Diagnostics.CodeAnalysis;
using Microsoft.AspNetCore.Mvc.ApplicationModels;

namespace FRT.Web
{
	/// <summary>
	/// Controlle Model Convention
	/// </summary>
	public class SeoControllerModelConvention : IControllerModelConvention
	{
		#region Implementation of IControllerModelConvention
		/// <summary>
		/// Called to apply the convention to the <see cref="T:Microsoft.AspNet.Mvc.ApplicationModels.ControllerModel"/>.
		/// </summary>
		/// <param name="controller">The <see cref="T:Microsoft.AspNet.Mvc.ApplicationModels.ControllerModel"/>.</param>
		[SuppressMessage("Microsoft.Globalization", "CA1308:NormalizeStringsToUppercase")]
		public void Apply(ControllerModel controller)
		{
			if (controller == null)
			{
				throw new ArgumentNullException(nameof(controller));
			}

			// Controller Name
			controller.ControllerName = controller.ControllerName.NameToDisplayName("-").ToLowerInvariant();
		}
		#endregion
	}
}
