﻿using System;
using System.Diagnostics.CodeAnalysis;
using FRT.Properties;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.DependencyInjection;
using FRT.Web.Properties;

namespace FRT.Web
{
	/// <summary>
	/// Seo Route Extensions
	/// </summary>
	public static class SeoRouteExtensions
	{
		public static IRouteBuilder MapSeoRoute(this IRouteBuilder routeCollectionBuilder, string name, string template)
		{
			routeCollectionBuilder.MapSeoRoute(name, template, null);
			return routeCollectionBuilder;
		}

		public static IRouteBuilder MapSeoRoute(this IRouteBuilder routeCollectionBuilder, string name, string template, object defaults)
		{
			return routeCollectionBuilder.MapSeoRoute(name, template, defaults, null);
		}

		public static IRouteBuilder MapSeoRoute(this IRouteBuilder routeCollectionBuilder, string name, string template, object defaults, object constraints)
		{
			return routeCollectionBuilder.MapSeoRoute(name, template, defaults, constraints, null);
		}

		[SuppressMessage("Microsoft.Design", "CA1062:Validate arguments of public methods", MessageId = "0")]
		public static IRouteBuilder MapSeoRoute(this IRouteBuilder routeCollectionBuilder, string name, string template, object defaults, object constraints, object dataTokens)
		{
			if (routeCollectionBuilder?.DefaultHandler == null)
			{
				throw new InvalidOperationException(LocalResources.S_DefaultRouteHandlerMustBeSet);
			}

			IInlineConstraintResolver requiredService = routeCollectionBuilder.ServiceProvider.GetRequiredService<IInlineConstraintResolver>();
			routeCollectionBuilder.Routes.Add(new SeoRoute(routeCollectionBuilder.DefaultHandler, name, template, ObjectToDictionary(defaults), ObjectToDictionary(constraints), ObjectToDictionary(dataTokens), requiredService));
			return routeCollectionBuilder;
		}

		private static RouteValueDictionary ObjectToDictionary(object value)
		{
			RouteValueDictionary dictionary = value as RouteValueDictionary;
			if (dictionary != null)
			{
				return dictionary;
			}
			return new RouteValueDictionary(value);
		}
	}
}
