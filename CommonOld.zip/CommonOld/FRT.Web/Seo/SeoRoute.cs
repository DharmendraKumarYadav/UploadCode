﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Routing;

namespace FRT.Web
{
	/// <summary>
	/// Seo Route
	/// </summary>
	public class SeoRoute : Route
	{
		#region Construction
		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="target"></param>
		/// <param name="routeTemplate"></param>
		/// <param name="inlineConstraintResolver"></param>
		public SeoRoute(IRouter target, string routeTemplate, IInlineConstraintResolver inlineConstraintResolver)
			: this(target, routeTemplate, null, null, null, inlineConstraintResolver)
		{
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="target"></param>
		/// <param name="routeTemplate"></param>
		/// <param name="defaults"></param>
		/// <param name="constraints"></param>
		/// <param name="dataTokens"></param>
		/// <param name="inlineConstraintResolver"></param>
		public SeoRoute(IRouter target, string routeTemplate, RouteValueDictionary defaults, IDictionary<string, object> constraints, RouteValueDictionary dataTokens, IInlineConstraintResolver inlineConstraintResolver)
			: this(target, null, routeTemplate, defaults, constraints, dataTokens, inlineConstraintResolver)
		{
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="target"></param>
		/// <param name="routeName"></param>
		/// <param name="routeTemplate"></param>
		/// <param name="defaults"></param>
		/// <param name="constraints"></param>
		/// <param name="dataTokens"></param>
		/// <param name="inlineConstraintResolver"></param>
		public SeoRoute(IRouter target, string routeName, string routeTemplate, RouteValueDictionary defaults, IDictionary<string, object> constraints, RouteValueDictionary dataTokens, IInlineConstraintResolver inlineConstraintResolver)
			: base(target, routeName, routeTemplate, defaults, constraints, dataTokens, inlineConstraintResolver)
		{
		}
		#endregion

		#region GetVirtualPath
		/// <summary>
		/// Gets the virtual path for the given context
		/// </summary>
		/// <param name="context">Context</param>
		/// <returns>Virtual path data if successful. Null otherwise</returns>
		public override VirtualPathData GetVirtualPath(VirtualPathContext context)
		{
			// Give base the first shot
			var vpData = base.GetVirtualPath(context);
			if (string.IsNullOrWhiteSpace(vpData?.VirtualPath))
			{
				return vpData;
			}

			// Process
			vpData.VirtualPath = GetVirtualPath(vpData.VirtualPath);

			// Return
			return vpData;
		}
		#endregion

		#region RouteAsync
		/// <summary>
		/// Routes the incoming request to the internal framrwork
		/// </summary>
		/// <param name="context">Route context</param>
		/// <returns>Asynchronous task</returns>
		public override Task RouteAsync(RouteContext context)
		{
			return base.RouteAsync(context)
				.ContinueWith(t =>
				{
					// Check if we have the data resolved by the base
					if (context.RouteData != null)
					{
						// Process
						context.RouteData = GetRouteData(context.RouteData);
					}
				});
		}
		#endregion

		#region Implementation
		/// <summary>
		/// Processes the virtual path
		/// </summary>
		/// <param name="virtualPath">Raw virtual path</param>
		/// <returns>Resolved virtual path</returns>
		[SuppressMessage("Microsoft.Globalization", "CA1308:NormalizeStringsToUppercase")]
		private static string GetVirtualPath(string virtualPath)
		{
			string trailers;
			virtualPath = Url.StripTrailers(virtualPath, out trailers);
			var startsWithSlash = virtualPath.StartsWith("/", StringComparison.Ordinal);
			var endsWithSlash = virtualPath.EndsWith("/", StringComparison.Ordinal);

			// Split
			var parts = virtualPath.Split('/').Select(p => p.Trim()).Where(p => p.Length > 0).ToArray();
			for (int i = 0; i < parts.Length; ++i)
			{
				parts[i] = parts[i].NameToDisplayName("-").ToLowerInvariant();
			}

			// Join
			virtualPath = string.Join("/", parts);
			if (startsWithSlash && !virtualPath.StartsWith("/", StringComparison.Ordinal))
			{
				virtualPath = "/" + virtualPath;
			}
			if (endsWithSlash && !virtualPath.EndsWith("/", StringComparison.Ordinal))
			{
				virtualPath = virtualPath + "/";
			}

			// Return
			return virtualPath + trailers;
		}

		/// <summary>
		/// Updates the route data
		/// </summary>
		/// <param name="routeData"></param>
		private static RouteData GetRouteData(RouteData routeData)
		{
			// Convert
			var routeValues = new RouteValueDictionary();
			foreach (KeyValuePair<string, object> kv in routeData.Values)
			{
				var val = kv.Value as string;
				if (val != null)
				{
					routeValues[kv.Key] = val.DisplayNameToName("-");
				}
				else
				{
					routeValues[kv.Key] = kv.Value;
				}
			}

			// Replace & Return
			routeData.Values.Clear();
			routeData.Values.AddRange(routeValues);

			// Return
			return routeData;
		}
		#endregion
	}
}
