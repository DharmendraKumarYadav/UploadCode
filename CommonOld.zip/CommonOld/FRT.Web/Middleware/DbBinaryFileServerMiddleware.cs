﻿using System;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using FRT.Properties;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Builder;
using Microsoft.Net.Http.Headers;

namespace FRT.Web
{
	/// <summary>
	/// Serves files stored in the database
	/// </summary>
	internal sealed class DbBinaryFileServerMiddleware
	{
		private readonly RequestDelegate _next;
		private readonly Action<DbBinaryFileServerOptions> _optionsBuilder;
		private readonly Lazy<ILogger<DbBinaryFileServerMiddleware>> _logger;
		private readonly Func<object, Task> _clearCacheHeadersDelegate;

		#region Construction

		/// <summary>
		/// Constructor
		/// </summary>
		public DbBinaryFileServerMiddleware(RequestDelegate next, Action<DbBinaryFileServerOptions> optionsBuilder)
		{
			_next = next;
			_optionsBuilder = optionsBuilder ?? (o => { });
			_logger = new Lazy<ILogger<DbBinaryFileServerMiddleware>>(Crosscuttings.GetTypedLogger<DbBinaryFileServerMiddleware>);
			_clearCacheHeadersDelegate = ClearCacheHeaders;
		}

		#endregion

		#region Properties

		private DbBinaryFileServerOptions _options;
		/// <summary>
		/// Options
		/// </summary>
		private DbBinaryFileServerOptions Options
		{
			get
			{
				if (_options == null)
				{
					_options = new DbBinaryFileServerOptions();
					_optionsBuilder(_options);
				}
				return _options;
			}
		}

		/// <summary>
		/// Logger
		/// </summary>
		// ReSharper disable once UnusedMember.Local
		private ILogger<DbBinaryFileServerMiddleware> Logger => _logger.Value;

		#endregion

		#region Invoke

		/// <summary>
		/// Implementation
		/// </summary>
		/// <param name="context">Http context</param>
		/// <returns>Task</returns>
		public async Task Invoke(HttpContext context)
		{
			// Validate
			if ((context?.Request == null) || (context.Response == null))
			{
				await _next(context);
				return;
			}

			// Get the token
			var response = context.Response;
			var token = context.Request.GetItem("t").ToString();

			// Check if the token is valid
			var tokenResult = TokenUtil.AnalyzeToken(token, DbFileServer.TokenAction);
			if (!tokenResult.Status)
			{
				response.Clear();
				response.StatusCode = (int) HttpStatusCode.BadRequest;
				response.OnStarting(_clearCacheHeadersDelegate, response);
			}
			else
			{
				try
				{
					var tableName = tokenResult.Data[0];
					var idColName = tokenResult.Data[1];
					var idValueTypeStr = tokenResult.Data[2];
					var idValueStr = tokenResult.Data[3];
					var contentColName = tokenResult.Data[4];
					var mimeColName = tokenResult.Data[5];
					var asAttachment = bool.Parse((tokenResult.Data.Length > 6) ? tokenResult.Data[6] : "false");
					var fileNameColumnName = (tokenResult.Data.Length > 7) ? tokenResult.Data[7] : null;

					// Get the data & serve
					var idValueType = Type.GetType(idValueTypeStr, true, true);
					var idValue = idValueStr.ConvertType(idValueType);

					// Get data
					var data = await GetContent(tableName, idColName, idValue, contentColName, mimeColName, asAttachment, fileNameColumnName);
					if (data == null)
					{
						response.Clear();
						response.StatusCode = (int) HttpStatusCode.NotFound;
						response.OnStarting(_clearCacheHeadersDelegate, response);
					}
					else
					{
						// Clear
						response.Clear();
						response.StatusCode = (int)HttpStatusCode.OK;
						response.OnStarting(_clearCacheHeadersDelegate, response);

						// Serve
						response.ContentType = data.Item2;
						if (asAttachment)
						{
							ContentDispositionHeaderValue dispHeader = new ContentDispositionHeaderValue("attachment");
							dispHeader.SetHttpFileName(data.Item3);
							response.Headers["Content-Disposition"] = dispHeader.ToString();
						}
						await response.Body.WriteAsync(data.Item1, 0, data.Item1.Length);
					}
				}
				catch
				{
					response.Clear();
					response.StatusCode = (int)HttpStatusCode.BadRequest;
					response.OnStarting(_clearCacheHeadersDelegate, response);
				}
			}

			// Next
			await _next(context);
		}

		#endregion

		#region Helpers

		private Task ClearCacheHeaders(object state)
		{
			HttpResponse response = (HttpResponse)state;
			response.Headers["Cache-Control"] = "no-cache";
			response.Headers["Pragma"] = "no-cache";
			response.Headers["Expires"] = "-1";
			response.Headers.Remove("ETag");
			return Task.CompletedTask;
		}

		private async Task<Tuple<byte[], string, string>> GetContent(string tableName, string idColumnName, object idValue,
			string contentColumnName, string mimeColumnName, bool asAttachment, string fileNameColumnName)
		{
			var options = Options;
			if (options.ConnectionString == null)
			{
				throw new InvalidOperationException(string.Format(CultureInfo.InvariantCulture,
					CommonResources.S_NullOrEmptyValue_Name, nameof(options.ConnectionString)));
			}

			// Create connection
			using (var sqlConnection = new SqlConnection(options.ConnectionString))
			{
				// Open
				await sqlConnection.OpenAsync();

				// File Name column
				tableName = tableName.Trim();
				idColumnName = idColumnName.Trim();
				contentColumnName = contentColumnName.Trim();
				mimeColumnName = mimeColumnName.Trim();
				fileNameColumnName = !string.IsNullOrWhiteSpace(fileNameColumnName) ? fileNameColumnName.Trim() : null;

				// Create the Query
				var queryText = (fileNameColumnName != null)
					? string.Format(CultureInfo.InvariantCulture, "SELECT {0}, {1}, {2} FROM {3} WHERE {4} = @id", contentColumnName,
						mimeColumnName, fileNameColumnName, tableName, idColumnName)
					: string.Format(CultureInfo.InvariantCulture, "SELECT {0}, {1} FROM {2} WHERE {3} = @id", contentColumnName,
						mimeColumnName, tableName, idColumnName);
				using (var cmd = new SqlCommand(queryText, sqlConnection))
				{
					// Parameter
					var idParam = new SqlParameter
					{
						ParameterName = "@id",
						Value = idValue
					};
					cmd.Parameters.Add(idParam);

					// Execute
					using (var reader = await cmd.ExecuteReaderAsync())
					{
						var contentDbValue = reader[contentColumnName];
						var mimeDbValue = reader[mimeColumnName];
						var fileNameDbValue = (fileNameColumnName != null) ? reader[fileNameColumnName] : DBNull.Value;

						if ((contentDbValue != DBNull.Value) && (contentDbValue != null)
						    && (mimeDbValue != DBNull.Value) && (mimeDbValue != null))
						{
							var content = (byte[]) Convert.ChangeType(contentDbValue, typeof(byte[]));

							var mimeType = Convert.ToString(mimeDbValue);
							mimeType = string.IsNullOrWhiteSpace(mimeType) ? null : mimeType.Trim();

							var fileName = ((fileNameDbValue != DBNull.Value) && (fileNameDbValue != null))
								? Convert.ToString(fileNameDbValue)
								: null;
							fileName = string.IsNullOrWhiteSpace(fileName) ? null : fileName.Trim();
							if (asAttachment && (fileName == null))
							{
								fileName = "File" + (MimeUtil.GetFileExtensionsForMimeType(mimeType).FirstOrDefault() ?? ".bin");
							}

							// Return
							return new Tuple<byte[], string, string>(content, mimeType, fileName);
						}
					}
				}
			}
			return null;
		}

		#endregion
	}

	/// <summary>
	/// Options
	/// </summary>
	public sealed class DbBinaryFileServerOptions
	{
		private string _connectionString;
		/// <summary>
		/// Connection string
		/// </summary>
		public string ConnectionString
		{
			get => _connectionString;
			set => _connectionString = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}
	}

	/// <summary>
	/// Extension method used to add the middleware to the HTTP request pipeline.
	/// </summary>
	public static class DbBinaryFileServerMiddlewareExtensions
	{
		/// <summary>
		/// Extension method used to add the middleware to the HTTP request pipeline.
		/// </summary>
		/// <param name="builder">Application builder</param>
		/// <param name="options">Options</param>
		/// <returns>Application builder</returns>
		public static IApplicationBuilder UseDbBinaryFileServer(this IApplicationBuilder builder, DbBinaryFileServerOptions options = null)
		{
			return builder.UseDbBinaryFileServer(optionsParam =>
			{
				if ((options != null) && (optionsParam != null))
				{
					Crosscuttings.Mapper.Map(options, optionsParam);
				}
			});
		}

		/// <summary>
		/// Extension method used to add the middleware to the HTTP request pipeline.
		/// </summary>
		/// <param name="builder">Application builder</param>
		/// <param name="optionsBuilder">Options builder</param>
		/// <returns>Application builder</returns>
		public static IApplicationBuilder UseDbBinaryFileServer(this IApplicationBuilder builder, Action<DbBinaryFileServerOptions> optionsBuilder)
		{
			return builder.UseMiddleware<DbBinaryFileServerMiddleware>(optionsBuilder);
		}
	}
}
