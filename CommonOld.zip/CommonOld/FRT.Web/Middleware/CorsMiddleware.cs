﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using FRT.Properties;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace FRT.Web
{
	/// <summary>
	/// Cors policy middleware
	/// https://developer.mozilla.org/en-US/docs/Web/HTTP/Access_control_CORS
	/// http://www.html5rocks.com/static/images/cors_server_flowchart.png
	/// http://www.w3.org/TR/cors/
	/// </summary>
	internal sealed class CorsMiddleware
	{
		private readonly RequestDelegate _next;
		private readonly Action<CorsOptions> _optionsBuilder;
		private readonly Lazy<ILogger<CorsMiddleware>> _logger;

		#region Construction
		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="next">Next middleware</param>
		/// <param name="optionsBuilder">Options builder</param>
		public CorsMiddleware(RequestDelegate next, Action<CorsOptions> optionsBuilder)
		{
			_next = next;
			_optionsBuilder = optionsBuilder ?? (o => { });
			_logger = new Lazy<ILogger<CorsMiddleware>>(Crosscuttings.GetTypedLogger<CorsMiddleware>);
		}
		#endregion

		#region Properties
		private CorsOptions _options;
		/// <summary>
		/// Options
		/// </summary>
		private CorsOptions Options
		{
			get
			{
				if (_options == null)
				{
					_options = new CorsOptions();
					_optionsBuilder(_options);
				}
				return _options;
			}
		}

		/// <summary>
		/// Logger
		/// </summary>
		private ILogger<CorsMiddleware> Logger => _logger.Value;
		#endregion

		#region Invoke
		/// <summary>
		/// Implementation
		/// </summary>
		/// <param name="httpContext">Http context</param>
		/// <returns>Task</returns>
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
		public Task Invoke(HttpContext httpContext)
		{
			CorsRequestProcessingResult processingResult;
			try
			{
				processingResult = ProcessCorsRequest(httpContext, httpContext.Request, httpContext.Response);
			}
			catch (Exception ex)
			{
				processingResult = CorsRequestProcessingResult.NotHandled;
				Logger.LogError(0, ex, CommonResources.S_UnknownError);
			}

			// Next Middleware
			if (processingResult != CorsRequestProcessingResult.HandledTerminateRequest)
			{
				return _next(httpContext);
			}
			return Task.FromResult(0);
		}
		#endregion

		#region Implementation
		#region Request Processing
		/// <summary>
		/// Process CORS Request
		/// </summary>
		/// <param name="httpContext">Http Context</param>
		/// <param name="httpRequest">Http Request</param>
		/// <param name="httpResponse">Http Response</param>
		/// <returns></returns>
		private CorsRequestProcessingResult ProcessCorsRequest(HttpContext httpContext, HttpRequest httpRequest, HttpResponse httpResponse)
		{
			// Origin header is required
			var requestOrigin = httpRequest.Headers["Origin"].ToString();
			if (string.IsNullOrWhiteSpace(requestOrigin))
			{
				// Not processing. Proceed with next middleware
				return CorsRequestProcessingResult.NotHandled;
			}
			requestOrigin = requestOrigin.Trim();

			// Get the configuration element
			var processor = Options.Processors.FirstOrDefault(p =>
				(p.OriginCondition == null) || p.OriginCondition(requestOrigin));
			if (processor == null)
			{
				return CorsRequestProcessingResult.NotHandled;
			}

			// Variables
			var isPreflightRequest = false;

			// Is OPTIONS
			if (IsOptionsRequest(httpRequest))
			{
				// Check Method header
				if (HasRequestMethodRequestHeader(httpRequest))
				{
					// Flag
					isPreflightRequest = true;

					// Process Preflight Request
					if (!ProcessCorsPreflightRequest(httpContext, httpRequest, httpResponse, processor))
					{
						// Not a valid Preflight Request
						return CorsRequestProcessingResult.NotHandled;
					}
				}
				else if (ShouldSetExposeHeadersResponseHeader(httpRequest, processor))
				{
					// Set Access-Control-Expose-Headers
					SetExposeHeadersResponseHeader(httpRequest, httpResponse, processor);
				}
			}
			else if (ShouldSetExposeHeadersResponseHeader(httpRequest, processor))
			{
				// Set Access-Control-Expose-Headers
				SetExposeHeadersResponseHeader(httpRequest, httpResponse, processor);
			}

			// Continue
			SetAllowOriginResponseHeader(httpRequest, httpResponse, processor);

			// Timing-Allow-Origin
			SetTimingAllowOriginResponseHeader(httpRequest, httpResponse, processor);

			// Access-Control-Allow-Credentials
			if (ShouldSetAllowCredentialsResponseHeader(httpRequest, processor))
			{
				SetAllowCredentialsResponseHeader(httpRequest, httpResponse, processor);
			}

			// End a Preflight Request
			if (isPreflightRequest)
			{
				httpResponse.StatusCode = StatusCodes.Status200OK;
				return CorsRequestProcessingResult.HandledTerminateRequest;
			}

			// Return
			return CorsRequestProcessingResult.Handled;
		}
		#endregion

		#region Pre Flight Request Processing
		/// <summary>
		/// Process CORS Request
		/// </summary>
		/// <param name="httpContext">Http Context</param>
		/// <param name="httpRequest">Http Request</param>
		/// <param name="httpResponse">Http Response</param>
		/// <param name="processor">Request processor</param>
		/// <returns></returns>
		// ReSharper disable once UnusedParameter.Local
		private static bool ProcessCorsPreflightRequest(HttpContext httpContext, HttpRequest httpRequest, HttpResponse httpResponse, CorsProcessorOptions processor)
		{
			// Check if Access-Control-Request-Method is valid
			// Check if Access-Control-Request-Headers is not specified or valid if specified
			if (!IsRequestMethodRequestHeaderValid(httpRequest, processor)
				|| (HasRequestHeadersRequestHeader(httpRequest)
					&& !IsRequestHeadersRequestHeaderValid(httpRequest, processor)))
			{
				// Not a valid Preflight Request
				return false;
			}

			// Set Access-Control-Allow-Methods
			SetAllowMethodsResponseHeader(httpRequest, httpResponse, processor);

			// Set Access-Control-Allow-Headers
			SetAllowHeadersResponseHeader(httpRequest, httpResponse, processor);

			// Set Access-Control-Max-Age
			if (ShouldSetMaxAgeResponseHeader(httpRequest, processor))
			{
				SetMaxAgeResponseHeader(httpRequest, httpResponse, processor);
			}

			// Return
			return true;
		}

		/// <summary>
		/// Whether OPTIONS request
		/// </summary>
		/// <param name="httpRequest">Http Request</param>
		/// <returns></returns>
		private static bool IsOptionsRequest(HttpRequest httpRequest)
		{
			return string.Equals(httpRequest.Method, "OPTIONS", StringComparison.OrdinalIgnoreCase);
		}
		#endregion

		#region Access-Control-Allow-Origin
		/// <summary>
		/// Sets Access-Control-Allow-Origin header
		/// </summary>
		/// <param name="httpRequest">Http Request</param>
		/// <param name="httpResponse">Http Response</param>
		/// <param name="processor">Request processor</param>
		[SuppressMessage("Microsoft.Globalization", "CA1308:NormalizeStringsToUppercase")]
		private static void SetAllowOriginResponseHeader(HttpRequest httpRequest, HttpResponse httpResponse, CorsProcessorOptions processor)
		{
			var originOptions = processor.AllowOrigin;
			var uriBuilder = new UriBuilder(Guid.NewGuid().ToString("N").ToLowerInvariant() + ".com");
			var requestUri = httpRequest.GetUri();
			var requestUrl = requestUri.ToString();

			// Decide
			switch (originOptions.OriginType)
			{
				case CorsOriginType.Request:
					{
						uriBuilder = new UriBuilder(requestUrl);
						break;
					}
				case CorsOriginType.Origin:
					{
						var origin = httpRequest.Headers["Origin"].ToString();
						uriBuilder = string.IsNullOrWhiteSpace(origin)
							? new UriBuilder(requestUrl) : new UriBuilder(origin);
						break;
					}
				case CorsOriginType.Custom:
					{
						var origin = (originOptions.CustomOrigin ?? string.Empty).Trim();
						if (origin.Length > 0)
						{
							uriBuilder = new UriBuilder(origin);
						}
						break;
					}
				case CorsOriginType.All:
					{
						httpResponse.Headers["Access-Control-Allow-Origin"] = "*";
						return;
					}
			}

			// Set scheme is not set
			if (string.IsNullOrWhiteSpace(uriBuilder.Scheme))
			{
				uriBuilder.Scheme = requestUri.Scheme;
			}

			// Write
			httpResponse.Headers["Access-Control-Allow-Origin"] = uriBuilder.Uri.GetComponents(UriComponents.Scheme | UriComponents.Host | UriComponents.Port, UriFormat.Unescaped);

			// Specify Vary Header
			var varyHeader = httpResponse.Headers["Vary"].ToString();
			if (string.IsNullOrWhiteSpace(varyHeader))
			{
				varyHeader = "Origin";
			}
			else
			{
				varyHeader = string.Join(", ",
					varyHeader.Split(',')
						.Select(p => p.Trim())
						.Where(p => p.Length > 0)
						.Concat(new[] { "Origin" })
						.Distinct(StringComparer.OrdinalIgnoreCase));
			}
			httpResponse.Headers["Vary"] = varyHeader;
		}
		#endregion

		#region Timing-Allow-Origin
		/// <summary>
		/// Sets Timing-Allow-Origin header
		/// </summary>
		/// <param name="httpRequest">Http Request</param>
		/// <param name="httpResponse">Http Response</param>
		/// <param name="processor">Request processor</param>
		[SuppressMessage("Microsoft.Globalization", "CA1308:NormalizeStringsToUppercase")]
		private static void SetTimingAllowOriginResponseHeader(HttpRequest httpRequest, HttpResponse httpResponse,
			CorsProcessorOptions processor)
		{
			var originOptions = processor.TimingAllowOrigin;
			var uriBuilder = new UriBuilder(Guid.NewGuid().ToString("N").ToLowerInvariant() + ".com");
			var requestUri = httpRequest.GetUri();
			var requestUrl = requestUri.ToString();

			// Decide
			switch (originOptions.OriginType)
			{
				case CorsOriginType.Request:
					{
						uriBuilder = new UriBuilder(requestUrl);
						break;
					}
				case CorsOriginType.Origin:
					{
						var origin = httpRequest.Headers["Origin"].ToString();
						uriBuilder = string.IsNullOrWhiteSpace(origin)
							? new UriBuilder(requestUrl) : new UriBuilder(origin);
						break;
					}
				case CorsOriginType.Custom:
					{
						var origin = (originOptions.CustomOrigin ?? string.Empty).Trim();
						if (origin.Length > 0)
						{
							uriBuilder = new UriBuilder(origin);
						}
						break;
					}
				case CorsOriginType.All:
					{
						httpResponse.Headers["Timing-Allow-Origin"] = "*";
						return;
					}
			}

			// Set scheme is not set
			if (string.IsNullOrWhiteSpace(uriBuilder.Scheme))
			{
				uriBuilder.Scheme = requestUri.Scheme;
			}

			// Write
			httpResponse.Headers["Timing-Allow-Origin"] = uriBuilder.Uri.GetComponents(UriComponents.Scheme | UriComponents.Host | UriComponents.Port, UriFormat.Unescaped);
		}
		#endregion

		#region Access-Control-Request-Method
		/// <summary>
		/// Checks if Access-Control-Request-Method is specified
		/// </summary>
		/// <param name="httpRequest">Http Request</param>
		/// <returns></returns>
		private static bool HasRequestMethodRequestHeader(HttpRequest httpRequest)
		{
			return !string.IsNullOrWhiteSpace(httpRequest.Headers["Access-Control-Request-Method"].ToString());
		}

		/// <summary>
		/// Checks if Access-Control-Request-Method is valid
		/// </summary>
		/// <param name="httpRequest">Http Request</param>
		/// <param name="processor">Request processor</param>
		/// <returns></returns>
		// ReSharper disable once UnusedParameter.Local
		private static bool IsRequestMethodRequestHeaderValid(HttpRequest httpRequest, CorsProcessorOptions processor)
		{
			var requestMethod = httpRequest.Headers["Access-Control-Request-Method"].ToString().Trim();
			var validMethods = new[] { "OPTIONS", "GET", "HEAD", "POST", "PUT", "DELETE", "TRACE", "CONNECT" };
			return validMethods.Contains(requestMethod, StringComparer.OrdinalIgnoreCase);
		}

		/// <summary>
		/// Sets Access-Control-Allow-Methods header
		/// </summary>
		/// <param name="httpRequest">Http Request</param>
		/// <param name="httpResponse">Http Response</param>
		/// <param name="processor">Request processor</param>
		private static void SetAllowMethodsResponseHeader(HttpRequest httpRequest, HttpResponse httpResponse, CorsProcessorOptions processor)
		{
			var allowMethodsOptions = processor.AllowMethods;
			var allowedMethods = new List<string>();
			switch (allowMethodsOptions.MethodType)
			{
				case CorsAllowMethodsType.DoNotRespond:
					{
						return;
					}
				case CorsAllowMethodsType.Request:
					{
						allowedMethods.Add(httpRequest.Headers["Access-Control-Request-Method"].ToString().Trim());
						break;
					}
				case CorsAllowMethodsType.Custom:
					{
						allowedMethods.AddRange(allowMethodsOptions.CustomMethods);
						break;
					}
				case CorsAllowMethodsType.RequestAndCustom:
					{
						allowedMethods.Add(httpRequest.Headers["Access-Control-Request-Method"].ToString().Trim());
						allowedMethods.AddRange(allowMethodsOptions.CustomMethods);
						break;
					}
				case CorsAllowMethodsType.All:
					{
						allowedMethods.Add("*");
						break;
					}
			}

			// Adjust
			allowedMethods = allowedMethods.Where(p => p != null)
				.Select(p => p.Trim())
				.Where(p => p.Length > 0)
				.Distinct(StringComparer.OrdinalIgnoreCase)
				.ToList();
			if (allowedMethods.Contains("*", StringComparer.Ordinal))
			{
				allowedMethods = new[] { "*" }.ToList();
			}
			if (allowedMethods.Count == 0)
			{
				// Add invalid method
				allowedMethods.Add("NONE");
			}

			// Set
			httpResponse.Headers["Access-Control-Allow-Methods"] = string.Join(", ", allowedMethods);
		}
		#endregion

		#region Access-Control-Request-Headers
		/// <summary>
		/// Checks if Access-Control-Request-Headers is specified
		/// </summary>
		/// <param name="httpRequest">Http Request</param>
		/// <returns></returns>
		private static bool HasRequestHeadersRequestHeader(HttpRequest httpRequest)
		{
			return !string.IsNullOrWhiteSpace(httpRequest.Headers["Access-Control-Request-Headers"].ToString());
		}

		/// <summary>
		/// Checks if Access-Control-Request-Headers is valid
		/// </summary>
		/// <param name="httpRequest">Http Request</param>
		/// <param name="processor">Request processor</param>
		/// <returns></returns>
		// ReSharper disable once UnusedParameter.Local
		private static bool IsRequestHeadersRequestHeaderValid(HttpRequest httpRequest, CorsProcessorOptions processor)
		{
			var requestHeaders = httpRequest.Headers["Access-Control-Request-Headers"]
				.ToString()
				.Trim()
				.Split(',')
				.Select(p => p.Trim())
				.ToArray();
			return requestHeaders.Any() && requestHeaders.All(p => p.Length > 0);
		}

		/// <summary>
		/// Sets Access-Control-Allow-Headers header
		/// </summary>
		/// <param name="httpRequest">Http Request</param>
		/// <param name="httpResponse">Http Response</param>
		/// <param name="processor">Request processor</param>
		private static void SetAllowHeadersResponseHeader(HttpRequest httpRequest, HttpResponse httpResponse, CorsProcessorOptions processor)
		{
			var allowHeadersOptions = processor.AllowHeaders;
			var allowedHeaders = new List<string>();

			// Requested Headers
			if ((allowHeadersOptions.HeadersType == CorsAllowHeadersType.Request)
				|| (allowHeadersOptions.HeadersType == CorsAllowHeadersType.Both))
			{
				var requestedHeaders = httpRequest.Headers["Access-Control-Request-Headers"]
					.ToString()
					.Trim()
					.Split(',')
					.Select(p => p.Trim())
					.Where(p => p.Length > 0)
					.Where(p => !string.Equals(p, "*", StringComparison.Ordinal))
					.ToArray();
				allowedHeaders.AddRange(requestedHeaders);
			}

			// Custom Headers
			if ((allowHeadersOptions.HeadersType == CorsAllowHeadersType.Custom)
				|| (allowHeadersOptions.HeadersType == CorsAllowHeadersType.Both))
			{
				var headers = allowHeadersOptions.CustomHeaders
					.Where(p => !string.Equals(p, "*", StringComparison.Ordinal))
					.ToArray();
				allowedHeaders.AddRange(headers);
			}

			// Adjust
			allowedHeaders = allowedHeaders.Distinct(StringComparer.OrdinalIgnoreCase).ToList();

			// Set
			if (allowedHeaders.Count > 0)
			{
				httpResponse.Headers["Access-Control-Allow-Headers"] = string.Join(", ", allowedHeaders);
			}
		}
		#endregion

		#region Access-Control-Expose-Headers
		/// <summary>
		/// Whether we can/should expose accessible response headers
		/// </summary>
		/// <param name="httpRequest">Http Request</param>
		/// <param name="processor">Request processor</param>
		/// <returns></returns>
		private static bool ShouldSetExposeHeadersResponseHeader(HttpRequest httpRequest, CorsProcessorOptions processor)
		{
			var exposeMode = processor.ExposeHeaders.Mode;
			if (exposeMode == CorsExposeHeadersMode.Never)
			{
				return false;
			}
			else if (exposeMode == CorsExposeHeadersMode.Always)
			{
				return true;
			}

			// Check if we have headers specified in the request
			return HasRequestHeadersRequestHeader(httpRequest);
		}

		/// <summary>
		/// Sets Access-Control-Expose-Headers header
		/// </summary>
		/// <param name="httpRequest">Http Request</param>
		/// <param name="httpResponse">Http Response</param>
		/// <param name="processor">Request processor</param>
		private static void SetExposeHeadersResponseHeader(HttpRequest httpRequest, HttpResponse httpResponse, CorsProcessorOptions processor)
		{
			var exposedHeadersOptions = processor.ExposeHeaders;
			var exposedHeaders = new List<string>();

			// Requested Headers
			if ((exposedHeadersOptions.HeadersType == CorsExposedHeadersType.Request)
				|| (exposedHeadersOptions.HeadersType == CorsExposedHeadersType.Both))
			{
				var requestedHeaders = httpRequest.Headers["Access-Control-Request-Headers"]
					.ToString()
					.Trim()
					.Split(',')
					.Select(p => p.Trim())
					.Where(p => p.Length > 0)
					.Where(p => !string.Equals(p, "*", StringComparison.Ordinal))
					.ToArray();
				exposedHeaders.AddRange(requestedHeaders);
			}

			// Custom Headers
			if ((exposedHeadersOptions.HeadersType == CorsExposedHeadersType.Custom)
				|| (exposedHeadersOptions.HeadersType == CorsExposedHeadersType.Both))
			{
				var headers = exposedHeadersOptions.CustomHeaders
					.Where(p => !string.Equals(p, "*", StringComparison.Ordinal))
					.ToArray();
				exposedHeaders.AddRange(headers);
			}

			// Adjust
			exposedHeaders = exposedHeaders.Distinct(StringComparer.OrdinalIgnoreCase).ToList();

			// Set
			if (exposedHeaders.Count > 0)
			{
				httpResponse.Headers["Access-Control-Expose-Headers"] = string.Join(", ", exposedHeaders);
			}
		}
		#endregion

		#region Access-Control-Max-Age
		/// <summary>
		/// Whether we can/should set max age response header
		/// </summary>
		/// <param name="httpRequest">Http Request</param>
		/// <param name="processor">Request processor</param>
		/// <returns></returns>
		// ReSharper disable once UnusedParameter.Local
		private static bool ShouldSetMaxAgeResponseHeader(HttpRequest httpRequest, CorsProcessorOptions processor)
		{
			var maxAgeOptions = processor.MaxAge;
			return (maxAgeOptions?.Age != null)
				&& (maxAgeOptions.Age.Value >= TimeSpan.Zero)
				&& (maxAgeOptions.Age.Value != TimeSpan.MaxValue);
		}

		/// <summary>
		/// Sets Access-Control-Max-Age header
		/// </summary>
		/// <param name="httpRequest">Http Request</param>
		/// <param name="httpResponse">Http Response</param>
		/// <param name="processor">Request processor</param>
		// ReSharper disable once UnusedParameter.Local
		private static void SetMaxAgeResponseHeader(HttpRequest httpRequest, HttpResponse httpResponse, CorsProcessorOptions processor)
		{
			var maxAgeOptions = processor.MaxAge;
			// ReSharper disable once PossibleInvalidOperationException
			httpResponse.Headers["Access-Control-Max-Age"] = maxAgeOptions.Age.Value.TotalSeconds.ToString(CultureInfo.InvariantCulture);
		}
		#endregion

		#region Access-Control-Allow-Credentials
		/// <summary>
		/// Whether we can/should set allow credentials response header
		/// </summary>
		/// <param name="httpRequest">Http Request</param>
		/// <param name="processor">Request processor</param>
		/// <returns></returns>
		// ReSharper disable once UnusedParameter.Local
		private static bool ShouldSetAllowCredentialsResponseHeader(HttpRequest httpRequest, CorsProcessorOptions processor)
		{
			var allowCredentialsOptions = processor.AllowCredentials;
			return allowCredentialsOptions.Allow;
		}

		/// <summary>
		/// Sets Access-Control-Allow-Credentials header
		/// </summary>
		/// <param name="httpRequest">Http Request</param>
		/// <param name="httpResponse">Http Response</param>
		/// <param name="processor">Request processor</param>
		// ReSharper disable once UnusedParameter.Local
		private static void SetAllowCredentialsResponseHeader(HttpRequest httpRequest, HttpResponse httpResponse, CorsProcessorOptions processor)
		{
			var allowCredentialsOptions = processor.AllowCredentials;
			httpResponse.Headers["Access-Control-Allow-Credentials"] =
				allowCredentialsOptions.Allow ? "true" : "false";
		}
		#endregion
		#endregion
	}

	#region Options
	#region Sub-options
	/// <summary>
	/// Origin type
	/// </summary>
	public enum CorsOriginType
	{
		None,
		Request,
		Origin,
		Custom,
		All
	}

	/// <summary>
	/// Allow methods type
	/// </summary>
	public enum CorsAllowMethodsType
	{
		None,
		DoNotRespond,
		Request,
		Custom,
		RequestAndCustom,
		All
	}

	/// <summary>
	/// Allow headers type
	/// </summary>
	public enum CorsAllowHeadersType
	{
		None,
		Request,
		Custom,
		Both
	}

	/// <summary>
	/// Exposed headers mode
	/// </summary>
	public enum CorsExposeHeadersMode
	{
		Never,
		RequestedHeaders,
		Always
	}

	/// <summary>
	/// Exposed headers type
	/// </summary>
	public enum CorsExposedHeadersType
	{
		Request,
		Custom,
		Both
	}

	/// <summary>
	/// Origin
	/// </summary>
	public sealed class CorsOriginOptions
	{
		/// <summary>
		/// How to respond
		/// </summary>
		public CorsOriginType OriginType
		{
			get;
			set;
		} = CorsOriginType.None;

		private string _customOrigin;
		/// <summary>
		/// Custom response
		/// </summary>
		public string CustomOrigin
		{
			get => _customOrigin;
			set => _customOrigin = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}
	}

	/// <summary>
	/// Allow methods configuration
	/// </summary>
	public sealed class CorsAllowMethodsOptions
	{
		/// <summary>
		/// How to respond
		/// </summary>
		public CorsAllowMethodsType MethodType
		{
			get;
			set;
		} = CorsAllowMethodsType.None;

		private List<string> _customMethods = new List<string>();
		/// <summary>
		/// Custom response
		/// </summary>
		[SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		[SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists")]
		public List<string> CustomMethods
		{
			get => _customMethods;
			set => _customMethods = (value ?? new List<string>()).Where(p => !string.IsNullOrWhiteSpace(p)).Select(p => p.Trim()).ToList();
		}
	}

	/// <summary>
	/// Allow headers
	/// </summary>
	public sealed class CorsAllowHeadersOptions
	{
		/// <summary>
		/// How to respond
		/// </summary>
		public CorsAllowHeadersType HeadersType
		{
			get;
			set;
		} = CorsAllowHeadersType.None;

		private List<string> _customHeaders = new List<string>();
		/// <summary>
		/// Custom response
		/// </summary>
		[SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		[SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists")]
		public List<string> CustomHeaders
		{
			get => _customHeaders;
			set => _customHeaders = (value ?? new List<string>()).Where(p => !string.IsNullOrWhiteSpace(p)).Select(p => p.Trim()).ToList();
		}
	}

	/// <summary>
	/// Exposed headers
	/// </summary>
	public sealed class CorsExposeHeadersOptions
	{
		/// <summary>
		/// When to respond
		/// </summary>
		public CorsExposeHeadersMode Mode
		{
			get;
			set;
		} = CorsExposeHeadersMode.Never;

		/// <summary>
		/// Type
		/// </summary>
		public CorsExposedHeadersType HeadersType
		{
			get;
			set;
		} = CorsExposedHeadersType.Both;

		private List<string> _customHeaders = new List<string>();
		/// <summary>
		/// Custom response
		/// </summary>
		[SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		[SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists")]
		public List<string> CustomHeaders
		{
			get => _customHeaders;
			set => _customHeaders = (value ?? new List<string>()).Where(p => !string.IsNullOrWhiteSpace(p)).Select(p => p.Trim()).ToList();
		}
	}

	/// <summary>
	/// Credentials
	/// </summary>
	public sealed class CorsAllowCredentialsOptions
	{
		/// <summary>
		/// Allow
		/// </summary>
		public bool Allow
		{
			get;
			set;
		}
	}

	/// <summary>
	/// Max age
	/// </summary>
	public sealed class CorsMaxAgeOptions
	{
		/// <summary>
		/// Max age
		/// </summary>
		public TimeSpan? Age
		{
			get;
			set;
		}
	}

	/// <summary>
	/// Processor
	/// </summary>
	public sealed class CorsProcessorOptions
	{
		/// <summary>
		/// Predicate to be satisfied in order to process this item
		/// </summary>
		public Func<string, bool> OriginCondition
		{
			get;
			set;
		}

		private CorsOriginOptions _allowOrigin = new CorsOriginOptions();
		/// <summary>
		/// Allow origin
		/// </summary>
		public CorsOriginOptions AllowOrigin
		{
			get => _allowOrigin;
			set => _allowOrigin = value ?? new CorsOriginOptions();
		}

		private CorsOriginOptions _timingAllowOrigin = new CorsOriginOptions();
		/// <summary>
		/// Timing allow origin
		/// </summary>
		public CorsOriginOptions TimingAllowOrigin
		{
			get => _timingAllowOrigin;
			set => _timingAllowOrigin = value ?? new CorsOriginOptions();
		}

		private CorsAllowMethodsOptions _allowMethods = new CorsAllowMethodsOptions();
		/// <summary>
		/// Allow methods
		/// </summary>
		public CorsAllowMethodsOptions AllowMethods
		{
			get => _allowMethods;
			set => _allowMethods = value ?? new CorsAllowMethodsOptions();
		}

		private CorsAllowHeadersOptions _allowHeaders = new CorsAllowHeadersOptions();
		/// <summary>
		/// Allow headers
		/// </summary>
		public CorsAllowHeadersOptions AllowHeaders
		{
			get => _allowHeaders;
			set => _allowHeaders = value ?? new CorsAllowHeadersOptions();
		}

		private CorsExposeHeadersOptions _exposeHeaders = new CorsExposeHeadersOptions();
		/// <summary>
		/// Exposed headers
		/// </summary>
		public CorsExposeHeadersOptions ExposeHeaders
		{
			get => _exposeHeaders;
			set => _exposeHeaders = value ?? new CorsExposeHeadersOptions();
		}

		private CorsAllowCredentialsOptions _allowCredentials = new CorsAllowCredentialsOptions();
		/// <summary>
		/// Allow credentials
		/// </summary>
		public CorsAllowCredentialsOptions AllowCredentials
		{
			get => _allowCredentials;
			set => _allowCredentials = value ?? new CorsAllowCredentialsOptions();
		}

		private CorsMaxAgeOptions _maxAge = new CorsMaxAgeOptions();
		/// <summary>
		/// Max-age
		/// </summary>
		public CorsMaxAgeOptions MaxAge
		{
			get => _maxAge;
			set => _maxAge = value ?? new CorsMaxAgeOptions();
		}
	}
	#endregion

	/// <summary>
	/// Options
	/// </summary>
	public sealed class CorsOptions
	{
		private List<CorsProcessorOptions> _processors = new List<CorsProcessorOptions>();
		/// <summary>
		/// Processors
		/// </summary>
		[SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		[SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists")]
		public List<CorsProcessorOptions> Processors
		{
			get => _processors;
			set => _processors = (value ?? new List<CorsProcessorOptions>()).Where(p => p != null).ToList();
		}
	}
	#endregion

	/// <summary>
	/// Processing result
	/// </summary>
	internal enum CorsRequestProcessingResult
	{
		NotHandled,
		Handled,
		HandledTerminateRequest
	}

	/// <summary>
	/// Extension method used to add the middleware to the HTTP request pipeline.
	/// </summary>
	public static class CorsMiddlewareExtensions
	{
		/// <summary>
		/// Extension method used to add the middleware to the HTTP request pipeline.
		/// </summary>
		/// <param name="builder">Application builder</param>
		/// <param name="options">Options</param>
		/// <returns>Application builder</returns>
		public static IApplicationBuilder UseCorsMiddleware(this IApplicationBuilder builder, CorsOptions options = null)
		{
			return builder.UseCorsMiddleware(optionsParam =>
			{
				if ((options != null) && (optionsParam != null))
				{
					Crosscuttings.Mapper.Map(options, optionsParam);
				}
			});
		}

		/// <summary>
		/// Extension method used to add the middleware to the HTTP request pipeline.
		/// </summary>
		/// <param name="builder">Application builder</param>
		/// <param name="optionsBuilder">Options builder</param>
		/// <returns>Application builder</returns>
		public static IApplicationBuilder UseCorsMiddleware(this IApplicationBuilder builder, Action<CorsOptions> optionsBuilder)
		{
			return builder.UseMiddleware<CorsMiddleware>(optionsBuilder);
		}
	}
}
