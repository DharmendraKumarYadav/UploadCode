﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;
using CacheManager.Core;
using FRT.Properties;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;

namespace FRT.Web
{
	/// <summary>
	/// Error type
	/// </summary>
	public enum ErrorType
	{
		Unknown,
		DataValidation,
		Security,
		BusinessRules
	}

	/// <summary>
	/// View model for the error handler
	/// </summary>
	public sealed class ErrorHandlerViewModel
	{
		internal ErrorHandlerViewModel()
		{
		}

		public ErrorType ErrorType
		{
			get;
			set;
		}

		private string _requestUrl;
		public string RequestUrl
		{
			get => _requestUrl;
			set => _requestUrl = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private string _message;
		public string Message
		{
			get => _message ?? Exception?.Message;
			set => _message = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		public Exception Exception
		{
			get;
			set;
		}
	}

	/// <summary>
	/// Exception handler helper
	/// </summary>
	public static class ErrorHandler
	{
		/// <summary>
		/// Creates error view model
		/// </summary>
		/// <param name="message">Error message</param>
		/// <param name="ex">Exception</param>
		/// <param name="errorType">Error type</param>
		/// <param name="exceptionRequestUrl">Original url where the error occurred</param>
		/// <returns>Error view model</returns>
		public static ErrorHandlerViewModel CreateErrorModel(string message, Exception ex, ErrorType errorType = ErrorType.Unknown, string exceptionRequestUrl = null)
		{
			message = string.IsNullOrWhiteSpace(message) ? null : message.Trim();
			return new ErrorHandlerViewModel
			{
				ErrorType = errorType,
				Message = message,
				Exception = ex,
				RequestUrl = exceptionRequestUrl
			};
		}

		/// <summary>
		/// Creates error view model
		/// </summary>
		/// <param name="message">Error message</param>
		/// <param name="errorType">Error type</param>
		/// <param name="exceptionRequestUrl">Original url where the error occurred</param>
		/// <returns>Error view model</returns>
		public static ErrorHandlerViewModel CreateErrorModel(string message, ErrorType errorType = ErrorType.Unknown, string exceptionRequestUrl = null)
		{
			message = string.IsNullOrWhiteSpace(message) ? null : message.Trim();
			return CreateErrorModel(message ?? CommonResources.S_UnknownError, null, errorType, exceptionRequestUrl);
		}

		/// <summary>
		/// Creates error view model
		/// </summary>
		/// <param name="ex">Exception</param>
		/// <param name="errorType">Error type</param>
		/// <param name="exceptionRequestUrl">Original url where the error occurred</param>
		/// <returns>Error view model</returns>
		public static ErrorHandlerViewModel CreateErrorModel(Exception ex, ErrorType errorType = ErrorType.Unknown, string exceptionRequestUrl = null)
		{
			return CreateErrorModel(ex?.Message ?? CommonResources.S_UnknownError, ex, errorType, exceptionRequestUrl);
		}

		/// <summary>
		/// Creates error view model
		/// </summary>
		/// <param name="errorType">Error type</param>
		/// <param name="exceptionRequestUrl">Original url where the error occurred</param>
		/// <returns>Error view model</returns>
		public static ErrorHandlerViewModel CreateErrorModel(ErrorType errorType, string exceptionRequestUrl = null)
		{
			return CreateErrorModel(CommonResources.S_UnknownError, errorType, exceptionRequestUrl);
		}

		/// <summary>
		/// Returns the error view model from the IExceptionHandlerFeature
		/// </summary>
		/// <param name="context">Http context</param>
		/// <returns>Error view model</returns>
		public static ErrorHandlerViewModel GetErrorModelFromExceptionFeature(this HttpContext context)
		{
			if (context == null)
			{
				throw new ArgumentNullException(nameof(context));
			}

			var feature = context.Features?.Get<IExceptionHandlerFeature>();
			if (feature != null)
			{
				var pathFeature = context.Features.Get<IExceptionHandlerPathFeature>();
				return new ErrorHandlerViewModel
				{
					ErrorType = ErrorType.Unknown,
					Exception = feature.Error,
					RequestUrl = pathFeature?.Path
				};
			}
			return null;
		}

		/// <summary>
		/// Sets context exception features from the given model
		/// </summary>
		/// <param name="context">Http context</param>
		/// <param name="model">Model</param>
		[SuppressMessage("Microsoft.Usage", "CA2201:DoNotRaiseReservedExceptionTypes")]
		[SuppressMessage("Microsoft.Design", "CA1062:Validate arguments of public methods", MessageId = "1")]
		public static void SetExceptionFeatureFromModel(this HttpContext context, ErrorHandlerViewModel model)
		{
			if (context == null)
			{
				throw new ArgumentNullException(nameof(context));
			}
			if (string.IsNullOrWhiteSpace(model?.Message))
			{
				throw new ArgumentNullException(nameof(model));
			}

			var feature = new ExceptionHandlerFeature
			{
				Error = model.Exception ?? new Exception(model.Message),
				Path = model.RequestUrl
			};
			context.Features?.Set<IExceptionHandlerFeature>(feature);
			context.Features?.Set<IExceptionHandlerPathFeature>(feature);
		}

		/// <summary>
		/// Returns an error redirect result for the given model
		/// </summary>
		/// <param name="model">Error data</param>
		public static Task<IActionResult> RedirectToError(ErrorHandlerViewModel model)
		{
			if (model == null)
			{
				throw new ArgumentNullException(nameof(model));
			}

			var exceptionHandlerOptions = DI.Container.GetService<ExceptionHandlerOptions>();
			var cacheKey = Guid.NewGuid().ToString("N");
			Crosscuttings.Cache.Put(new CacheItem<object>(cacheKey, model, ExpirationMode.Sliding, TimeSpan.FromSeconds(20.0)));
			return Task.FromResult(new RedirectResult(Url.AppendQueryParameters(exceptionHandlerOptions.RedirectPath, new { errorId = cacheKey }), false) as IActionResult);
		}

		/// <summary>
		/// Returns an error redirect result for the given model
		/// </summary>
		/// <param name="message">Error message</param>
		/// <param name="ex">Exception</param>
		/// <param name="errorType">Error type</param>
		/// <param name="exceptionRequestUrl">Original url where the error occurred</param>
		public static async Task<IActionResult> RedirectToError(string message, Exception ex, ErrorType errorType = ErrorType.Unknown, string exceptionRequestUrl = null)
		{
			message = string.IsNullOrWhiteSpace(message) ? null : message.Trim();
			return await RedirectToError(new ErrorHandlerViewModel
			{
				ErrorType = errorType,
				Message = message,
				Exception = ex,
				RequestUrl = exceptionRequestUrl
			});
		}

		/// <summary>
		/// Returns an error redirect result for the given model
		/// </summary>
		/// <param name="message">Error message</param>
		/// <param name="errorType">Error type</param>
		/// <param name="exceptionRequestUrl">Original url where the error occurred</param>
		public static async Task<IActionResult> RedirectToError(string message, ErrorType errorType = ErrorType.Unknown, string exceptionRequestUrl = null)
		{
			message = string.IsNullOrWhiteSpace(message) ? null : message.Trim();
			return await RedirectToError(message ?? CommonResources.S_UnknownError, null, errorType, exceptionRequestUrl);
		}

		/// <summary>
		/// Returns an error redirect result for the given model
		/// </summary>
		/// <param name="ex">Exception</param>
		/// <param name="errorType">Error type</param>
		/// <param name="exceptionRequestUrl">Original url where the error occurred</param>
		public static async Task<IActionResult> RedirectToError(Exception ex, ErrorType errorType = ErrorType.Unknown, string exceptionRequestUrl = null)
		{
			return await RedirectToError(ex?.Message ?? CommonResources.S_UnknownError, ex, errorType, exceptionRequestUrl);
		}

		/// <summary>
		/// Returns an error redirect result for the given model
		/// </summary>
		/// <param name="errorType">Error type</param>
		/// <param name="exceptionRequestUrl">Original url where the error occurred</param>
		public static async Task<IActionResult> RedirectToError(ErrorType errorType, string exceptionRequestUrl = null)
		{
			return await RedirectToError(CommonResources.S_UnknownError, errorType, exceptionRequestUrl);
		}
	}
}
