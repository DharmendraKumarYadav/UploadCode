﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using FRT.Properties;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Diagnostics;
using FRT.Messaging;

namespace FRT
{
	/// <summary>
	/// Middleware
	/// </summary>
	internal sealed class ExceptionHandlerMiddleware
	{
		private readonly RequestDelegate _next;
		private readonly Action<ExceptionHandlerOptions> _optionsBuilder;
		private readonly Lazy<ILogger<ExceptionHandlerMiddleware>> _logger;
		private readonly Func<object, Task> _clearCacheHeadersDelegate;

		#region Construction
		/// <summary>
		/// Constructor
		/// </summary>
		public ExceptionHandlerMiddleware(RequestDelegate next, Action<ExceptionHandlerOptions> optionsBuilder)
		{
			_next = next;
			_optionsBuilder = optionsBuilder ?? (o => { });
			_logger = new Lazy<ILogger<ExceptionHandlerMiddleware>>(Crosscuttings.GetTypedLogger<ExceptionHandlerMiddleware>);
			_clearCacheHeadersDelegate = ClearCacheHeaders;
		}
		#endregion

		#region Invoke

		/// <summary>
		/// Implementation
		/// </summary>
		/// <param name="httpContext">Http context</param>
		/// <returns>Task</returns>
		public async Task Invoke(HttpContext httpContext)
		{
			// Invoke next
			try
			{
				// Next
				await _next(httpContext);
			}
			catch (Exception ex)
			{
				// Get options
				var options = DI.Container.GetService<ExceptionHandlerOptions>() ?? new ExceptionHandlerOptions();
				_optionsBuilder(options);

				// Exception Processors
				var exceptionHandled = false;
				foreach (var proc in options.Processors)
				{
					if(proc(httpContext, ex))
					{
						exceptionHandled = true;
						break;
					}
				}

				// Check if we have an exception or it is already handled
				if (exceptionHandled)
				{
					// Return
					return;
				}

				// Log the exception
				if (options.EnableLog)
				{
					_logger.Value.LogError(ex, CommonResources.S_UnknownError);
				}

				// Save in Db
				if (options.EnableDatabasePersistence)
				{
					await SaveToDatabase(httpContext, ex);
				}

				// Redirect
				if (!options.EnableRedirect || (options.RedirectPath == null))
				{
					throw;
				}

				// Process it further
				if (httpContext.Response.HasStarted)
				{
					// We cannot proceed further
					_logger.Value.LogWarning("The response has already started, the error handler will not be executed.");

					// Rethrow
					throw;
				}

				// Redirect now
				var originalPath = httpContext.Request.Path;
				httpContext.Request.Path = options.RedirectPath;
				try
				{
					httpContext.Response.Clear();
					var exceptionHandlerFeature = new ExceptionHandlerFeature()
					{
						Error = ex,
						Path = originalPath.Value,
					};
					httpContext.Features.Set<IExceptionHandlerFeature>(exceptionHandlerFeature);
					httpContext.Features.Set<IExceptionHandlerPathFeature>(exceptionHandlerFeature);
					httpContext.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
					httpContext.Response.OnStarting(_clearCacheHeadersDelegate, httpContext.Response);

					// Call the next with the new path
					await _next(httpContext);

					// Return
					return;
				}
				catch (Exception ex2)
				{
					// Suppress secondary exceptions, re-throw the original.
					_logger.Value.LogError(ex2, "An exception was thrown attempting to execute the error handler.");
				}
				finally
				{
					// Restore the original path
					httpContext.Request.Path = originalPath;
				}

				// Throw original
				throw;
			}
		}

		#endregion

		#region Helpers

		private Task ClearCacheHeaders(object state)
		{
			HttpResponse response = (HttpResponse)state;
			response.Headers["Cache-Control"] = "no-cache";
			response.Headers["Pragma"] = "no-cache";
			response.Headers["Expires"] = "-1";
			response.Headers.Remove("ETag");
			return Task.CompletedTask;
		}

		#endregion

		#region Database

		/// <summary>
		/// Saves the exception details to the database
		/// </summary>
		/// <param name="httpContext">Context</param>
		/// <param name="ex">Exception</param>
		private Task SaveToDatabase(HttpContext httpContext, Exception ex)
		{
			// TODO
			return Task.CompletedTask;
		}

		#endregion
	}

	/// <summary>
	/// Options
	/// </summary>
	public class ExceptionHandlerOptions
	{
		/// <summary>
		/// Whether to log the error
		/// </summary>
		public bool EnableLog
		{
			get;
			set;
		} = true;

		/// <summary>
		/// Whether to save the exception into the database
		/// </summary>
		public bool EnableDatabasePersistence
		{
			get;
			set;
		} = false;

		private string _databaseConnectionString;
		/// <summary>
		/// Database connection string if database persistence is required
		/// </summary>
		public string DatabaseConnectionString
		{
			get { return _databaseConnectionString; }
			set { _databaseConnectionString = string.IsNullOrWhiteSpace(value) ? null : value.Trim(); }
		}

		private string _databaseTableName;
		/// <summary>
		/// Name of the database table if database persistence is required
		/// </summary>
		public string DatabaseTableName
		{
			get { return _databaseTableName; }
			set { _databaseTableName = string.IsNullOrWhiteSpace(value) ? null : value.Trim(); }
		}

		/// <summary>
		/// Whether to redirect to error page
		/// </summary>
		public bool EnableRedirect
		{
			get;
			set;
		} = true;

		private string _redirectPath;
		/// <summary>
		/// Path to redirect to
		/// </summary>
		public string RedirectPath
		{
			get { return _redirectPath; }
			set { _redirectPath = string.IsNullOrWhiteSpace(value) ? null : value.Trim(); }
		}

		private List<Func<HttpContext, Exception, bool>> _processors = new List<Func<HttpContext, Exception, bool>>();
		/// <summary>
		/// Exception processors
		/// </summary>
		[SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		[SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists")]
		public List<Func<HttpContext, Exception, bool>> Processors
		{
			get { return _processors; }
			set { _processors = ((IEnumerable<Func<HttpContext, Exception, bool>>)value ?? new Func<HttpContext, Exception, bool>[0]).Where(p => p != null).ToList(); }
		}
	}

	public static class ExceptionHandlerMiddlewareExtensions
	{
		/// <summary>
		/// Extension method used to add the middleware to the HTTP request pipeline.
		/// </summary>
		/// <param name="builder">Application builder</param>
		/// <param name="options">Options</param>
		/// <returns>Application builder</returns>
		public static IApplicationBuilder UseExceptionHandlerMiddleware(this IApplicationBuilder builder, ExceptionHandlerOptions options = null)
		{
			return builder.UseExceptionHandlerMiddleware(optionsParam =>
			{
				if ((options != null) && (optionsParam != null))
				{
					Crosscuttings.Mapper.Map(options, optionsParam);
				}
			});
		}

		/// <summary>
		/// Extension method used to add the middleware to the HTTP request pipeline.
		/// </summary>
		/// <param name="builder">Application builder</param>
		/// <param name="optionsBuilder">Options builder</param>
		/// <returns>Application builder</returns>
		public static IApplicationBuilder UseExceptionHandlerMiddleware(this IApplicationBuilder builder, Action<ExceptionHandlerOptions> optionsBuilder)
		{
			return builder.UseMiddleware<ExceptionHandlerMiddleware>(optionsBuilder);
		}
	}
}

