﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using FRT.Properties;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using FRT.Web.Properties;

namespace FRT.Web
{
	/// <summary>
	/// Date time model binder
	/// </summary>
	public class DateTimeModelBinder : IModelBinder
	{
		private string _defaultDateFormat = "dd/MM/yyyy";
		/// <summary>
		/// Default date format to use
		/// </summary>
		public string DefaultDateFormat
		{
			get => _defaultDateFormat;
			set => _defaultDateTimeFormat = string.IsNullOrWhiteSpace(value) ? "dd/MM/yyyy" : value.Trim();
		}

		private string _defaultTimeFormat = "hh:mm:ss tt";
		/// <summary>
		/// Default time format to use
		/// </summary>
		public string DefaultTimeFormat
		{
			get => _defaultTimeFormat;
			set => _defaultTimeFormat = string.IsNullOrWhiteSpace(value) ? "hh:mm:ss tt" : value.Trim();
		}

		private string _defaultDateTimeFormat;
		/// <summary>
		/// Default date/time format to use
		/// </summary>
		public string DefaultDateTimeFormat
		{
			get => _defaultDateTimeFormat ?? StringUtil.JoinStrings(" ", DefaultDateFormat, DefaultTimeFormat) ?? ("dd/MM/yyyy hh:mm:ss tt");
			set => _defaultDateTimeFormat = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		/// <summary>
		/// Binding
		/// </summary>
		[SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity")]
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
		public Task BindModelAsync(ModelBindingContext bindingContext)
		{
			// Validate
			if (bindingContext == null)
			{
				throw new ArgumentNullException(nameof(bindingContext));
			}

			// Check if we have a value
			var valueProviderResult = bindingContext.ValueProvider.GetValue(bindingContext.ModelName);
			if (valueProviderResult == ValueProviderResult.None)
			{
				return Task.CompletedTask;
			}

			try
			{
				// Set the value
				bindingContext.ModelState.SetModelValue(bindingContext.ModelName, valueProviderResult);

				// Get the format info
				var formatAttr = bindingContext.GetAttributes<DateTimeBindingInfoAttribute>().FirstOrDefault() ?? new DateTimeBindingInfoAttribute();
				var dateFormat = formatAttr.DateFormat ?? DefaultDateFormat;
				var timeFormat = formatAttr.TimeFormat ?? DefaultTimeFormat;
				var dateTimeFormat = formatAttr.DateTimeFormat ?? DefaultDateTimeFormat;
				var format = (formatAttr.FormatType == DateTimeBindingFormatType.DateAndTime) ? dateTimeFormat
							: ((formatAttr.FormatType == DateTimeBindingFormatType.DateOnly) ? dateFormat
								: ((formatAttr.FormatType == DateTimeBindingFormatType.TimeOnly) ? timeFormat
									: dateTimeFormat));
				// Check model type
				if (formatAttr.FormatType == DateTimeBindingFormatType.TimeOnly)
				{
					if (bindingContext.ModelMetadata.UnderlyingOrModelType != typeof(TimeSpan))
					{
						throw new InvalidCastException(string.Format(CultureInfo.CurrentCulture,
							LocalResources.S_DateTimeModelBindingInvalidPropertyType_Name_Type_ExpectedTypes,
							bindingContext.ModelName, bindingContext.ModelMetadata.UnderlyingOrModelType, typeof(TimeSpan)));
					}
				}
				else
				{
					if ((bindingContext.ModelMetadata.UnderlyingOrModelType != typeof(DateTime))
						&& (bindingContext.ModelMetadata.UnderlyingOrModelType != typeof(DateTimeOffset)))
					{
						throw new InvalidCastException(string.Format(CultureInfo.CurrentCulture,
							LocalResources.S_DateTimeModelBindingInvalidPropertyType_Name_Type_ExpectedTypes,
							bindingContext.ModelName, bindingContext.ModelMetadata.UnderlyingOrModelType, typeof(DateTime) + " OR " + typeof(DateTimeOffset)));
					}
				}

				// Raw value & parse
				var rawValue = (valueProviderResult.FirstValue ?? string.Empty).Trim();
				if (rawValue.Length > 0)
				{
					if (formatAttr.FormatType != DateTimeBindingFormatType.TimeOnly)
					{
						// Get the client timezone info
						var timeZoneManager = DI.Container.GetService<IWebTimeZoneManager>();
						var clientTimeZone = timeZoneManager?.ClientEffectiveTimeZone ?? TimeZoneInfo.Local;
						DateTime parsedDt;

						// Parse
						if (DateTime.TryParseExact(rawValue, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out parsedDt))
						{
							// Convert to UTC
							parsedDt = DateTime.SpecifyKind(parsedDt, DateTimeKind.Unspecified);
							parsedDt = TimeZoneInfo.ConvertTime(parsedDt, clientTimeZone, TimeZoneInfo.Utc);

							// Set
							if (bindingContext.ModelType == typeof(DateTime?))
							{
								// ReSharper disable once RedundantExplicitNullableCreation
								bindingContext.Result = ModelBindingResult.Success(new DateTime?(parsedDt));
							}
							else if (bindingContext.ModelType == typeof(DateTime))
							{
								bindingContext.Result = ModelBindingResult.Success(parsedDt);
							}
							else if (bindingContext.ModelType == typeof(DateTimeOffset?))
							{
								// ReSharper disable once RedundantExplicitNullableCreation
								bindingContext.Result = ModelBindingResult.Success(new DateTimeOffset?(parsedDt));
							}
							else
							{
								bindingContext.Result = ModelBindingResult.Success(new DateTimeOffset(parsedDt));
							}
						}
						else
						{
							bindingContext.ModelState.TryAddModelError(bindingContext.ModelName, string.Format(CultureInfo.CurrentCulture, LocalResources.S_DateTimeCouldNotBeParsed_Value_ExpectedFormat,
								rawValue, format));
						}
					}
					else
					{
						TimeSpan parsedTs;
						if (TimeSpan.TryParseExact(rawValue, format, CultureInfo.InvariantCulture, TimeSpanStyles.None, out parsedTs))
						{
							bindingContext.Result = ModelBindingResult.Success(bindingContext.ModelType == typeof(TimeSpan?)
								// ReSharper disable once RedundantExplicitNullableCreation
								? new TimeSpan?(parsedTs) : parsedTs);
						}
						else
						{
							bindingContext.ModelState.TryAddModelError(bindingContext.ModelName, String.Format(CultureInfo.CurrentCulture, LocalResources.S_DateTimeCouldNotBeParsed_Value_ExpectedFormat,
								rawValue, format));
						}
					}
				}
				else if (!bindingContext.ModelMetadata.IsReferenceOrNullableType)
				{
					bindingContext.ModelState.TryAddModelError(bindingContext.ModelName, bindingContext.ModelMetadata
						.ModelBindingMessageProvider.ValueMustNotBeNullAccessor(valueProviderResult.ToString()));
				}
				else
				{
					bindingContext.Result = ModelBindingResult.Success(null);
				}
			}
			catch (Exception ex)
			{
				bindingContext.ModelState.TryAddModelError(bindingContext.ModelName, ex, bindingContext.ModelMetadata);
			}
			return Task.CompletedTask;
		}
	}

	/// <summary>
	/// Model binding provider
	/// </summary>
	public class DateTimeModelBinderProvider : IModelBinderProvider
	{
		private string _defaultDateFormat = "dd/MM/yyyy";
		/// <summary>
		/// Default date format to use
		/// </summary>
		public string DefaultDateFormat
		{
			get => _defaultDateFormat;
			set => _defaultDateTimeFormat = string.IsNullOrWhiteSpace(value) ? "dd/MM/yyyy" : value.Trim();
		}

		private string _defaultTimeFormat = "hh:mm:ss tt";
		/// <summary>
		/// Default time format to use
		/// </summary>
		public string DefaultTimeFormat
		{
			get => _defaultTimeFormat;
			set => _defaultTimeFormat = string.IsNullOrWhiteSpace(value) ? "hh:mm:ss tt" : value.Trim();
		}

		private string _defaultDateTimeFormat;
		/// <summary>
		/// Default date/time format to use
		/// </summary>
		public string DefaultDateTimeFormat
		{
			get => _defaultDateTimeFormat ?? StringUtil.JoinStrings(" ", DefaultDateFormat, DefaultTimeFormat) ?? ("dd/MM/yyyy hh:mm:ss tt");
			set => _defaultDateTimeFormat = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		/// <summary>
		/// Provide
		/// </summary>
		public IModelBinder GetBinder(ModelBinderProviderContext context)
		{
			if (context == null)
			{
				throw new ArgumentNullException(nameof(context));
			}

			if ((context.Metadata.UnderlyingOrModelType == typeof(DateTimeOffset))
				|| (context.Metadata.UnderlyingOrModelType == typeof(DateTime))
				|| (context.Metadata.UnderlyingOrModelType == typeof(TimeSpan)))
			{
				return new DateTimeModelBinder()
				{
					DefaultDateFormat = DefaultDateFormat,
					DefaultTimeFormat = DefaultTimeFormat,
					DefaultDateTimeFormat = _defaultDateTimeFormat
				};
			}

			return null;
		}
	}
}
