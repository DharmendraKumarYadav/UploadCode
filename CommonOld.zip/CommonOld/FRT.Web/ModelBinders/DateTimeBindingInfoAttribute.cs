﻿using System;

namespace FRT.Web
{
	/// <summary>
	/// Format type
	/// </summary>
	public enum DateTimeBindingFormatType
	{
		DateAndTime,
		DateOnly,
		TimeOnly
	}

	/// <summary>
	/// Information on DateTime Model binding
	/// </summary>
	[AttributeUsage(AttributeTargets.Property)]
	public sealed class DateTimeBindingInfoAttribute : Attribute
	{
		/// <summary>
		/// Constructor
		/// </summary>
		public DateTimeBindingInfoAttribute(DateTimeBindingFormatType formatType = DateTimeBindingFormatType.DateAndTime,
			string dateTimeFormat = null, string dateFormat = null, string timeFormat = null)
		{
			FormatType = formatType;
			DateFormat = dateFormat;
			TimeFormat = timeFormat;
			DateTimeFormat = dateTimeFormat;
		}

		/// <summary>
		/// Has date part
		/// </summary>
		public DateTimeBindingFormatType FormatType { get; }

		private string _dateFormat = "dd/MM/yyyy";
		/// <summary>
		/// Date format to use
		/// </summary>
		public string DateFormat
		{
			get => _dateFormat; private set => _dateFormat = string.IsNullOrWhiteSpace(value) ? "dd/MM/yyyy" : value.Trim();
		}

		private string _timeFormat = "hh:mm:ss tt";
		/// <summary>
		/// Time format to use
		/// </summary>
		public string TimeFormat
		{
			get => _timeFormat; private set => _timeFormat = string.IsNullOrWhiteSpace(value) ? "hh:mm:ss tt" : value.Trim();
		}

		private string _dateTimeFormat;
		/// <summary>
		/// Date/time format to use
		/// </summary>
		public string DateTimeFormat
		{
			get => _dateTimeFormat ?? StringUtil.JoinStrings(" ", DateFormat, TimeFormat) ?? ("dd/MM/yyyy hh:mm:ss tt"); private set => _dateTimeFormat = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}
	}
}
