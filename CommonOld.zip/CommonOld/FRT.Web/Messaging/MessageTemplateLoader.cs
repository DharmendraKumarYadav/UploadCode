﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;
using FRT.Messaging;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace FRT.Web
{
	/// <summary>
	/// Message template loader
	/// </summary>
	public sealed class MessageTemplateLoader : IMessageTemplateLoader
	{
		private readonly IHostingEnvironment _hostingEnvironment;
		private readonly IOptions<MessagingConfig> _config;
		private readonly ILogger<MessageTemplateLoader> _logger;
		private static readonly Regex _imageRegex1 = DI.Platform.CreateRegex(@"'[^']+\.(bmp|png|jpg|jpeg|gif)'", RegexOptions.Singleline | RegexOptions.IgnoreCase, true);
		private static readonly Regex _imageRegex2 = DI.Platform.CreateRegex("\"[^\"]+\\.(bmp|png|jpg|jpeg|gif)\"", RegexOptions.Singleline | RegexOptions.IgnoreCase, true);
		private static readonly Regex _imageRegex3 = DI.Platform.CreateRegex(@"url\s*\(\s*(?<urlValue>[^\)]+\.(bmp|png|jpg|jpeg|gif))\)", RegexOptions.Singleline | RegexOptions.IgnoreCase, true);

		/// <summary>
		/// Constructor
		/// </summary>
		public MessageTemplateLoader(IHostingEnvironment hostingEnvironment, IOptions<MessagingConfig> config, ILogger<MessageTemplateLoader> logger)
		{
			_config = config;
			_hostingEnvironment = hostingEnvironment;
			_logger = logger;
		}

		/// <summary>
		/// Loads the given template content
		/// </summary>
		/// <param name="templateRelativePath">Template relative path file name without the file extension</param>
		/// <param name="type">Templatetype to load</param>
		/// <returns>Content of the template if found. Null otherwise</returns>
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
		public string Load(string templateRelativePath, MessageTemplateType type)
		{
			if (string.IsNullOrWhiteSpace(templateRelativePath))
			{
				throw new ArgumentNullException(nameof(templateRelativePath));
			}

			try
			{
				// Get file info
				var fileExt = (type == MessageTemplateType.HtmlMail)
					? ".mail.html"
					: ((type == MessageTemplateType.TextMail)
						? ".mail.txt"
						: ".sms.txt");
				templateRelativePath = Path.Combine(_config.Value.Templates.RelativePath,
					Path.Combine(Path.GetDirectoryName(templateRelativePath),
						Path.GetFileNameWithoutExtension(templateRelativePath) + fileExt));
				var fileInfo = _hostingEnvironment.ContentRootFileProvider.GetFileInfo(templateRelativePath);
				if ((fileInfo == null) || fileInfo.IsDirectory || !fileInfo.Exists)
				{
					return null;
				}

				// Get physical path & return content
				var filePath = fileInfo.PhysicalPath;
				return File.ReadAllText(filePath);
			}
			catch (Exception ex)
			{
				_logger.LogError(ex);
				return null;
			}
		}

		/// <summary>
		/// Embeds resources into the html content
		/// </summary>
		/// <param name="htmlContent">Html content</param>
		/// <param name="templateRelativePath">Template relative path file name without the file extension</param>
		/// <param name="htmlLinkedResources">List of resources</param>
		[SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists")]
		public string EmbedHtmlResources(string htmlContent, string templateRelativePath, List<MessageAttachment> htmlLinkedResources)
		{
			if (string.IsNullOrWhiteSpace(templateRelativePath))
			{
				throw new ArgumentNullException(nameof(templateRelativePath));
			}
			if (htmlLinkedResources == null)
			{
				throw new ArgumentNullException(nameof(htmlLinkedResources));
			}

			// Get file info
			var fileExt = ".mail.html";
			templateRelativePath = Path.Combine(_config.Value.Templates.RelativePath, Path.Combine(Path.GetDirectoryName(templateRelativePath),
				Path.GetFileNameWithoutExtension(templateRelativePath) + fileExt));
			var fileInfo = _hostingEnvironment.ContentRootFileProvider.GetFileInfo(templateRelativePath);
			if (fileInfo == null)
			{
				return htmlContent;
			}

			// Get physical path & return content
			var filePath = fileInfo.PhysicalPath;

			// Clear resources
			htmlLinkedResources.Clear();
			Dictionary<string, string> idToFilePathMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

			// Replace
			htmlContent = _imageRegex1.Replace(htmlContent,
				match => ReplaceImageUrl(match.Value, filePath, "'", "'", ref htmlLinkedResources, ref idToFilePathMap));
			htmlContent = _imageRegex2.Replace(htmlContent,
				match => ReplaceImageUrl(match.Value, filePath, "\"", "\"", ref htmlLinkedResources, ref idToFilePathMap));
			htmlContent = _imageRegex3.Replace(htmlContent, delegate (Match match)
			{
				string matchValue = match.Value;
				Group urlValue = match.Groups["urlValue"];
				string leadingText = matchValue.Substring(0, urlValue.Index - match.Index);
				string trailingText = matchValue.Substring(urlValue.Index - match.Index + urlValue.Length);
				return ReplaceImageUrl(matchValue, filePath, leadingText, trailingText, ref htmlLinkedResources, ref idToFilePathMap);
			});

			// Return
			return htmlContent;
		}

		/// <summary>
		/// Converts a physical image url to a linked resource id
		/// </summary>
		/// <param name="imageUrl">Image url</param>
		/// <param name="templateContextPath">Physical path of the referring template file</param>
		/// <param name="leadingText">Leading text</param>
		/// <param name="trailingText">Training text</param>
		/// <param name="linkedResources">Linked resources</param>
		/// <param name="idToFilePathMap">Map between the resource id and the file path</param>
		/// <returns>Mapped image url</returns>
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
		private static string ReplaceImageUrl(string imageUrl, string templateContextPath, string leadingText, string trailingText, ref List<MessageAttachment> linkedResources, ref Dictionary<string, string> idToFilePathMap)
		{
			if (string.IsNullOrWhiteSpace(imageUrl))
			{
				throw new ArgumentNullException(nameof(imageUrl));
			}
			templateContextPath = (templateContextPath ?? string.Empty).Trim();
			leadingText = (leadingText ?? string.Empty).Trim();
			trailingText = (trailingText ?? string.Empty).Trim();
			if (linkedResources == null)
			{
				throw new ArgumentNullException(nameof(linkedResources));
			}
			if (idToFilePathMap == null)
			{
				throw new ArgumentNullException(nameof(idToFilePathMap));
			}

			// Original url
			string originalImageUrl = imageUrl;

			// Remove enclosing quotes
			imageUrl = imageUrl.Trim();
			imageUrl = imageUrl.Substring(leadingText.Length, imageUrl.Length - leadingText.Length - trailingText.Length);

			// Replace / with \\
			imageUrl = imageUrl.Replace("/", "\\");

			// Check if the url is a relative url
			try
			{
				string filePath = (templateContextPath.Length > 0) ? Path.Combine(Path.GetDirectoryName(templateContextPath), imageUrl) : imageUrl;
				string resourceId;
				if (!idToFilePathMap.TryGetValue(filePath, out resourceId))
				{
					var linkedResource = new MessageAttachment(filePath);
					resourceId = linkedResource.Id;
					linkedResources.Add(linkedResource);
					idToFilePathMap[filePath] = resourceId;
				}
				return string.Format(CultureInfo.InvariantCulture, "{0}cid:{1}{2}", leadingText, resourceId, trailingText);
			}
			// ReSharper disable once EmptyGeneralCatchClause
			catch { }
			return originalImageUrl;
		}
	}
}
