﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

namespace FRT
{
	/// <summary>
	/// Remote content proxy
	/// </summary>
	public sealed class RemoteProxyConfig : IInjectableConfig
	{
		private string _appId;
		/// <summary>
		/// App Id
		/// </summary>
		public string AppId
		{
			get => _appId;
			set => _appId = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		private string _appSecret;
		/// <summary>
		/// App Secret
		/// </summary>
		public string AppSecret
		{
			get => _appSecret;
			set => _appSecret = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
		}

		/// <summary>
		/// Token validity
		/// </summary>
		public int TokenValidityMilliseconds
		{
			get;
			set;
		}

		/// <summary>
		/// Token validity
		/// </summary>
		public TimeSpan TokenValidity => TimeSpan.FromMilliseconds(TokenValidityMilliseconds);

		private List<string> _allowedReferrers = new List<string>();
		/// <summary>
		/// Allowed referrer patterns
		/// </summary>
		[SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		[SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists")]
		public List<string> AllowedReferrers
		{
			get => _allowedReferrers;
			set => _allowedReferrers = (value ?? new List<string>()).Where(p => !string.IsNullOrWhiteSpace(p)).Select(p => p.Trim()).Distinct(StringComparer.Ordinal).ToList();
		}
	}
}
