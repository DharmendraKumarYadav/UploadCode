﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;

namespace FRT.Web
{
	/// <summary>
	/// Proxy for a remote url to support external urls which do not support CORS
	/// https://www.cs.tut.fi/~jkorpela/http.html
	/// http://www.w3.org/Protocols/rfc2616/rfc2616-sec14.html
	/// https://en.wikipedia.org/wiki/List_of_HTTP_header_fields
	/// https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers
	/// </summary>
	[SuppressMessage("Microsoft.Maintainability", "CA1506:AvoidExcessiveClassCoupling")]
	internal sealed class RemoteProxyMiddleware
	{
		private const string _poweredBy = "FR Tech Remote Proxy";
		private const string _overrrideHeaderPrefix = "X-WEBBROKER-";
		private const string _cookieTokenSeparator = "!#webb#!";
		private const string _cookieNamePrefix = "ASRPM-";

		private static readonly Dictionary<string, HeaderCopyAction> _requestHeaderCopyActionOverrides = GetRequestHeaderCopyActionOverrides();
		private static readonly Dictionary<string, Func<string, string>> _requestHeaderOverrides = GetRequestHeaderOverrides();
		private static readonly Dictionary<string, bool> _responseHeaderCopyActionOverrides = GetResponseHeaderCopyActionOverrides();
		private static readonly Dictionary<string, Func<string, string>> _responseHeaderOverrides = GetResponseHeaderOverrides();

		private readonly RequestDelegate _next;
		private readonly ILogger<RemoteProxyMiddleware> _logger;
		private readonly IOptions<RemoteProxyConfig> _config;
		private readonly Action<RemoteUrlProxyOptions> _optionsBuilder;

		private string _requestId;

		#region Construction
		/// <summary>
		/// Constructor
		/// </summary>
		public RemoteProxyMiddleware(RequestDelegate next,
			ILogger<RemoteProxyMiddleware> logger,
			IOptions<RemoteProxyConfig> config,
			Action<RemoteUrlProxyOptions> optionsBuilder)
		{
			_next = next;
			_logger = logger;
			_config = config;
			_optionsBuilder = optionsBuilder;
		}
		#endregion

		#region Inner Types
		/// <summary>
		/// Cookie Item
		/// </summary>
		private sealed class CookieItem
		{
			public string Name;
			// ReSharper disable once NotAccessedField.Local
#pragma warning disable 414
			[SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
			public string Value;
#pragma warning restore 414
			public object ExpiresAt;
			public bool Secure;
			public int Version;
		}
		#endregion

		#region Properties
		private RemoteUrlProxyOptions _options;
		/// <summary>
		/// Options
		/// </summary>
		private RemoteUrlProxyOptions Options
		{
			get
			{
				if (_options == null)
				{
					// Create new
					_options = new RemoteUrlProxyOptions();

					// Copy properties
					Crosscuttings.Mapper.Map(_config.Value, _options);

					// Add Allowed Referrers
					if (_options.AllowedReferrers.Count == 0)
					{
						var appHostName = StringExtensions.EscapeRegexPattern(Url.WebApplicationDomainUri.GetComponents(UriComponents.Host,
							UriFormat.Unescaped));
						var patterns = new[]
						{
							"^[a-z]+://{0}(:[0-9]+)?$",
							"^[a-z]+://{0}(:[0-9]+)?/"
						};
						patterns.ToList().ForEach(p => _options.AllowedReferrers.Add(string.Format(CultureInfo.InvariantCulture,
								p, appHostName)));
					}

					// Builder
					_optionsBuilder?.Invoke(_options);
				}
				return _options;
			}
		}
		#endregion

		#region Init Helpers
		/// <summary>
		/// Copy Action Overrides
		/// </summary>
		private static Dictionary<string, HeaderCopyAction> GetRequestHeaderCopyActionOverrides()
		{
			// Overrides
			return new Dictionary<string, HeaderCopyAction>(StringComparer.OrdinalIgnoreCase)
			{
				{ "Accept-Encoding", HeaderCopyAction.None },
				{ "Cookie", HeaderCopyAction.None },
				{ "Host", HeaderCopyAction.None },
				{ "Transfer-Encoding", HeaderCopyAction.None }
			};
		}

		/// <summary>
		/// List of headers to be overridden
		/// </summary>
		private static Dictionary<string, Func<string, string>> GetRequestHeaderOverrides()
		{
			// Overrides
			var headerInfos = new Dictionary<string, Func<string, string>>(StringComparer.OrdinalIgnoreCase)
			{
				{ "X-Forwarded-For", h => ClientIp.GetRemoteAddress()?.ToString() ?? string.Empty }
			};

			// Return
			return headerInfos;
		}

		/// <summary>
		/// Copy Action Overrides
		/// </summary>
		private static Dictionary<string, bool> GetResponseHeaderCopyActionOverrides()
		{
			// Overrides
			var headerInfos = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase)
			{
				{ "Transfer-Encoding", false }
			};

			// Return
			return headerInfos;
		}

		/// <summary>
		/// List of headers to be overridden
		/// </summary>
		private static Dictionary<string, Func<string, string>> GetResponseHeaderOverrides()
		{
			// Overrides
			var headerInfos = new Dictionary<string, Func<string, string>>(StringComparer.OrdinalIgnoreCase)
			{
				{ "X-Powered-By", v => _poweredBy }
			};

			// Return
			return headerInfos;
		}
		#endregion

		#region Implementation
		/// <summary>
		/// Invoke
		/// </summary>
		/// <param name="httpContext">Http context</param>
		public async Task Invoke(HttpContext httpContext)
		{
			// Options
			var options = Options;

			// Get parameters
			var referrer = httpContext.Request.Headers["Referer"].ToString();
			if ((options.AllowedReferrers.Count > 0)
				&& (string.IsNullOrWhiteSpace(referrer)
					|| !options.AllowedReferrers.Any(r => Regex.IsMatch(referrer, r, RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.Singleline))))
			{
				httpContext.Response.StatusCode = StatusCodes.Status401Unauthorized;
				// ReSharper disable once ConstantNullCoalescingCondition
				_logger.LogError(0, "The referrer(" + (referrer ?? "") + ") is not allowed");
				options.AllowedReferrers.ForEach(a =>
				{
					_logger.LogError(0, "Allowed referrer pattern - " + a);
				});
				return;
			}

			// Parameters
			var appId = httpContext.Request.GetItem("a").ToString().Trim();
			var timestamp = httpContext.Request.GetItem("t").ToString().Trim();
			var nonce = httpContext.Request.GetItem("n").ToString().Trim();
			var hash = httpContext.Request.GetItem("h").ToString().Trim();

			// Params not supplied
			if (string.IsNullOrWhiteSpace(appId)
				&& string.IsNullOrWhiteSpace(timestamp)
				&& string.IsNullOrWhiteSpace(nonce)
				&& string.IsNullOrWhiteSpace(hash))
			{
				httpContext.Response.StatusCode = StatusCodes.Status401Unauthorized;
				_logger.LogError(0, "Required parameters not supplied");
				return;
			}

			// Partial set supplied
			if (string.IsNullOrWhiteSpace(appId)
				|| string.IsNullOrWhiteSpace(timestamp)
				|| string.IsNullOrWhiteSpace(nonce)
				|| string.IsNullOrWhiteSpace(hash))
			{
				httpContext.Response.StatusCode = StatusCodes.Status400BadRequest;
				return;
			}

			// Authenticate
			if (!Authenticate(appId, timestamp, nonce, hash))
			{
				httpContext.Response.StatusCode = StatusCodes.Status403Forbidden;
				return;
			}

			// Parameters
			var targetUrl = httpContext.Request.GetItem("u").ToString().Trim();
			var rerouteRelativeUrlsText = httpContext.Request.GetItem("r").ToString().Trim();
			var rerouteRelativeUrls = (string.IsNullOrWhiteSpace(rerouteRelativeUrlsText)
									   || (!string.Equals(rerouteRelativeUrlsText, "0", StringComparison.OrdinalIgnoreCase)
										   && !string.Equals(rerouteRelativeUrlsText, "false", StringComparison.OrdinalIgnoreCase)));
			var jsonpCallback = httpContext.Request.GetItem("callback").ToString().Trim();
			jsonpCallback = (jsonpCallback.Length == 0) ? null : jsonpCallback;

			// Validate
			if (string.IsNullOrWhiteSpace(targetUrl))
			{
				httpContext.Response.StatusCode = StatusCodes.Status400BadRequest;
				return;
			}
			else
			{
				Uri targetUri;
				try { targetUri = new Uri(targetUrl, UriKind.RelativeOrAbsolute); }
				catch { targetUri = null; }
				if ((targetUri == null) || !targetUri.IsAbsoluteUri
					|| !new[] { "http", "https" }.Any(p => string.Equals(p, targetUri.Scheme, StringComparison.OrdinalIgnoreCase)))
				{
					httpContext.Response.StatusCode = StatusCodes.Status400BadRequest;
					return;
				}
				else
				{
					// Request Id
					_requestId = $"{appId}#{targetUrl}".GetHashCode().ToString(CultureInfo.InvariantCulture);

					// Process
					var result = await ProcessRequest(targetUri, httpContext.Request, httpContext.Response,
												rerouteRelativeUrls, jsonpCallback);
					if(!result)
					{
						return;
					}
				}
			}

			// Next
			await _next(httpContext);
		}
		#endregion

		#region Helpers
		/// <summary>
		/// Validates the API Key
		/// </summary>
		/// <returns></returns>
		private bool Authenticate(string appId, string timestamp, string nonce, string hash)
		{
			// Check App Id
			if (string.IsNullOrWhiteSpace(appId))
			{
				return false;
			}
			appId = appId.Trim();

			// Check Timestamp
			ulong timestampNum;
			if (string.IsNullOrWhiteSpace(timestamp)
				|| !ulong.TryParse(timestamp.Trim(), out timestampNum))
			{
				return false;
			}

			// Check Nonce
			if (string.IsNullOrWhiteSpace(nonce))
			{
				return false;
			}
			nonce = nonce.Trim();

			// Check Hash
			if (string.IsNullOrWhiteSpace(hash))
			{
				return false;
			}
			hash = hash.Trim();

			// Options
			var options = Options;
			var configAppId = options.AppId;
			var configAppSecret = options.AppSecret;

			// Check App Id
			if (!string.Equals(configAppId, appId, StringComparison.OrdinalIgnoreCase))
			{
				return false;
			}

			// Generate out hash
			var generatedHash = HMACHelper.Hash(appId, configAppSecret, timestampNum, nonce);
			if (!string.Equals(generatedHash, hash, StringComparison.OrdinalIgnoreCase))
			{
				return false;
			}

			// Timestamp validity
			var epochStart = new DateTimeOffset(new DateTime(1970, 01, 01, 0, 0, 0, 0, DateTimeKind.Utc));
			var timestampDateTime = epochStart.Add(TimeSpan.FromSeconds(timestampNum));
			if (DateTimeOffset.UtcNow > (timestampDateTime.Add(options.TokenValidity)))
			{
				return false;
			}

			// Return
			return true;
		}

		/// <summary>
		/// Processing
		/// </summary>
		private async Task<bool> ProcessRequest(Uri targetUri, HttpRequest httpRequest, HttpResponse httpResponse, bool rerouteRelativeUrls, string jsonpCallback)
		{
			using (HttpClientHandler remoteClientHandler = new HttpClientHandler())
			using (HttpClient remoteClient = new HttpClient(remoteClientHandler, false))
			using (HttpRequestMessage remoteRequest = new HttpRequestMessage())
			{
				// Prepare request
				remoteRequest.RequestUri = targetUri;
				PrepareRequest(httpRequest, remoteRequest, remoteClientHandler);

				// Send
				var remoteResponse = await remoteClient.SendAsync(remoteRequest, HttpCompletionOption.ResponseContentRead);

				// Process response
				return await UpdateResponse(httpResponse, remoteResponse, remoteRequest, remoteClientHandler.CookieContainer, rerouteRelativeUrls, jsonpCallback);
			}
		}
		#endregion

		#region Request
		/// <summary>
		/// Prepares the request to be sent
		/// </summary>
		/// <param name="httpRequest">Current request</param>
		/// <param name="remoteRequest">Request</param>
		/// <param name="remoteClientHandler">Client handler</param>
		[SuppressMessage("Microsoft.Globalization", "CA1308:NormalizeStringsToUppercase")]
		private void PrepareRequest(HttpRequest httpRequest, HttpRequestMessage remoteRequest, HttpClientHandler remoteClientHandler)
		{
			// Options
			remoteClientHandler.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
			remoteClientHandler.ServerCertificateCustomValidationCallback += (message, certificate2, arg3, arg4) => true;

			// Request
			remoteRequest.Method = new HttpMethod(httpRequest.Method);

			// Headers
			CopyRequestHeaders(httpRequest, remoteRequest.Headers);

			// Cookies
			var superCookieValue = httpRequest.Cookies[_cookieNamePrefix + _requestId];
			if (!string.IsNullOrWhiteSpace(superCookieValue))
			{
				var cookieList = JsonConvert.DeserializeObject<CookieItem[]>(Encoding.UTF8.GetString(Convert.FromBase64String(superCookieValue)));
				foreach (var item in cookieList)
				{
					if (item.Secure && (!httpRequest.IsHttps || (remoteRequest.RequestUri.Scheme.ToLowerInvariant() != "https")))
					{
						continue;
					}
					item.ExpiresAt = (item.ExpiresAt != null)
						? DateTime.ParseExact((string)item.ExpiresAt, "O", CultureInfo.InvariantCulture)
						: DateTime.MinValue;
					remoteClientHandler.CookieContainer.Add(remoteRequest.RequestUri, new Cookie()
					{
						Name = item.Name,
						Expires = (DateTime)item.ExpiresAt,
						Secure = item.Secure,
						Version = item.Version
					});
				}
			}

			// Content
			if (httpRequest.ContentLength > 0)
			{
				remoteRequest.Content = new ByteArrayContent(httpRequest.Body.ReadAllBytes());
			}
		}

		/// <summary>
		/// Copies request headers
		/// </summary>
		/// <param name="httpRequest"></param>
		/// <param name="remoteHeaders"></param>
		private static void CopyRequestHeaders(HttpRequest httpRequest, HttpRequestHeaders remoteHeaders)
		{
			var invalidHeaders = new[]
			{
				"Allow",
				"Content-Disposition",
				"Content-Encoding",
				"Content-Language",
				"Content-Length",
				"Content-Location",
				"Content-MD5",
				"Content-Range",
				"Content-Type",
				"Cookie",
				"Expires",
				"Last-Modified"
			};
			var allHeaderNames = new List<string>();

			// All request headers
			allHeaderNames.AddRange(httpRequest.Headers.Keys);
			allHeaderNames.AddRange(_requestHeaderCopyActionOverrides.Select(t => t.Key));
			allHeaderNames.AddRange(_requestHeaderOverrides.Select(t => t.Key));
			allHeaderNames = allHeaderNames.Except(invalidHeaders).Distinct(StringComparer.OrdinalIgnoreCase).ToList();

			// CORS Headers
			allHeaderNames = allHeaderNames.Where(h => !h.StartsWith("Access-Control-", StringComparison.OrdinalIgnoreCase)
														&& !string.Equals(h, "Origin", StringComparison.OrdinalIgnoreCase)
														&& !string.Equals(h, "Timing-Allow-Origin", StringComparison.OrdinalIgnoreCase))
														.ToList();

			// Add
			foreach (var headerName in allHeaderNames)
			{
				string headerValue = null;
				var setValue = false;

				// Header overrides
				Func<string, string> headerValueCallback;
				if (_requestHeaderOverrides.TryGetValue(headerName, out headerValueCallback))
				{
					headerValue = headerValueCallback(headerName);
					setValue = true;
				}
				else
				{
					// Copy action
					HeaderCopyAction copyAction;
					if (!_requestHeaderCopyActionOverrides.TryGetValue(headerName, out copyAction))
					{
						copyAction = HeaderCopyAction.UseBoth;
					}

					// Copy
					if (copyAction != HeaderCopyAction.None)
					{
						// ReSharper disable once ConditionIsAlwaysTrueOrFalse
						if ((headerValue == null) && ((copyAction & HeaderCopyAction.UseForwardPrefixed) != 0))
						{
							var prefixedHeaderName = _overrrideHeaderPrefix + headerName;
							var prefixedHeaderValue = httpRequest.Headers[prefixedHeaderName].ToString();
							if (!string.IsNullOrWhiteSpace(prefixedHeaderValue))
							{
								headerValue = prefixedHeaderValue.Trim();
							}
						}
						if ((headerValue == null) && ((copyAction & HeaderCopyAction.UseCurrentRequest) != 0))
						{
							headerValue = httpRequest.Headers[headerName].ToString();
							if (string.IsNullOrWhiteSpace(headerValue))
							{
								headerValue = null;
							}
						}
						setValue = headerValue != null;
					}
				}

				// Set
				if (setValue)
				{
					remoteHeaders.Remove(headerName);
					if (headerValue != null)
					{
						remoteHeaders.Add(headerName, headerValue);
					}
				}
			}
		}
		#endregion

		#region Response
		/// <summary>
		/// Updates the current response from the remote response
		/// </summary>
		/// <param name="httpResponse">Current response</param>
		/// <param name="remoteResponse">Remote response</param>
		/// <param name="remoteRequest">Remote Request</param>
		/// <param name="cookieContainer">Cookie container</param>
		/// <param name="rerouteRelativeUrls">Whether to re-route relative urls in the response</param>
		/// <param name="jsonpCallback">JSONP callback name</param>
		private async Task<bool> UpdateResponse(HttpResponse httpResponse, HttpResponseMessage remoteResponse, HttpRequestMessage remoteRequest,
			CookieContainer cookieContainer, bool rerouteRelativeUrls, string jsonpCallback)
		{
			// Fixed Properties
			httpResponse.StatusCode = (int)remoteResponse.StatusCode;

			// Headers
			CopyResponseHeaders(remoteResponse.Headers, httpResponse);

			// Response Uri
			var locationHeader = remoteResponse.Headers.TryGetValue("Location", v => v.FirstOrDefault());
			var responseUri = (locationHeader != null)
				? new Uri(remoteRequest.RequestUri, locationHeader)
				: remoteRequest.RequestUri;

			// Cookies
			var cookieItems = new List<CookieItem>();
			foreach (Cookie cookie in cookieContainer.GetCookies(responseUri))
			{
				if (cookie.Secure && !httpResponse.HttpContext.Request.IsHttps)
				{
					continue;
				}
				var item = new CookieItem
				{
					Name = cookie.Name,
					ExpiresAt = cookie.Expires.ToString("O", CultureInfo.InvariantCulture),
					Value = cookie.Value,
					Version = cookie.Version,
					Secure = cookie.Secure
				};
				cookieItems.Add(item);
			}
			if (cookieItems.Count > 0)
			{
				var superCookieValue = Convert.ToBase64String(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(cookieItems.ToArray())));
				httpResponse.Cookies.Append(_cookieNamePrefix + _requestId, superCookieValue, new CookieOptions() { HttpOnly = true });
			}

			// Can reroute relative urls
			var collectContent = false;
			var htmlTypes = new[] { "text/html", "application/xhtml+xml" };
			// ReSharper disable once ConstantNullCoalescingCondition
			var responseContentType = remoteResponse.Headers.TryGetValue("Content-Type", v => v.FirstOrDefault())
					?? string.Empty;
			if (responseContentType.Length > 0)
			{
				if (rerouteRelativeUrls
					&& htmlTypes.Any(p => responseContentType.StartsWith(p, StringComparison.OrdinalIgnoreCase)))
				{
					collectContent = true;
				}
				else
				{
					rerouteRelativeUrls = false;
				}

				if ((jsonpCallback != null)
					&& responseContentType.Equals("application/json", StringComparison.OrdinalIgnoreCase))
				{
					collectContent = true;
				}
				else
				{
					jsonpCallback = null;
				}
			}
			else
			{
				rerouteRelativeUrls = false;
				jsonpCallback = null;
			}

			// Write Content
			byte[] responseBuffer = null;
			Encoding responseEncoding = null;
			using (var inputStream = await remoteResponse.Content.ReadAsStreamAsync())
			{
				if (inputStream != null)
				{
					// If not required to collect content, copy & return
					if (!collectContent)
					{
						inputStream.CopyTo(httpResponse.Body);
						return true;
					}

					// Reroute
					using (var outputStream = new MemoryStream())
					{
						// Copy to memory
						inputStream.CopyTo(outputStream);

						// Buffer
						var contentBuffer = outputStream.ToArray();
						if (contentBuffer.Length > 0)
						{
							// Get Encoding
							var contentEncoding = remoteResponse.Headers.TryGetValue("Content-Encoding", v => v.FirstOrDefault());
							if (!string.IsNullOrWhiteSpace(contentEncoding))
							{
								try
								{
									responseEncoding = Encoding.GetEncoding(contentEncoding);
								}
								// ReSharper disable once EmptyGeneralCatchClause
								catch { }
							}

							// Content
							responseEncoding = responseEncoding ?? Encoding.UTF8;
							responseBuffer = outputStream.ToArray();
						}
					}
				}

				// Process
				if (responseBuffer != null)
				{
					// Re-route Urls
					if (rerouteRelativeUrls)
					{
						// Reroute
						responseBuffer = responseEncoding.GetBytes(RerouteRelativeUrls(
												responseEncoding.GetString(responseBuffer), responseUri));
					}

					// JSONP
					if (jsonpCallback != null)
					{
						responseBuffer = responseEncoding.GetBytes(
											string.Format(CultureInfo.InvariantCulture,
												"{0}({1})",
												jsonpCallback,
												responseEncoding.GetString(responseBuffer)));
						responseContentType = "application/javascript";
					}

					// Write Response
					httpResponse.ContentType = responseContentType;
					httpResponse.Body.Write(responseBuffer, 0, responseBuffer.Length);
				}
			}

			// Result
			return remoteResponse.IsSuccessStatusCode;
		}

		/// <summary>
		/// Copies response headers
		/// </summary>
		/// <param name="remoteHeaders"></param>
		/// <param name="httpResponse"></param>
		private static void CopyResponseHeaders(HttpResponseHeaders remoteHeaders, HttpResponse httpResponse)
		{
			var invalidHeaders = new[]
			{
				"Allow",
				"Content-Disposition",
				"Content-Encoding",
				"Content-Language",
				"Content-Length",
				"Content-Location",
				"Content-MD5",
				"Content-Range",
				"Content-Type",
				"Expires",
				"Last-Modified",
				"Set-Cookie"
			};
			var allHeaderNames = new List<string>();

			// All request headers
			allHeaderNames.AddRange(remoteHeaders.Select(h => h.Key));
			allHeaderNames.AddRange(_responseHeaderCopyActionOverrides.Select(t => t.Key));
			allHeaderNames.AddRange(_responseHeaderOverrides.Select(t => t.Key));
			allHeaderNames = allHeaderNames.Except(invalidHeaders).Distinct(StringComparer.OrdinalIgnoreCase).ToList();

			// CORS Headers
			allHeaderNames = allHeaderNames.Where(h => !h.StartsWith("Access-Control-", StringComparison.OrdinalIgnoreCase)
														&& !string.Equals(h, "Origin", StringComparison.OrdinalIgnoreCase)
														&& !string.Equals(h, "Timing-Allow-Origin", StringComparison.OrdinalIgnoreCase))
														.ToList();

			// Add
			foreach (var headerName in allHeaderNames)
			{
				string headerValue = null;
				var setValue = false;

				// Header overrides
				Func<string, string> headerValueCallback;
				if (_responseHeaderOverrides.TryGetValue(headerName, out headerValueCallback))
				{
					headerValue = headerValueCallback(headerName);
					setValue = true;
				}
				else
				{
					// Copy action
					bool copyAction;
					if (!_responseHeaderCopyActionOverrides.TryGetValue(headerName, out copyAction))
					{
						copyAction = false;
					}

					// Copy
					if (copyAction)
					{
						headerValue = remoteHeaders.TryGetValue(headerName, v => v.FirstOrDefault());
						if (string.IsNullOrWhiteSpace(headerValue))
						{
							headerValue = null;
						}
						setValue = headerValue != null;
					}
				}

				// Set
				if (setValue)
				{
					httpResponse.Headers.Remove(headerName);
					if (headerValue != null)
					{
						httpResponse.Headers.Add(headerName, headerValue);
					}
				}
			}
		}
		#endregion

		#region Re-route
		private static readonly Regex _headRegex = new Regex(@"(?<preContent><\s*head[^>]*>)(?<content>.*)(?<postContent><\s*/\s*head\s*>)", RegexOptions.Compiled | RegexOptions.Singleline | RegexOptions.IgnoreCase);
		private static readonly Regex _baseTagRegex = new Regex(@"(?<pre><\s*base)(?<content>((?:\s+[\w-]+(?:\s*=\s*(?:(?:""[^""]*"")|(?:'[^']*')|[^>\s]+))?)*)\s*)(?<post>(\/?)>)", RegexOptions.Compiled | RegexOptions.Singleline | RegexOptions.IgnoreCase);
		private static readonly Regex _metaCharsetTag = new Regex(@"(?<pre><\s*meta)(?<content>((?:\s+[\w-]+(?:\s*=\s*(?:(?:""[^""]*"")|(?:'[^']*')|[^>\s]+))?)*)\s*)(?<post>(\/?)>)", RegexOptions.Compiled | RegexOptions.Singleline | RegexOptions.IgnoreCase);
		private static readonly Regex _metaUACompatibleTag = new Regex(@"(?<pre><\s*meta)(?<content>((?:\s+[\w-]+(?:\s*=\s*(?:(?:""[^""]*"")|(?:'[^']*')|[^>\s]+))?)*)\s*)(?<post>(\/?)>)", RegexOptions.Compiled | RegexOptions.Singleline | RegexOptions.IgnoreCase);
		private static readonly Regex _metaViewportTag = new Regex(@"(?<pre><\s*meta)(?<content>((?:\s+[\w-]+(?:\s*=\s*(?:(?:""[^""]*"")|(?:'[^']*')|[^>\s]+))?)*)\s*)(?<post>(\/?)>)", RegexOptions.Compiled | RegexOptions.Singleline | RegexOptions.IgnoreCase);
		private static readonly Regex _titleTag = new Regex(@"(?<pre><\s*title[^>]*>)(?<content>[^<]*)(?<post><\s*/\s*title\s*>)", RegexOptions.Compiled | RegexOptions.Singleline | RegexOptions.IgnoreCase);

		/// <summary>
		/// Changes all relative urls to the absolute urls
		/// </summary>
		private static string RerouteRelativeUrls(string htmlContent, Uri baseUri)
		{
			return _headRegex.Replace(htmlContent, m =>
			{
				// Get Parts
				string preContent = m.Groups["pre"].Success ? m.Groups["pre"].Value : string.Empty;
				string content = m.Groups["content"].Success ? m.Groups["content"].Value : string.Empty;
				string postContent = m.Groups["post"].Success ? m.Groups["post"].Value : string.Empty;

				// Check if we already have a base tag
				if (!_baseTagRegex.IsMatch(content))
				{
					// Absolute Url
					var testFileName = "Default.aspx";
					var baseUrl = Url.Convert(testFileName, UrlType.Absolute, baseUri.ToString());
					baseUrl = baseUrl.Substring(0, baseUrl.Length - testFileName.Length);

					// Insert
					var insertPosition = 0;

					// Meta Charset
					var match = _metaCharsetTag.Match(content);
					// ReSharper disable once ConditionIsAlwaysTrueOrFalse
					if ((match != null) && match.Success)
					{
						insertPosition = Math.Max(insertPosition, match.Index + match.Length);
					}

					// Meta UACompat
					match = _metaUACompatibleTag.Match(content);
					// ReSharper disable once ConditionIsAlwaysTrueOrFalse
					if ((match != null) && match.Success)
					{
						insertPosition = Math.Max(insertPosition, match.Index + match.Length);
					}

					// Meta Viewport
					match = _metaViewportTag.Match(content);
					// ReSharper disable once ConditionIsAlwaysTrueOrFalse
					if ((match != null) && match.Success)
					{
						insertPosition = Math.Max(insertPosition, match.Index + match.Length);
					}

					// Title
					match = _titleTag.Match(content);
					// ReSharper disable once ConditionIsAlwaysTrueOrFalse
					if ((match != null) && match.Success)
					{
						insertPosition = Math.Max(insertPosition, match.Index + match.Length);
					}

					// Insert at position
					content = content.Substring(0, insertPosition)
							  + Environment.NewLine
							  + string.Format(CultureInfo.InvariantCulture, "<base href=\"{0}\" />", baseUrl)
							  + Environment.NewLine
							  + content.Substring(insertPosition);
				}

				// Return
				return preContent + content + postContent;
			});
		}
		#endregion

		#region Cookies
		/// <summary>
		/// Creates an outgoing cookie based on the incoming one
		/// </summary>
		/// <returns></returns>
		// ReSharper disable once UnusedMember.Local
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
		// ReSharper disable once UnusedMember.Local
		private static Cookie CreateHttpWebRequestCookie(string cookieName, StringValues cookieValue, Uri externalUri)
		{
			// Try to decode
			string decodedName;
			try
			{
				decodedName = Encoding.UTF8.GetString(Convert.FromBase64String(cookieName));
			}
			catch { decodedName = null; }
			if (string.IsNullOrWhiteSpace(decodedName))
			{
				return null;
			}

			// Try to Split & get the patterns
			var parts = decodedName.Split(new[] { _cookieTokenSeparator }, StringSplitOptions.None)
				.Select(p => p.Trim())
				.Where(p => p.Length > 0)
				.ToArray();
			if (parts.Length != 3)
			{
				return null;
			}

			// Get Patters
			var domainPatternRegex = new Regex(parts[0],
				RegexOptions.Compiled | RegexOptions.Singleline | RegexOptions.IgnoreCase);
			if (domainPatternRegex.IsMatch(externalUri.Authority))
			{
				var pathPatternRegex = new Regex(parts[1],
					RegexOptions.Compiled | RegexOptions.Singleline | RegexOptions.IgnoreCase);
				if (pathPatternRegex.IsMatch(externalUri.AbsolutePath))
				{
					try
					{
						var cookie = (Cookie)JsonConvert.DeserializeObject(cookieValue.ToString(), typeof(Cookie));
						if (string.IsNullOrWhiteSpace(cookie.Domain))
						{
							cookie.Domain = externalUri.Host;
						}
						return cookie;
					}
					// ReSharper disable once EmptyGeneralCatchClause
					catch { }
				}
			}
			return null;
		}
		#endregion
	}

	/// <summary>
	/// Copy action
	/// </summary>
	[Flags]
	internal enum HeaderCopyAction
	{
		None = 0x0,
		UseForwardPrefixed = 0x1,
		UseCurrentRequest = 0x2,
		UseBoth = UseForwardPrefixed | UseCurrentRequest
	}

	/// <summary>
	/// Options
	/// </summary>
	public sealed class RemoteUrlProxyOptions
	{
		private string _appId;
		/// <summary>
		/// Application Id
		/// </summary>
		[SuppressMessage("Microsoft.Globalization", "CA1308:NormalizeStringsToUppercase")]
		public string AppId
		{
			get => _appId;
			set => _appId = string.IsNullOrWhiteSpace(value) ? null : value.Trim().ToLowerInvariant();
		}

		private string _appSecret;
		/// <summary>
		/// Application secret
		/// </summary>
		[SuppressMessage("Microsoft.Globalization", "CA1308:NormalizeStringsToUppercase")]
		public string AppSecret
		{
			get => _appSecret;
			set => _appSecret = string.IsNullOrWhiteSpace(value) ? null : value.Trim().ToLowerInvariant();
		}

		/// <summary>
		/// Token validity timestamp
		/// </summary>
		public TimeSpan TokenValidity
		{
			get;
			set;
		} = TimeSpan.FromMinutes(1.0D);

		private List<string> _allowedReferrers = new List<string>();
		/// <summary>
		/// Allowed referrer patterns
		/// </summary>
		[SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
		[SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists")]
		public List<string> AllowedReferrers
		{
			get => _allowedReferrers;
			set => _allowedReferrers = (value ?? new List<string>()).Where(p => !string.IsNullOrWhiteSpace(p)).Select(p => p.Trim()).Distinct(StringComparer.Ordinal).ToList();
		}
	}

	/// <summary>
	/// Extension method used to add the middleware to the HTTP request pipeline.
	/// </summary>
	public static class RemoteUrlProxyMiddlewareExtensions
	{
		/// <summary>
		/// Extension method used to add the middleware to the HTTP request pipeline.
		/// </summary>
		/// <param name="builder">Application builder</param>
		/// <param name="options">Options</param>
		/// <returns>Application builder</returns>
		public static IApplicationBuilder UseRemoteUrlProxyMiddleware(this IApplicationBuilder builder,
			RemoteUrlProxyOptions options = null)
		{
			return UseRemoteUrlProxyMiddleware(builder, o =>
			{
				if ((o != null) && (options != null))
				{
					Crosscuttings.Mapper.Map(options, o);
				}
			});
		}

		/// <summary>
		/// Extension method used to add the middleware to the HTTP request pipeline.
		/// </summary>
		/// <param name="builder">Application builder</param>
		/// <param name="optionsBuilder">Options builder</param>
		/// <returns>Application builder</returns>
		public static IApplicationBuilder UseRemoteUrlProxyMiddleware(this IApplicationBuilder builder,
			Action<RemoteUrlProxyOptions> optionsBuilder)
		{
			optionsBuilder = optionsBuilder ?? (o => { });
			return builder.UseMiddleware<RemoteProxyMiddleware>(optionsBuilder);
		}
	}
}
