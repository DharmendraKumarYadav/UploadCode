﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Loader;
using Microsoft.Extensions.DependencyModel;

namespace FRT
{
	/// <summary>
	/// App domain utility
	/// </summary>
	public static class AppDomainUtil
	{
		/// <summary>
		/// Returns a list of assemblies in a specified folder
		/// </summary>
		/// <param name="directoryPath">Folder path</param>
		/// <param name="searchOption">Search option</param>
		/// <param name="assemblyFilter">Assembly filter</param>
		/// <returns>Assemblies in the specified path</returns>
		[SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
		[SuppressMessage("Microsoft.Reliability", "CA2001:AvoidCallingProblematicMethods", MessageId = "System.Reflection.Assembly.LoadFrom")]
		public static IEnumerable<Assembly> AssembliesFromPath(string directoryPath, SearchOption searchOption = SearchOption.TopDirectoryOnly, Predicate<Assembly> assemblyFilter = null)
		{
			directoryPath = (directoryPath ?? string.Empty).Trim();
			if (directoryPath.Length == 0)
			{
				throw new ArgumentNullException(nameof(directoryPath));
			}
			else if (!Directory.Exists(directoryPath))
			{
				return null;
			}

			// Enumerate
			string[] fileExtensions = { ".dll", ".exe" };
			List<Assembly> assemblyList = new List<Assembly>();
			foreach (FileInfo fileInfo in new DirectoryInfo(directoryPath).GetFiles("*.*", searchOption))
			{
				if (Array.Find(fileExtensions, str => string.Equals(fileInfo.Extension, str, StringComparison.OrdinalIgnoreCase)) != null)
				{
					Assembly assembly = null;
					try
					{
						assembly = AssemblyLoadContext.Default.LoadFromAssemblyPath(fileInfo.FullName);
					}
					// ReSharper disable once EmptyGeneralCatchClause
					catch { }
					if ((assembly != null) && ((assemblyFilter == null) || assemblyFilter(assembly)))
					{
						assemblyList.Add(assembly);
					}
				}
			}
			return assemblyList;
		}

		/// <summary>
		/// Returns a list of assemblies referenced by the current application
		/// </summary>
		/// <returns></returns>
		public static Assembly[] GetAssemblies()
		{
			var assemblies = new List<Assembly>();
			var dependencies = DependencyContext.Default.RuntimeLibraries;
			foreach (var library in dependencies)
			{
				if (IsCandidateCompilationLibrary(library))
				{
					var assembly = Assembly.Load(new AssemblyName(library.Name));
					assemblies.Add(assembly);
				}
			}
			return assemblies.ToArray();
		}

		private static bool IsCandidateCompilationLibrary(RuntimeLibrary compilationLibrary)
		{
			return compilationLibrary.Name == ("Specify")
					|| compilationLibrary.Dependencies.Any(d => d.Name.StartsWith("Specify"));
		}
	}
}
