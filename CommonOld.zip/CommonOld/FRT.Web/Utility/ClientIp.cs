﻿using System;
using System.Net;
using System.Net.Sockets;
using Microsoft.AspNetCore.Http;

namespace FRT.Web
{
	/// <summary>
	/// IP Address Utilities
	/// http://stackoverflow.com/questions/527638/getting-the-client-ip-address-remote-addr-http-x-forwarded-for-what-else-coul
	/// http://www.grantburton.com/2008/11/30/fix-for-incorrect-ip-addresses-in-wordpress-comments/
	/// </summary>
	public static class ClientIp
	{
		/// <summary>
		/// Private IP Ranges
		/// </summary>
		private static readonly IpRange[] _privateRanges =
		{
			new IpRange("0.0.0.0", "2.255.255.255"),
			new IpRange("10.0.0.0", "10.255.255.255"),
			new IpRange("127.0.0.0", "127.255.255.255"),
			new IpRange("169.254.0.0", "169.254.255.255"),
			new IpRange("172.16.0.0", "172.31.255.255"),
			new IpRange("192.0.2.0", "192.0.2.255"),
			new IpRange("192.168.0.0", "192.168.255.255"),
			new IpRange("255.255.255.0", "255.255.255.255")
		};

		/// <summary>
		/// Header items to use in order of priority
		/// </summary>
		private static readonly HeaderItem[] _headerItems =
		{
			new HeaderItem("HTTP_CLIENT_IP", false),
			new HeaderItem("HTTP_X_FORWARDED_FOR", true),
			new HeaderItem("HTTP_X_FORWARDED", false),
			new HeaderItem("HTTP_X_CLUSTER_CLIENT_IP", false),
			new HeaderItem("HTTP_FORWARDED_FOR", false),
			new HeaderItem("HTTP_FORWARDED", false),
			new HeaderItem("HTTP_VIA", false),
			new HeaderItem("REMOTE_ADDR", false)
		};

		#region Internal Types
		/// <summary>
		/// Provides a simple class that understands how to parse and
		/// compare IP addresses (IPV4 and IPV6) ranges.
		/// </summary>
		private sealed class IpRange
		{
			private readonly UInt64 _start;
			private readonly UInt64 _end;

			public IpRange(string startStr, string endStr)
			{
				_start = ParseToUInt64(startStr);
				_end = ParseToUInt64(endStr);
			}

			public static UInt64 AddrToUInt64(IPAddress ip)
			{
				var ipBytes = ip.GetAddressBytes();
				UInt64 value = 0;

				foreach (var abyte in ipBytes)
				{
					value <<= 8;    // shift
					value += abyte;
				}

				return value;
			}

			// ReSharper disable once MemberCanBePrivate.Local
			public static UInt64 ParseToUInt64(string ipStr)
			{
				var ip = IPAddress.Parse(ipStr);
				return AddrToUInt64(ip);
			}

			public bool Encompasses(UInt64 addrValue)
			{
				return _start <= addrValue && addrValue <= _end;
			}

			// ReSharper disable once UnusedMember.Local
			public bool Encompasses(IPAddress addr)
			{
				var value = AddrToUInt64(addr);
				return Encompasses(value);
			}
		}

		/// <summary>
		/// Describes a header item (key) and if it is expected to be
		/// a comma-delimited string
		/// </summary>
		private sealed class HeaderItem
		{
			public readonly string Key;
			public readonly bool Split;

			public HeaderItem(string key, bool split)
			{
				Key = key;
				Split = split;
			}
		}
		#endregion

		/// <summary>
		/// Gets the client ip address from the request
		/// </summary>
		/// <param name="skipPrivate"></param>
		/// <returns></returns>
		public static IPAddress GetRemoteAddress(bool skipPrivate = true)
		{
			return GetRemoteAddress(WebCrosscuttings.HttpContext.Request, skipPrivate);
		}

		/// <summary>
		/// Gets the client ip address from the request
		/// </summary>
		/// <param name="context"></param>
		/// <param name="skipPrivate"></param>
		/// <returns></returns>
		public static IPAddress GetRemoteAddress(this HttpContext context, bool skipPrivate = true)
		{
			if (context == null)
			{
				throw new ArgumentNullException(nameof(context));
			}
			return GetRemoteAddress(context.Request, skipPrivate);
		}

		/// <summary>
		/// Gets the client ip address from the request
		/// </summary>
		/// <param name="request"></param>
		/// <param name="skipPrivate"></param>
		/// <returns></returns>
		public static IPAddress GetRemoteAddress(this HttpRequest request, bool skipPrivate = true)
		{
			if (request == null)
			{
				throw new ArgumentNullException(nameof(request));
			}

			foreach (var item in _headerItems)
			{
				var ipString = request.Headers[item.Key];
				if (ipString.Count <= 0)
				{
					continue;
				}
				foreach (var val in ipString.ToArray())
				{
					if (item.Split)
					{
						foreach (var ip in val.Split(','))
						{
							if (ValidIP(ip, skipPrivate))
							{
								return IPAddress.Parse(ip);
							}
						}
					}
					else
					{
						if (ValidIP(ipString, skipPrivate))
						{
							return IPAddress.Parse(ipString);
						}
					}
				}
			}
			return null;
		}

		/// <summary>
		/// Checks if the specified ip address string is valid
		/// </summary>
		/// <param name="ip">IP address string</param>
		/// <param name="skipPrivate">Whether to skip private addresses</param>
		private static bool ValidIP(string ip, bool skipPrivate)
		{
			IPAddress ipAddr;
			ip = ip?.Trim() ?? String.Empty;
			if ((ip.Length == 0)
				|| !IPAddress.TryParse(ip, out ipAddr)
				|| ((ipAddr.AddressFamily != AddressFamily.InterNetwork)
					&& (ipAddr.AddressFamily != AddressFamily.InterNetworkV6)))
			{
				return false;
			}

			if (skipPrivate && (ipAddr.AddressFamily == AddressFamily.InterNetwork))
			{
				var addr = IpRange.AddrToUInt64(ipAddr);
				// ReSharper disable once LoopCanBeConvertedToQuery
				foreach (var range in _privateRanges)
				{
					if (range.Encompasses(addr))
					{
						return false;
					}
				}
			}
			return true;
		}
	}

}